import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-membership',
  templateUrl: './membership.component.html',
  styleUrls: ['./membership.component.scss']
})
export class MembershipComponent implements OnInit {

  currentPlan: string = 'basic'; //monthly, yearly

  constructor() { }

  ngOnInit(): void {
  }

  updatePlan(newPlan): void {
    this.currentPlan = newPlan;
  }
}
