import { Component, OnInit, EventEmitter, Input, Output} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ConfirmationComponent } from '../confirmation/confirmation.component';

@Component({
  selector: 'app-old-notifications-card',
  templateUrl: './old-notifications-card.component.html',
  styleUrls: ['./old-notifications-card.component.scss']
})
export class OldNotificationsCardComponent implements OnInit {

  @Input() oldNotification: {id: number, content: string, icon: string, time: string, state: string, subMenu: string};
  
  @Input() selected: boolean = false;

  @Output() selectOldNotificationEvent = new EventEmitter<number>();

  constructor(private _snackBar: MatSnackBar) { }

  openSnackBar() {
    this._snackBar.openFromComponent(ConfirmationComponent, {
      duration: 3000,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['class-snackbar']
    });
  }

  ngOnInit(): void {
  }

}
