import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-quote-card-tracking',
  templateUrl: './quote-card-tracking.component.html',
  styleUrls: ['./quote-card-tracking.component.scss']
})
export class QuoteCardTrackingComponent implements OnInit {

  expand: boolean = false;

  @Input() card: {
    id: number, 
    title: string, 
    img: any, 
    subtitle: string, 
    date: string, 
    hora: string, 
    date2: string, 
    hora2: string, 
    date3: string, 
    hora3: string, 
    parrafo: string, 
    parrafo2: string};

  constructor() { }

  ngOnInit(): void {
  }

  toggleExpand () {
    this.expand = !this.expand;
  }

}
