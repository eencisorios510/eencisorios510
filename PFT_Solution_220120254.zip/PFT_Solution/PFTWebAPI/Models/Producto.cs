namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Producto
{
    public int Id { get; set; }
    [Column(TypeName = "nvarchar(250)")]
    public string Nombre { get; set; }
    public string ContratoJson { get; set; } = string.Empty;
    public bool Estado { get; set; }
     public ICollection<Solicitud> Solicitudes { get; set; } 

}
       