import { EventEmitter } from '@angular/core';
import { Output } from '@angular/core';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-rest',
  templateUrl: './medical-rest.component.html',
  styleUrls: ['./medical-rest.component.scss']
})
export class MedicalRestComponent implements OnInit {

  isChecked: boolean;
  isSlide: boolean;

  signed: boolean = false;
  content: string = 'Vestibulum eget urna risus. Donec et viverra nibh. Phasellus in scelerisque nunc. Quisque cursus pretium orci eu laoreet. Suspendisse placerat placerat ligula ac pretium. Nunc congue pellentesque risus, dignissim semper augue finibus quis. Nullam eget sagittis dui, id congue ex. Nunc in dui lacus. ';


  proximoControl: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

}
