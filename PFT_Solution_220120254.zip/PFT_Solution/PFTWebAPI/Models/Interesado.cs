// namespace PFTWebAPI.Entities;
// using System.ComponentModel.DataAnnotations;

// public class Interesado
// {
//     public int Id { get; set; }
//     public bool Is_Principal { get; set; }
//     //public Solicitud Solicitud { get; set; }=default!;
//     public int Solicitud_id { get; set; }
//     public Unidad_Equipo Unidad_Equipo { get; set; }=default!;
//     public int Unidad_Equipo_id { get; set; }
// }
     