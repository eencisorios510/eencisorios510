import { NgModule } from '@angular/core';
import { SomeComponent } from './some.component';
import {
  BcpActionSheetBodyModule,
  BcpActionSheetHeaderModule,
  BcpActionSheetModule,
  BcpButtonModule,
  BcpParagraphModule,
} from '@bcp/ng-ui-components';

@NgModule({
  declarations: [
    SomeComponent,
  ],
  imports: [
    BcpActionSheetModule,
    BcpActionSheetHeaderModule,
    BcpActionSheetBodyModule,
    BcpButtonModule,
    BcpParagraphModule,
  ],
  exports: [
    SomeComponent,
  ],
})
export class SomeModule { }