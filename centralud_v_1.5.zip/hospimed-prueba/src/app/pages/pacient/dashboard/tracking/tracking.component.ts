import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss']
})
export class TrackingComponent implements OnInit {

  cards: any[] = [
    {
      id: 85,
      title: 'P. Arterial',
      img: '../../../assets/images/arteria.png',
      subtitle: 'Milímetros de Mercurio (mmhg)',
      date: '01/02/2021',
      hora: '4:00 pm',
      date2: '02/02/2021',
      hora2: '12:00 pm',
      date3: '01/03/2021',
      hora3: '1:00 pm',
      parrafo: '180 mmhg',
      parrafo2: '170 mmhg'
    },
    {
      id: 70,
      title: 'F. Cardiaca',
      img: '../../../assets/images/corazon.png',
      subtitle: 'Latidos por minuto (x’)',
      date: '15/03/2021',
      hora: '4:00 pm',
      date2: '10/03/2021',
      hora2: '12:00 pm',
      date3: '01/03/2021',
      hora3: '1:00 pm',
      parrafo: '75 x’',
      parrafo2: '64 x’'
    },
    {
      id: 18,
      title: 'F. Respiratoria',
      img: '../../../assets/images/pulmon.png',
      subtitle: 'Respiraciones por minuto (x’)',
      date: '31/03/2021',
      hora: '4:00 pm',
      date2: '04/05/2021',
      hora2: '12:00 pm',
      date3: '11/07/2021',
      hora3: '1:00 pm',
      parrafo: '15 x’',
      parrafo2: '29 x’'
    },
  ];

  filteredCards: any[] = [];


  selectedDate: Date;
  startAt = new Date('2019/09/11');
  minDate = new Date('2019/09/14');
  maxDate = new Date(new Date().setMonth(new Date().getMonth() + 1));
  year: any;
  DayAndDate: string;

  turnDate: any;

  dates = [
    { day: 1, date: '29-03-2021', dateName: 'Lun 29', turns: [] },
    { day: 2, date: '30-03-2021', dateName: 'Mar 30', turns: [] },
    { day: 3, date: '01-04-2021', dateName: 'Mié 1', turns: [] },
    { day: 4, date: '02-04-2021', dateName: 'Jue 2', turns: [] },
    { day: 5, date: '03-04-2021', dateName: 'Vie 3', turns: [] },
    { day: 6, date: '04-04-2021', dateName: 'Sáb 4', turns: [] },
    { day: 7, date: '05-04-2021', dateName: 'Dom 5', turns: [] },
    { day: 1, date: '06-04-2021', dateName: 'Lun 6', turns: [] },
    { day: 2, date: '07-04-2021', dateName: 'mar 7', turns: [] },
    { day: 3, date: '08-04-2021', dateName: 'Mié 8', turns: [] },
  ];

  isEmpty: boolean = true;

  constructor() {
    this.filteredCards = this.cards;
   }

  ngOnInit(): void {
  }

}
