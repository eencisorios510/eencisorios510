import { ElementRef } from '@angular/core';
import { Component, OnInit, EventEmitter, Input, Output, ViewChild} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import { ConfirmationComponent } from '../confirmation/confirmation.component';

@Component({
  selector: 'app-new-notifications-card',
  templateUrl: './new-notifications-card.component.html',
  styleUrls: ['./new-notifications-card.component.scss']
})
export class NewNotificationsCardComponent implements OnInit {

  // @ViewChild('menu') menu;
  @ViewChild('closeBtn') closeBtn;

  @Input() newNotification: {id: number, content: string, icon: string, time: string, state: string, subMenu: string};

  private _selected;
  get selected(): boolean {return this._selected}
  @Input() set selected(val : boolean) {
    this._selected = val;
    console.log('funciona');

    // if(!val){
    //   this.closeBtn.closeMenu();
    // }
    console.log(this.closeBtn);

  };

  @Output() selectNewNotificationEvent = new EventEmitter<number>();

  constructor(private _snackBar: MatSnackBar) {
  }

  openSnackBar() {
    this._snackBar.openFromComponent(ConfirmationComponent, {
      duration: 3000,
      verticalPosition: 'top',
      horizontalPosition: 'center',
      panelClass: ['class-snackbar']
    });
  }

  ngOnInit(): void {
  }


}
