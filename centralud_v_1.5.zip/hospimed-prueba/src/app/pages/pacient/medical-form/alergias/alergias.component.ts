import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import {MatAutocompleteSelectedEvent, MatAutocomplete} from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-alergias',
  templateUrl: './alergias.component.html',
  styleUrls: ['./alergias.component.scss']
})
export class AlergiasComponent implements OnInit {

  medicamentoCtrl = new FormControl();
  medicamentos: string[] = [];
  filteredMedicamentos: Observable<string[]>;
  separatorKeysCodes: number[] = [ENTER, COMMA];

  @ViewChild('medicamentoInput') medicamentoInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.medicamentos.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.medicamentoCtrl.setValue(null);
  }

  remove(medicamento: string): void {
    const index = this.medicamentos.indexOf(medicamento);

    if (index >= 0) {
      this.medicamentos.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.medicamentos.push(event.option.viewValue);
    this.medicamentoInput.nativeElement.value = '';
    this.medicamentoCtrl.setValue(null);
  }

  constructor() { }

  ngOnInit(): void {
  }

}
