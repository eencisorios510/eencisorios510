import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-medical-board',
  templateUrl: './medical-board.component.html',
  styleUrls: ['./medical-board.component.scss']
})
export class MedicalBoardComponent implements OnInit {
  Checked: boolean = false;

  time = new FormControl();

  dateTime: string[] = ['00:00 a 00:00', '13:15 a 14:15', '14:15 a 15:15', '15:15 a 16:15 ', '16:15 a 17:15', '17:15 a 18:15'];

  @ViewChild('doctorInput') doctorInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  medicos:  Array<number> = [1];

  doctorCtrl = new FormControl();

  doctores: string[] = [];
  filteredDoctores: Observable<string[]>;

  separatorKeysCodes: number[] = [ENTER, COMMA];

  addMedico() {
    this.medicos.push(1);
  }

  removeMedico() {
    this.medicos.splice(0, 1);
  }

  constructor() { }

  ngOnInit(): void {
  }

  add(event: MatChipInputEvent, kind: string): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      switch (kind) {
        case 'doctores':
          this.doctores.push(value.trim());
          this.doctorCtrl.setValue(null);
          break;

        default:
          break;
      }
    }

    if (input) {
      input.value = '';
    }
  }

  remove(doctor: string, kind: string): void {
    let index;

    switch (kind) {
      case 'doctores':
        index = this.doctores.indexOf(doctor);
        if (index >= 0) this.doctores.splice(index, 1);
        break;

      default:
        break;
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.doctores.push(event.option.viewValue);
    this.doctorInput.nativeElement.value = '';
    this.doctorCtrl.setValue(null);
  }

  

}
