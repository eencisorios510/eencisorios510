import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacient-history',
  templateUrl: './pacient-history.component.html',
  styleUrls: ['./pacient-history.component.scss']
})
export class PacientHistoryComponent implements OnInit {

  history = [
    { id: 1, name: 'Medicina interna', date: '23/04/2021' },
    { id: 2, name: 'Gastroenterología', date: '23/04/2021' },
    { id: 3, name: 'Dermatología', date: '23/04/2021' },
    { id: 4, name: 'Otorrinolaringología', date: '23/04/2021' },
    { id: 5, name: 'Otorrinolaringología', date: '23/04/2021' },
    { id: 6, name: 'Dermatología', date: '23/04/2021' },
  ];

  expandedId: number;

  constructor() { }

  ngOnInit(): void {
  }

}
