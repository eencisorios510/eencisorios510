using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using PFTWebAPI.Data;

namespace PFTWebAPI.Controllers
{
    public class GridRequest{
        public string? Query {get;set;}
        public int PageNumber {get;set;} = 1;
        public int PageSize {get;set;} = 10;
        public string? SortBy {get;set;} = null;
        public string SortOrder {get;set;} = "asc";
    }

    public class GridResponse<TDto>{
        public int TotalRecords {get;set;}
        public int CurrentPage {get;set;}
        public int PageSize {get;set;}
        public IEnumerable<TDto> Data {get;set;} = new List<TDto>();
    }

    public abstract class GridController<TEntity, TGetDto, TCreateDto, TUpdateDto> : CrudController<TEntity, TGetDto, TCreateDto, TUpdateDto>
    where TEntity : class
    {
        protected GridController(DataContext context, IMapper mapper)
            : base(context, mapper) { }
    
        [HttpGet("grid")]
        public virtual async Task<ActionResult<GridResponse<TGetDto>>> GetGrid([FromQuery] GridRequest request)
        {
            var queryable = _dbSet.AsQueryable();
    
            // 1) Filtro (search)
            if (!string.IsNullOrEmpty(request.Query))
            {
                queryable = queryable.Where(SearchExpression(request.Query));
            }
    
            // 2) Ordenamiento
            if (!string.IsNullOrEmpty(request.SortBy))
            {
                if (request.SortOrder.Equals("desc", System.StringComparison.OrdinalIgnoreCase))
                {
                    queryable = queryable.OrderByDescending(e => EF.Property<object>(e, request.SortBy));
                }
                else
                {
                    queryable = queryable.OrderBy(e => EF.Property<object>(e, request.SortBy));
                }
            }
    
            // 3) Total antes de paginar
            var totalRecords = await queryable.CountAsync();
    
            // 4) Paginación
            queryable = queryable
                .Skip((request.PageNumber - 1) * request.PageSize)
                .Take(request.PageSize);
    
            // 5) Ejecutamos la query
            var entities = await queryable.ToListAsync();
            var dtos = _mapper.Map<IEnumerable<TGetDto>>(entities);
    
            // 6) Armamos la respuesta
            var response = new GridResponse<TGetDto>
            {
                TotalRecords = totalRecords,
                CurrentPage = request.PageNumber,
                PageSize = request.PageSize,
                Data = dtos
            };
    
            return Ok(response);
        }
    
        protected abstract Expression<Func<TEntity,bool>> SearchExpression(string query);
        
    }
}