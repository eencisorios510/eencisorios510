namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;

public class Tipo_Transferencia
{
    public int Id { get; set; }
    public string Nombre { get; set; }
    public string Tipo { get; set; }  
    //public ICollection<Solicitud> Solicitudes { get; set; }   

}
     