namespace PFTWebAPI.Dto;

    public class EmpresaCreateDto
    {
        public string Nombre { get; set; } = string.Empty;
        public string NombreCorto { get; set; } = string.Empty;
        public string Telefono { get; set; } = string.Empty;
        public string Pais { get; set; } = string.Empty;
        public string Ruc { get; set; } = string.Empty;
        public DateTime FechaRegistro { get; set; }
    }