import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalRestComponent } from './medical-rest.component';

describe('MedicalRestComponent', () => {
  let component: MedicalRestComponent;
  let fixture: ComponentFixture<MedicalRestComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalRestComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalRestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
