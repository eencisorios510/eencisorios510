﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PFTWebAPI.Migrations.SqlServerMigrations
{
    /// <inheritdoc />
    public partial class migration210120253 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
