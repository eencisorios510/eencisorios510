import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-layout',
  templateUrl: './dashboard-layout.component.html',
  styleUrls: ['./dashboard-layout.component.scss']
})
export class DashboardLayoutComponent implements OnInit {

  showAnnouncement: boolean = true;

  showFooter: boolean = false;
  

  menuItems = [
    // { icon: '/assets/images//assets/images/logo-full.svg', name: 'Dashboard', route: '/dashboard' },
    { icon: '/assets/images/sidebar/box-icon.png', name: 'Turnos', route: '/dashboard/turn-schedule' },
    { icon: '/assets/images/sidebar/calendar-icon.png', name: 'Citados', route: '/dashboard/quotes' },
    { icon: '/assets/images/sidebar/phone-icon.png', name: 'Teleconsulta', route: '/dashboard/quotes/:id/video-call' },
    { icon: '/assets/images/sidebar/eye-icon.png', name: 'Seguimiento', route: '/dashboard/patient-monitoring' },
    { icon: '/assets/images/sidebar/sound-icon.png', name: 'Campañas', route: '/dashboard/campaigns' },
    { icon: '/assets/images/sidebar/group-icon.png', name: 'Junta médica', route: '/dashboard/medical-board' },
    { icon: '/assets/images/sidebar/doc-icon.png', name: 'Honorarios', route: '/dashboard/honorarium' },
    { icon: '/assets/images/sidebar/table-icon.png', name: 'Reportería', route: '/dashboard/reports' },
    { icon: '/assets/images/sidebar/file-icon.png', name: 'Repositorio', route: '/dashboard/hce-report' }
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
