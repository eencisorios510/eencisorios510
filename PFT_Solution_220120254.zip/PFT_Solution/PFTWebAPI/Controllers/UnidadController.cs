using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto;


namespace PFTWebAPI.Controllers
{
    
    [Route("[controller]")]
    [ApiController]
    public class UnidadController 
        : CrudController<Unidad, UnidadDto, UnidadCreateDto, UnidadCreateDto>
    {
        public UnidadController(DataContext context, IMapper mapper)
            : base(context, mapper)
        {
        }

    }

}
