﻿namespace PFTWebAPI.Dto.Users;

using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

public class RegisterGUsuariosRequest
{

    public string IdSolicitud { get; set; }

    public string NombreEmpresa { get; set; }
    [Required]
    public string Producto { get; set; }
    [Required]
    public string Ambiente { get; set; }
}