import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteItemPatientComponent } from './quote-item-patient.component';

describe('QuoteItemPatientComponent', () => {
  let component: QuoteItemPatientComponent;
  let fixture: ComponentFixture<QuoteItemPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuoteItemPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteItemPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
