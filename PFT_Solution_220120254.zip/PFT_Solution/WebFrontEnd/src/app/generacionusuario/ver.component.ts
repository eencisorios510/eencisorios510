﻿import { Component, OnInit,inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { GuserService, AlertService } from '@app/_services';

@Component({ templateUrl: 'ver.component.html' })
export class VerComponent implements OnInit {
    form: UntypedFormGroup;
    id: string;
    loading = false;
    submitted = false;
    private readonly guserService = inject(GuserService);

    constructor(
        private formBuilder: UntypedFormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private alertService: AlertService
    ) {}

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];
        
        // password not required in edit mode
        const passwordValidators = [Validators.minLength(6)];


        this.form = this.formBuilder.group({
            codigo: ['', Validators.required],
            idAfiliacion: ['', Validators.required],
            nombreEmpresa: ['', Validators.required],
            producto: ['', Validators.required],
            ambiente: ['', Validators.required]
        });        

        this.form.disable();
        
            this.guserService.getGeneracionUsuarioById(this.id)
                .pipe(first())
                .subscribe(x => this.form.patchValue(x));
    }

    // convenience getter for easy access to form fields
    get f() { return this.form.controls; }

}