    namespace PFTWebAPI.Dto;
    public class SolicitudInteresado
    {
        public int SolicitudId { get; set; }
        public int? AplicacionId { get; set; }
        public int? UnidadId { get; set; }
        public bool EsResponsable { get; set; }
    }