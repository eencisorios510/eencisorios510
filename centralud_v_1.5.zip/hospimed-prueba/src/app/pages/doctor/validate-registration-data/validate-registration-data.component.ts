import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validate-registration-data',
  templateUrl: './validate-registration-data.component.html',
  styleUrls: ['./validate-registration-data.component.scss']
})
export class ValidateRegistrationDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
