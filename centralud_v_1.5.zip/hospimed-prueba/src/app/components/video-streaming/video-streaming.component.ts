import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EndCallComponent } from './end-call/end-call.component';


@Component({
  selector: 'app-video-streaming',
  templateUrl: './video-streaming.component.html',
  styleUrls: ['./video-streaming.component.scss']
})
export class VideoStreamingComponent implements OnInit {

  @Output() showChatEvent = new EventEmitter<boolean>();
  @Input() isHidden: boolean = true;

  fullscreen: boolean = false;

  callStarted: boolean = false;

  videocam: boolean = true;

  mic: boolean = true;

  constructor(public dialogEndCall: MatDialog) {}

  openDialogEndCall() {
    if(this.callStarted = true){
      this.dialogEndCall.open(EndCallComponent);

    } else this.callStarted = false;
  }

  ngOnInit(): void {
  }

}
