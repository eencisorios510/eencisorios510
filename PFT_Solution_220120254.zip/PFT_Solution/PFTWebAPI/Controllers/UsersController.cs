﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PFTWebAPI.Authorization;
using PFTWebAPI.Helpers;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Services;
using System.DirectoryServices.AccountManagement;

namespace PFTWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class UsersController : ControllerBase
    {
        private IUserService _userService;
        private IMapper _mapper;
        private readonly AppSettings _appSettings;
        private IJwtUtils _jwtUtils;
        public UsersController(
            IUserService userService,
            IMapper mapper,
            IOptions<AppSettings> appSettings,
            IJwtUtils jwtUtils)
        {
            _userService = userService;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            _jwtUtils = jwtUtils;
        }
        [AllowAnonymous]
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody] AuthenticateRequest login)
        {

         var isDevelopment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
            if (isDevelopment)
            {
                if(login.Username == "T40710"){
                    return Ok(new
                    {
                        username = login.Username,
                        token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlQ1MzcxNyIsIm5iZiI6MTczNTIzNTI3MSwiZXhwIjoxNzM1ODQwMDcxLCJpYXQiOjE3MzUyMzUyNzF9.aoJR5EIYNcjFT68TzjsoPElXXWguoG6rWznPn4iTQKM",
                        email = "adrianvargas@bcp.com.pe",
                        name = "Adrian Jesus Vargas Vargas",
                        rol = "Usuario",
                        rolId = 3
                    });
                }                
                if(login.Username == "T53717"){
                    return Ok(new
                    {
                        username = login.Username,
                        token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IlQ1MzcxNyIsIm5iZiI6MTczNTIzNTI3MSwiZXhwIjoxNzM1ODQwMDcxLCJpYXQiOjE3MzUyMzUyNzF9.aoJR5EIYNcjFT68TzjsoPElXXWguoG6rWznPn4iTQKM",
                        email = "emersonenciso@bcp.com.pe",
                        name = "Emerson Adrian Enciso Rios",
                        rol = "Especialista",
                        rolId = 2
                    });
                }

            }else{
                if (ValidateUser(login.Username, login.Password))
                {
                    var token = _jwtUtils.GenerateToken(login);
                    var usuarioAd = GetDataUser(login.Username);
                    var usuarioDb = _userService.GetRolByUsername(login.Username);
                    
                    return Ok(new
                    {
                        username = login.Username,
                        token = token,
                        email = usuarioAd.EmailAddress,
                        name = usuarioAd.Name,
                        rol = usuarioDb,
                        rolId = _userService.GetUserByUsername(login.Username).IdRol
                    });
                }

            }

            
            return Unauthorized(new { message = "Usuario o Contraseña es incorrecta" });
        }

        private bool ValidateUser(string username, string password)
        {
            using (var context = new PrincipalContext(ContextType.Domain))
            {
                return context.ValidateCredentials(username, password);
            }
        }   
 
        private UserPrincipal GetDataUser(string username)
        {
            string dominio = "credito.bcp.com.pe";
            PrincipalContext contexto = new PrincipalContext(ContextType.Domain, dominio);

            UserPrincipal usuario = UserPrincipal.FindByIdentity(contexto, username);

            if (usuario != null)
            {
                return usuario;
            }
            else
            {
                return null;
            }
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register(RegisterRequest model)
        {
            _userService.Register(model);
            return Ok(new { message = "Registro exitoso" });
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult GetAll()
        {
            var users = _userService.GetAll();
            return Ok(users);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var user = _userService.GetById(id);
            return Ok(user);
        }

        [AllowAnonymous]
        [HttpPut("{id}")]
        public IActionResult Update(int id, UpdateRequest model)
        {
            _userService.Update(id, model);
            return Ok(new { message = "Usuario actualizado exitosamente" });
        }
        
        [AllowAnonymous]
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _userService.Delete(id);
            return Ok(new { message = "Usuario eliminado exitosamente" });
        }
    }
}
