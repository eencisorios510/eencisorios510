namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;

public class H2h_Detalle
{
    public int Id { get; set; }
    public string Contacto { get; set; }
    public string Ruta { get; set; }
    public string Ip_host { get; set; }
    public string Puerto { get; set; }
    //public Solicitud Solicitud { get; set; }=default!;
    public int Solicitud_id { get; set; }
}
