﻿import { Component,inject  } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { AccountService } from './_services';
import { User } from './_models';
import { AccessibleLayout, NotificationItem } from '@bcp/stl-ui-components';



@Component({ selector: 'app', templateUrl: 'app.component.html' })
export class AppComponent {
    private userSubject: BehaviorSubject<User>;
    user: User;
    private readonly accountService = inject(AccountService);

    constructor() {
        this.accountService.user.subscribe(x => this.user = x);
        this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user'))); 
    }

    logout() {
        this.accountService.logout();
    }

    public get userValue(): User {
        return this.userSubject.value;
    }
    accessibleConfig: AccessibleLayout = {
        hamburgerConfig: {
          buttonAriaLabelledby: 'hamburgerLayoutSidebarSpanSrOnlyAria1',
          buttonAriaDescribedby: 'hamburgerLayoutSidebarSpanSrOnlyAria2'
        }
      }
    
      notifications: NotificationItem<any>[]= [
        { date: '10:00 am', description: 'Descarga tu estado de cuenta en noviembre', iconName: 'building-b', read: false },
        { date: '11:00 am', description: 'conforme', iconName: 'building-b', read: false },
        { date: '10:00 am', description: 'Descarga tu estado de cuenta en noviembre', iconName: 'building-b', read: false },
        { date: '11:00 am', description: 'conforme', iconName: 'building-b', read: false },
      ];
      size = 'md';
      bodyPosition = 'right';
      headerText = 'Notificaciones';
      footerText = 'Mostrar toda la actividad';
    
      handleConfigClick(): void {
        console.log('handleConfigClick');
      }
    
      handleFooterTextClick(): void {
        console.log('handleFooterTextClick');
      }
    
      handleItemSelected(event: Event): void {
        const { detail } = event as CustomEvent;
        console.log('(handleItemSelected) event listened', detail);
      }
    
      handleItemMenu(event: Event): void {
        const { detail } = event as CustomEvent;
        console.log('(handleItemMenu) event listened', detail);
      }
}