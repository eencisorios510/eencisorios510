import { Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';


@Component({
  selector: 'app-schedule-slider-tracking',
  templateUrl: './schedule-slider-tracking.component.html',
  styleUrls: ['./schedule-slider-tracking.component.scss']
})
export class ScheduleSliderTrackingComponent implements OnInit {

  @Input() dates: [];
  @Input() isEmpty: boolean = true;
  @Input() isPacient: boolean = false;

  @Output() removeTurnEvent = new EventEmitter<{ date: string, turnIndex: number }>();
  @Output() selectTurnEvent = new EventEmitter<{ date: string, turnIndex: number }>();

  sliderOptions: OwlOptions = {
    loop: false,
    dots: false,
    items: 5,
    nav: true,
    navText: [ '<div class="schedule-slider-btn mat-calendar-previous-button"></div>', '<div class="schedule-slider-btn mat-calendar-next-button"></div>' ],
    responsive: {
      1024 : {
        items: 7
      }
    }
  }

  currentDate: string = '01-01-2021';

  cards: any[] = [
    {
      date: '7:00 pm',
      alert: ''
    },
    {
      date: '3:00 pm',
      alert: ''
    },
    {
      date: '1:00 pm',
      alert: '14 hr 32 m Retraso'
    },
    // {
    //   date: '11:00 am',
    //   alert: '14 hr 32 m Retraso'
    // }
  ]

  itemsCard: any[] = [];

  constructor() { 
    this.itemsCard = this.cards;
  }

  ngOnInit(): void {
  }

  removeTurn(date, turnIndex): void {
    console.log('date: ', date);
    console.log('turnIndex: ', turnIndex);
    this.removeTurnEvent.emit({ date, turnIndex });
  }

  handleTurnClicked(turn): void {
    if (!this.isPacient) return;

    this.selectTurnEvent.emit(turn);
  }

}
