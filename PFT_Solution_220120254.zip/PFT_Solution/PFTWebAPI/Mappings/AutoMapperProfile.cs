﻿namespace PFTWebAPI.Mappings;

using AutoMapper;
using PFTWebAPI.Models;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Dto.AtencionSolicitud;
using PFTWebAPI.Dto;

public class AutoMapperProfile : Profile
{
    public AutoMapperProfile()
    {
     
        CreateMap<RegisterGUsuariosRequest, Generacion_Usuario>();

        // User -> AuthenticateResponse
        //CreateMap<UserEntity, AuthenticateResponse>();

        // RegisterRequest -> User
        CreateMap<RegisterRequest, UserEntity>();

        // UpdateRequest -> User
        CreateMap<UpdateRequest, UserEntity>()
            .ForAllMembers(x => x.Condition(
                (src, dest, prop) =>
                {
                    // ignore null & empty string properties
                    if (prop == null) return false;
                    if (prop.GetType() == typeof(string) && string.IsNullOrEmpty((string)prop)) return false;

                    return true;
                }
            ));

        // RegisterRequest -> User
        CreateMap<SolicitudAddRequest, Solicitud>();

        // UpdateRequest -> User
        CreateMap<SolicitudUpdateRequest, Solicitud>()
            .ForAllMembers(x => x.Condition(
                (src, dest, prop) =>
                {
                    // ignore null & empty string properties
                    if (prop == null) return false;
                    if (prop.GetType() == typeof(string) && string.IsNullOrEmpty((string)prop)) return false;

                    return true;
                }
            ));    

        CreateMap<RegisterRequestAtencion, HistorialAtencion>();   

        CreateMap<Unidad, UnidadDto>();
        CreateMap<UnidadCreateDto, Unidad>();
        CreateMap<Empresa, EmpresaGetDto>();
        CreateMap<EmpresaCreateDto, Empresa>();
        CreateMap<Producto, ProductoGetDto>();
        CreateMap<ProductoCreateDto, Producto>();         
    }
}