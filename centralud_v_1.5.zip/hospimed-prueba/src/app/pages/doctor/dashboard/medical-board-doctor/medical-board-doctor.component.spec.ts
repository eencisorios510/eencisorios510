import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalBoardDoctorComponent } from './medical-board-doctor.component';

describe('MedicalBoardDoctorComponent', () => {
  let component: MedicalBoardDoctorComponent;
  let fixture: ComponentFixture<MedicalBoardDoctorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalBoardDoctorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalBoardDoctorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
