import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyPlanCardComponent } from './monthly-plan-card.component';

describe('MonthlyPlanCardComponent', () => {
  let component: MonthlyPlanCardComponent;
  let fixture: ComponentFixture<MonthlyPlanCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyPlanCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyPlanCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
