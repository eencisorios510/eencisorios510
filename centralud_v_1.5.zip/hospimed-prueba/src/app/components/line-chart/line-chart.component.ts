import { Component, Input, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.scss']
})
export class LineChartComponent implements OnInit {
  @Input() data: ChartDataSets[];
  @Input() labels: Label[];
  @Input() chartHeight: string;

  public lineChartOptions: (ChartOptions) = {
    responsive: true,
    scales: {
      // We use this empty structure as a placeholder for dynamic theming.
      xAxes: [{}],
      yAxes: [
        {
          id: 'y-axis-0',
          position: 'left',
        },
      ]
    }
  };

  public lineChartColors: Color[] = [
    {
      backgroundColor: 'rgba(255, 255, 255, 0)',
      borderColor: '#103DF6',
      pointBackgroundColor: '#103DF6',
      pointBorderColor: '#103DF6',
      pointHoverBackgroundColor: '#103DF6',
      pointHoverBorderColor: '#103DF6'
    },
    {
      backgroundColor: 'rgba(255, 255, 255, 0)',
      borderColor: '#F8BE00',
      pointBackgroundColor: '#F8BE00',
      pointBorderColor: '#F8BE00',
      pointHoverBackgroundColor: '#F8BE00',
      pointHoverBorderColor: '#F8BE00'
    }
  ];
  public lineChartLegend = true;
  public lineChartType: ChartType = 'line';

  constructor() { }

  ngOnInit(): void {
  }

}
