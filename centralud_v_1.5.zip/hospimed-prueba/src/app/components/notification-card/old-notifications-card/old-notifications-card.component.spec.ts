import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OldNotificationsCardComponent } from './old-notifications-card.component';

describe('OldNotificationsCardComponent', () => {
  let component: OldNotificationsCardComponent;
  let fixture: ComponentFixture<OldNotificationsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OldNotificationsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OldNotificationsCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
