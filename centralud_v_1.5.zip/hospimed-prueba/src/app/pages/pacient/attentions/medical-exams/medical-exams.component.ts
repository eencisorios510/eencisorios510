import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-exams',
  templateUrl: './medical-exams.component.html',
  styleUrls: ['./medical-exams.component.scss']
})
export class MedicalExamsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
