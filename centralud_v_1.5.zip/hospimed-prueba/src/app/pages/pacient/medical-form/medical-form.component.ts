import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-medical-form',
  templateUrl: './medical-form.component.html',
  styleUrls: ['./medical-form.component.scss']
})
export class MedicalFormComponent implements OnInit {

  isContinuador: boolean = false;

  showAntecedentes: boolean = false;
  showGinecologicas: boolean = false;
  showAlergias: boolean = false;

  tiempoEnfermedad: number = 15;

  currentTiempoEnfermedadUnit: string;
  tiempoEnfermedadUnitsList: string[] = ['Días', 'Semanas', 'Meses'];
  filteredTiempoEnfermedadUnitsList: string[] = [];

  constructor() { }

  ngOnInit(): void {
    this.updateTiempoEnfermedadUnit('Días');
  }

  updateTiempoEnfermedadUnit(unit): void {
    this.currentTiempoEnfermedadUnit = unit;
    this.filteredTiempoEnfermedadUnitsList = this.tiempoEnfermedadUnitsList.filter(item => item !== this.currentTiempoEnfermedadUnit);
  }
}
