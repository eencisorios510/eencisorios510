namespace PFTWebAPI.Services;
using Microsoft.EntityFrameworkCore;

using AutoMapper;
using BCrypt.Net;
using PFTWebAPI.Authorization;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto.Users;

public interface IEstadoService
{
    bool CanChangeState(int rolId, int estadoId);
    EstadosSolicitud getEstadoById(int id);
    List<SolicitudBoton>  GetFormDetail(int rolId, int estadoId);
}

public class EstadoService : IEstadoService
{
    private DataContext _context;
    private IJwtUtils _jwtUtils;
    private readonly IMapper _mapper;

    public EstadoService(
        DataContext context,
        IJwtUtils jwtUtils,
        IMapper mapper)
    {
        _context = context;
        _jwtUtils = jwtUtils;
    }


    public bool CanChangeState(int rolId, int estadoId)
    {
       return _context.RolEstados.Any(x => x.RolId == rolId && x.Id == estadoId);
    }

    public List<SolicitudBoton>  GetFormDetail(int rolId, int estadoId)
    {
        var listBotones = new List<SolicitudBoton>();
        var estado = getEstadoById(estadoId);
       //Estado Anterior
        var estadoAnt = _context.EstadosSolicitudes.FirstOrDefault(x=>x.Orden == estado.Orden-1);
        if (estadoAnt != null)
        {
            var botonesAnterior = new SolicitudBoton {Boton="anterior",Estado=CanChangeState(rolId, estadoAnt.Id)};
            listBotones.Add(botonesAnterior);
        }
        else
        {
            var botonesAnterior = new SolicitudBoton {Boton="anterior",Estado=false};
            listBotones.Add(botonesAnterior);
        }        
    
       //Estado Siguiente

        var estadoSig = _context.EstadosSolicitudes.FirstOrDefault(x=>x.Orden == estado.Orden+1);
        if (estadoSig != null)
        {
            var botonesSiguiente = new SolicitudBoton {Boton="siguiente",Estado=CanChangeState(rolId, estadoSig.Id)};
            listBotones.Add(botonesSiguiente);
        }
        else
        {
            var botonesSiguiente = new SolicitudBoton {Boton="siguiente",Estado=false};
            listBotones.Add(botonesSiguiente);
        }       
 

        var botonesCancelado = new SolicitudBoton {Boton="cancelado",Estado=CanChangeState(rolId, 1)};
        listBotones.Add(botonesCancelado);
        var botonesRechazado = new SolicitudBoton {Boton="rechazado",Estado=CanChangeState(rolId, 9)};
        listBotones.Add(botonesRechazado);
        var botonesPendiente = new SolicitudBoton {Boton="pendiente",Estado=CanChangeState(rolId, 7)};
        listBotones.Add(botonesPendiente);                
        return listBotones;
    }     

    public EstadosSolicitud getEstadoById(int id)
    {
        var estado = _context.EstadosSolicitudes.Find(id);
        if (estado == null) throw new KeyNotFoundException("Estado no se encontro");
        return estado;
    }


}