import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HCEReportComponent } from './hce-report.component';

describe('HCEReportComponent', () => {
  let component: HCEReportComponent;
  let fixture: ComponentFixture<HCEReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HCEReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HCEReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
