import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TopBarPatientsComponent } from './top-bar-patients.component';

describe('TopBarPatientsComponent', () => {
  let component: TopBarPatientsComponent;
  let fixture: ComponentFixture<TopBarPatientsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TopBarPatientsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TopBarPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
