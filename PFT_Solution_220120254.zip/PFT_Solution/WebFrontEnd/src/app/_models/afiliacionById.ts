export class AfiliacionById {
    id: string;
    solicitante: string;
    correoSolicitante: string;
    fechaIngresoSolicitud: string;
    empresaAfiliacion: string;
    contactoEmpresa: string;
    correoContactoEmpresa: string;
    flujoInformacion: string;
    datosDac: string;
    tipoEncriptacion: string;
    especialistaComercial: string;
    responsable: string;
    detalleSolicitud: string;
    desc_AreaSolicitante: string;
    desc_Producto: string;
    desc_AplicacionSolicitante: string;
    desc_EstadoSolicitud: string;
    idEstadoSolicitud: string;
    productoId: string;
}