import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PickTurnComponent } from './pick-turn.component';

describe('PickTurnComponent', () => {
  let component: PickTurnComponent;
  let fixture: ComponentFixture<PickTurnComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PickTurnComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PickTurnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
