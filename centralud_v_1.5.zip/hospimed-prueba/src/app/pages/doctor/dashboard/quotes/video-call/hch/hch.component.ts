import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-hch',
  templateUrl: './hch.component.html',
  styleUrls: ['./hch.component.scss']
})
export class HchComponent implements OnInit {

  @Input() fullHeight: boolean = false;

  @Output() updateHCHEvent = new EventEmitter<boolean>();

  hchItems = [
    { id: 1, date: '10/04/2021' },
    { id: 2, date: '09/04/2021' },
    { id: 3, date: '08/04/2021' },
    { id: 4, date: '07/04/2021' },
    { id: 5, date: '10/03/2021' },
    { id: 6, date: '10/02/2021' },
    { id: 7, date: '10/01/2021' },
    { id: 8, date: '06/01/2021' },
    { id: 9, date: '05/01/2021' },
    { id: 10, date: '04/01/2021' },
  ];

  expandedItem = null;

  constructor() { }

  ngOnInit(): void {
  }

  toggleExpandedItem(itemId): void {
    this.expandedItem = this.expandedItem === itemId ? null : itemId;
  }
}
