namespace PFTWebAPI.Dto.Users;

using System.ComponentModel.DataAnnotations;

public class GetAllUsers
{
    public int Id { get; set; }
    public string Username { get; set; }
    public int IdRol { get; set; }
    public string Desc_Rol { get; set; }
}