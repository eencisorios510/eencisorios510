﻿namespace PFTWebAPI.Services;

using AutoMapper;
using BCrypt.Net;
using PFTWebAPI.Authorization;
using PFTWebAPI.Models;
using PFTWebAPI.Helpers;
using PFTWebAPI.Data;
using PFTWebAPI.Dto.Users;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;


public interface IGeneracionUsuarioService
{
    Task<Generacion_Usuario> RegisterGeneracionUsuario(RegisterGUsuariosRequest model);
    IEnumerable<Generacion_Usuario> GetGeneracionUsuarioAll();
    Generacion_Usuario GetGeneracionUsuarioById(int id);
}

public class GeneracionUsuarioService : IGeneracionUsuarioService
{
    private DataContext _context;
    private readonly IMapper _mapper;
    private readonly HttpClient _httpClient;
        private static readonly HttpClientHandler handler = new HttpClientHandler
    {
        ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
    };
    private static readonly HttpClient client2 = new HttpClient(handler);
    public GeneracionUsuarioService(
        DataContext context,
        IMapper mapper,
        HttpClient httpClient)
    {
        _context = context;
        _mapper = mapper;
        _httpClient = httpClient;

    }

public IEnumerable<Generacion_Usuario> GetGeneracionUsuarioAll()
{
    return _context.Generacion_Usuarios.ToList();
}

public Generacion_Usuario GetGeneracionUsuarioById(int id)
{
    return geGeneracionUsuario(id);
}    

private Generacion_Usuario geGeneracionUsuario(int id)
{
    var gen_user = _context.Generacion_Usuarios.Find(id);
    if (gen_user == null) throw new KeyNotFoundException("Generacion Usuario no se encontro");
    return gen_user;
}
public async Task<Generacion_Usuario> RegisterGeneracionUsuario(RegisterGUsuariosRequest model)
{
    if (_context.Generacion_Usuarios.Any(x => x.IdSolicitud == model.IdSolicitud))
        throw new AppException("Cod Afiliación '" + model.IdSolicitud + "' ya ha sido ingresado");

    var sigla = GenerarSiglasIntercaladas(model.NombreEmpresa);
    var generadosAnteriormente = _context.Generacion_Usuarios.Where(x => x.Codigo.Contains("FT" + sigla)).ToList().Count();
    var codigo = GenerarCodigo(model.NombreEmpresa, generadosAnteriormente);

    string nuevoCodigo = GenerarCodigoUnico(codigo);

    var user = _mapper.Map<Generacion_Usuario>(model);
    user.Codigo = nuevoCodigo; 
    user.Codigo = codigo;  
    _context.Generacion_Usuarios.Add(user);
    _context.SaveChanges();
 
    return user;
}

    static string GenerarCodigoUnico(string codigo)
    {
         while (ConsultaCodigoApi(codigo))
        {
            codigo = IncrementarCorrelativo(codigo);
        } 

        return codigo;
    }

    static string IncrementarCorrelativo(string codigo)
    {
        if (codigo.Length > 10)
        {
            throw new ArgumentException("El código debe tener 10 o menos caracteres");
        }

        string yy = codigo.Substring(0, 2);
        string xxxx = codigo.Substring(2, codigo.Length - 4);
        string nn = codigo.Substring(codigo.Length - 2); 

        int correlativo = int.Parse(nn);
        correlativo++;

        string nuevoNN = correlativo.ToString("D2");

        string nuevoCodigo = $"{yy}{xxxx}{nuevoNN}";

        return nuevoCodigo;
    }

   static bool ConsultaCodigoApi(string codigo)
    {
        string uri = $"https://pssftsod02:10075/B2BAPIs/svc/tradingpartners/?searchFor={codigo}";
        bool retorno = false;
        client2.DefaultRequestHeaders.Accept.Clear();
        client2.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        client2.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes("APIUSER:Peru2020$")));

        HttpResponseMessage response = client2.GetAsync(uri).Result;

    try
        {
            if (response.IsSuccessStatusCode)
            {
              retorno = true;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                Console.WriteLine("Error: Código no encontrado (404)");
            }
            else
            {
                Console.WriteLine($"Error: {response.ReasonPhrase}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception: {ex.Message}");
        } 

        return retorno;
    }    
    public string GenerarCodigo(string empresa, int numeroCodigosGenerados)
    {
        string siglas = GenerarSiglasIntercaladas(empresa);

        int correlativo = numeroCodigosGenerados + 1;

        string correlativoStr = correlativo.ToString("D2");

        string codigo = $"FT{siglas}{correlativoStr}";

        return codigo;
    }

    private string GenerarSiglasIntercaladas(string nombre)
    {
        var siglas = new System.Text.StringBuilder();

        for (int i = 0; i < nombre.Length; i += 2)
        {
            siglas.Append(nombre[i]);
        }

        var newsigla = siglas.ToString().Replace(" ", "");
        if (newsigla.Length >= 4)
        {
            newsigla = newsigla.Substring(0, 4);
        }
        else
        {
            newsigla = newsigla.PadRight(4, 'F');
        }

        return newsigla.ToUpper();
    }
   
}