import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

export interface colecction {id: string, img: string};

@Component({
  selector: 'app-dashboard-patients-carousel',
  templateUrl: './dashboard-patients-carousel.component.html',
  styleUrls: ['./dashboard-patients-carousel.component.scss']
})
export class DashboardPatientsCarouselComponent implements OnInit {

  slidesStore : colecction[] = [
    {
      id: '1',
      img: '../../../assets/images/dashboard-pacient/traumatologia.svg',
    },
    {
      id: '2',
      img: '../../../assets/images/dashboard-pacient/anatomia.svg',
    },
    {
      id: '3',
      img: '../../../assets/images/dashboard-pacient/anestesiologia.svg',
    },
    {
      id: '4',
      img: '../../../assets/images/dashboard-pacient/cardiologia.svg',
    },
    {
      id: '5',
      img: '../../../assets/images/dashboard-pacient/card-pediatrica.svg',
    },
    {
      id: '6',
      img: '../../../assets/images/dashboard-pacient/cardiovascular.svg',
    },
    {
      id: '7',
      img: '../../../assets/images/dashboard-pacient/cabeza-cuello.svg',
    },
    {
      id: '8',
      img: '../../../assets/images/dashboard-pacient/torax.svg',
    },
    {
      id: '9',
      img: '../../../assets/images/dashboard-pacient/general.svg',
    },
    {
      id: '10',
      img: '../../../assets/images/dashboard-pacient/general-oncologica.svg',
    },
  
  ]

  
  customOptions: OwlOptions = {
    loop: true,
    margin: 16,
    dots: false,
    nav: true,
    items: 4,
    navText: ['<div id="arrows" class="arrows material-icons">arrow_back_ios_new</div>', '<div id="arrows" class="arrows material-icons">arrow_forward_ios</div>'],
  }

  // customOptions: OwlOptions = {
  //   loop: true,
  //   mouseDrag: true,
  //   touchDrag: false,
  //   pullDrag: false,
  //   items: 5,
  //   dots: false,
  //   navText: ['', ''],
  //   nav: true
  // }



  constructor() { }

  ngOnInit(): void {
  }

}
