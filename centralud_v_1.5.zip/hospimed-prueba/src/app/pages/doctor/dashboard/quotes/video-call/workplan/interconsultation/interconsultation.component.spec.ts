import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InterconsultationComponent } from './interconsultation.component';

describe('InterconsultationComponent', () => {
  let component: InterconsultationComponent;
  let fixture: ComponentFixture<InterconsultationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InterconsultationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InterconsultationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
