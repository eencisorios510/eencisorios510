import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TurnScheduleComponent } from './turn-schedule.component';

describe('TurnScheduleComponent', () => {
  let component: TurnScheduleComponent;
  let fixture: ComponentFixture<TurnScheduleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TurnScheduleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TurnScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
