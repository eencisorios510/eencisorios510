import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvitationsPatientComponent } from './invitations-patient.component';

describe('InvitationsPatientComponent', () => {
  let component: InvitationsPatientComponent;
  let fixture: ComponentFixture<InvitationsPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvitationsPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvitationsPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
