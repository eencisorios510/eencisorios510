﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PFTWebAPI.Authorization;
using PFTWebAPI.Helpers;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Services;

namespace PFTWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class GeneracionUsuariosController : ControllerBase
    {
        private IGeneracionUsuarioService _generateuserService;

        public GeneracionUsuariosController(IGeneracionUsuarioService generateuserService)
        {
            _generateuserService = generateuserService;
        }


        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult RegisterGeneracionUsuario(RegisterGUsuariosRequest model)
        {
             var registeredUser = _generateuserService.RegisterGeneracionUsuario(model);
            //return Ok(new { message = "Registration successful" });

           return CreatedAtAction(nameof(GetGeneracionUsuarioById), new { id = registeredUser.Id }, registeredUser);
        }

        [AllowAnonymous]
        [HttpGet("GetGeneracionUsuarioAll")]
        public IActionResult GetGeneracionUsuarioAll()
        {
            var users = _generateuserService.GetGeneracionUsuarioAll();
            return Ok(users);
        }

        [AllowAnonymous]
        [HttpGet("GetGeneracionUsuarioById/{id}")]
        public IActionResult GetGeneracionUsuarioById(int id)
        {
            var user = _generateuserService.GetGeneracionUsuarioById(id);
            return Ok(user);
        }


    }
}
