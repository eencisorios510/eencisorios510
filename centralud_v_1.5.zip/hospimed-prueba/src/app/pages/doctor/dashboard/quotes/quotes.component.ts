import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDatepicker } from '@angular/material/datepicker';
import { OwlOptions } from 'ngx-owl-carousel-o';

// the `default as` syntax.
// import * as _moment from 'moment';
// tslint:disable-next-line:no-duplicate-imports
// import {default as _rollupMoment, Moment} from 'moment';

@Component({
  selector: 'app-quotes',
  templateUrl: './quotes.component.html',
  styleUrls: ['./quotes.component.scss']
})
export class QuotesComponent implements OnInit {

  @ViewChild('picker') datePicker: MatDatepicker<any>;

  showFilters: boolean = false;

  months = [
    { month: 'Marzo', year: '2021' },
    { month: 'Febrero', year: '2021' },
    { month: 'Enero', year: '2021' },
    { month: 'Diciembre', year: '2020' },
    { month: 'Novimebre', year: '2020' },
    { month: 'Octubre', year: '2020' },
    { month: 'Setiembre', year: '2020' },
    { month: 'Agosto', year: '2020' },
    { month: 'Julio', year: '2020' },
    { month: 'Junio', year: '2020' },
    { month: 'Mayo', year: '2020' },
    { month: 'Abril', year: '2020' },
    { month: 'Marzo', year: '2020' },
    { month: 'Febrero', year: '2020' },
    { month: 'Enero', year: '2020' },
  ];

  currentMonth: number = 0;

  dates = [
    { prettyDate: 'Lun 1', date: '01-01-2021' },
    { prettyDate: 'Mar 2', date: '02-01-2021' },
    { prettyDate: 'Mié 3', date: '03-01-2021' },
    { prettyDate: 'Jue 4', date: '04-01-2021' },
    { prettyDate: 'Vie 5', date: '05-01-2021' },
    { prettyDate: 'Sáb 6', date: '06-01-2021' },
    { prettyDate: 'Dom 7', date: '07-01-2021' },
    { prettyDate: 'Lun 8', date: '08-01-2021' },
    { prettyDate: 'Mar 9', date: '09-01-2021' },
    { prettyDate: 'Mié 10', date: '10-01-2021' },
    { prettyDate: 'Jue 11', date: '11-01-2021' },
    { prettyDate: 'Vie 12', date: '12-01-2021' },
    { prettyDate: 'Sáb 13', date: '13-01-2021' },
    { prettyDate: 'Dom 14', date: '14-01-2021' },
    { prettyDate: 'Lun 15', date: '15-01-2021' },
    { prettyDate: 'Mar 16', date: '16-01-2021' },
    { prettyDate: 'Mié 17', date: '17-01-2021' },
    { prettyDate: 'Jue 18', date: '18-01-2021' },
    { prettyDate: 'Vie 19', date: '19-01-2021' },
    { prettyDate: 'Sáb 20', date: '20-01-2021' },
    { prettyDate: 'Dom 21', date: '21-01-2021' },
    { prettyDate: 'Lun 22', date: '22-01-2021' },
    { prettyDate: 'Mar 23', date: '23-01-2021' },
    { prettyDate: 'Mié 24', date: '24-01-2021' },
    { prettyDate: 'Jue 25', date: '25-01-2021' },
    { prettyDate: 'Vie 26', date: '26-01-2021' },
    { prettyDate: 'Sáb 27', date: '27-01-2021' },
    { prettyDate: 'Dom 28', date: '28-01-2021' },
    { prettyDate: 'Lun 29', date: '29-01-2021' },
    { prettyDate: 'Mar 30', date: '30-01-2021' },
  ];

  currentDate: string = '01-01-2021';

  quotes = [
    { id: 1, canCall: true, chatMessages: [] },
    { id: 2, canCall: false, chatMessages: [1, 1, 1, 1] },
    { id: 3, canCall: false, chatMessages: [] },
    { id: 4, canCall: false, chatMessages: [] },
    { id: 5, canCall: true, chatMessages: [1] },
    { id: 6, canCall: true, chatMessages: [] },
    { id: 7, canCall: false, chatMessages: [1, 1] },
    { id: 8, canCall: false, chatMessages: [] },
  ];

  selectedQuote: Number = 1;

  sliderOptions: OwlOptions = {
    loop: false,
    dots: false,
    items: 7,
    nav: true,
    navText: [ '<div class="mat-icon notranslate material-icons mat-icon-no-color">navigate_before</div>', '<div class="mat-icon notranslate material-icons mat-icon-no-color">navigate_next</div>' ]
  }

  constructor() { }

  ngOnInit(): void {
  }

  updateSelectedQuote(quoteId): void {
    this.selectedQuote = quoteId;
    // Cargar contenido de la cita seleccionada en panel derecho
  }

  // ngAfterViewInit(): void {
  //   const BACK_BUTTON = document.querySelector('.mat-calendar-previous-button');
  //   const FORWARD_BUTTON = document.querySelector('.mat-calendar-next-button');
  //   if (BACK_BUTTON) {
  //     this.renderer.listen(BACK_BUTTON, 'click', () => {
  //       console.log(this.dateAdapter.today());
  //       if (this.datePicker.getMonth() === 0) {
  //         this.datePicker.setFullYear(this.datePicker.getFullYear() - 1);
  //         this.datePicker.setMonth(11);
  //       } else {
  //         this.datePicker.;

  //         this.datePicker.setMonth(this.datePicker.getMonth() - 1);
  //       }
  //     });
  //   }
  //   if (FORWARD_BUTTON) {
  //     this.renderer.listen(FORWARD_BUTTON, 'click', () => {
  //       if (this.datePicker.getMonth() === 11) {
  //         this.datePicker.setFullYear(this.datePicker.getFullYear() + 1);
  //         this.datePicker.setMonth(0);
  //       } else {
  //         this.datePicker.setMonth(this.datePicker.getMonth() + 1);
  //       }
  //     });
  //   }
  // }

  closeDatePicker(event) {
    console.log('closeDatePicker() event: ', event);
    this.datePicker.close();
    // this.pickerDate = moment(event).format('YYYY-MM');
  }
  // date = new FormControl(moment());

  // chosenYearHandler(normalizedYear: Moment) {
  //   const ctrlValue = this.date.value;
  //   ctrlValue.year(normalizedYear.year());
  //   this.date.setValue(ctrlValue);
  // }

  // chosenMonthHandler(normalizedMonth: Moment, datepicker: MatDatepicker<Moment>) {
  //   const ctrlValue = this.date.value;
  //   ctrlValue.month(normalizedMonth.month());
  //   this.date.setValue(ctrlValue);
  //   datepicker.close();
  // }
}
