using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PFTWebAPI.Authorization;
using PFTWebAPI.Data;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Services;
using System.DirectoryServices.AccountManagement;

namespace PFTWebAPI.Controllers
{

[Authorize]
[ApiController]
[Route("[controller]")]
public class SolicitudesController : ControllerBase
{
    private readonly ISolicitudService _afiliacionService;
    private readonly IMapper _mapper;
    private readonly DataContext _context;
    private readonly IEstadoService _estadoService;

    public SolicitudesController(ISolicitudService afiliacionService
    , IMapper mapper
    ,DataContext context
    ,IEstadoService estadoService)
    {
        _afiliacionService = afiliacionService;
        _mapper = mapper;
        _context = context;
        _estadoService = estadoService;
    }

    [AllowAnonymous]
    [HttpPost("register")]
    public IActionResult Register([FromForm] SolicitudAddRequest model)
    {
        var afiliacion = _afiliacionService.Register(model);
        //return Ok(new { message = "Registro exitoso" });
        return CreatedAtAction(nameof(GetAfilicacionById), new { id = afiliacion.Id }, afiliacion);
    }

    [AllowAnonymous]
    [HttpGet("getprueba")]
    public async Task<IActionResult> get()
    {
        return Ok("Hola mundo");
    } 

    [AllowAnonymous]
    [HttpGet("GetSolicitudesAll")]
    public IActionResult GetSolicitudesAll([FromQuery] int page = 1, [FromQuery] int pageSize = 10, [FromQuery] string filter = "")
    {
        var afiliacion = _afiliacionService.GetSolicitudesAll(page, pageSize, filter);
        return Ok(afiliacion);
    }

    [AllowAnonymous]
    [HttpGet("GetAfilicacionById/{id}")]
    public async Task<IActionResult> GetAfilicacionById(int id)
    {
        try
        {
            var afiliacion = await _afiliacionService.GetSolicitudDetalleAsync(id);
            if (afiliacion == null)
            {
                return NotFound();
            }
            return Ok(afiliacion);
        }
        catch (Exception ex)
        {
            // Log the exception (ex) here
            return StatusCode(500, "Internal server error");
        }
    }


    [AllowAnonymous]
    [HttpPut("{id}")]
    public IActionResult Update(int id, SolicitudUpdateRequest model)
    {
        _afiliacionService.Update(id, model);
        return Ok(new { message = "Afiliación actualizada exitosamente" });
    }

    [AllowAnonymous]
    [HttpDelete("{id}")]
    public IActionResult Delete(int id)
    {
        _afiliacionService.Delete(id);
        return Ok(new { message = "Afiliación eliminada exitosamente" });
    }

    [AllowAnonymous]
    [HttpGet("GetAreaCombo")]
    public IActionResult GetAreaCombo()
    {
        var area = _afiliacionService.GetAreaCombo();
        return Ok(area);
    }  

    [AllowAnonymous]
    [HttpGet("GetRolCombo")]
    public IActionResult GetGetRolComboAll()
    {
        var rol = _afiliacionService.GetRolCombo();
        return Ok(rol);
    } 

    [AllowAnonymous]
    [HttpGet("GetProductoCombo")]
    public IActionResult GetProductoCombo()
    {
        var producto = _afiliacionService.GetProductoCombo();
        return Ok(producto);
    } 

    [AllowAnonymous]
    [HttpGet("GetAplicacionCombo")]
    public IActionResult GetAplicacionCombo()
    {
        var app = _afiliacionService.GetAplicacionCombo();
        return Ok(app);
    }          

    [AllowAnonymous]
    [HttpGet("GetEmpresaCombo")]
    public IActionResult GetEmpresaCombo()
    {
        var app = _afiliacionService.GetEmpresaCombo();
        return Ok(app);
    }   

    [AllowAnonymous]
    [HttpGet("getButonsformAfliacionesDetail")]
    public IActionResult GetFormDetail(int rolId, int estadoId)
    {
        var result = _estadoService.GetFormDetail(rolId, estadoId);

        return Ok(result);
    }     
 
    [AllowAnonymous]
    [HttpPost("UpdateDatosProducto/{id}")]
    public IActionResult UpdateDatosProducto(int id, [FromBody] string datosProducto)
    {
        _afiliacionService.RegisUpdateDatosProductoter(id, datosProducto);
        return Ok(new { message = "Afiliación actualizada exitosamente" });
    }



    
         
}
}