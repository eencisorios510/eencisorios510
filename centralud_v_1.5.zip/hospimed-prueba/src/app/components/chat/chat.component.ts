import { Component, Input, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnInit {

  @Input() isOnModal: boolean = false;

  @ViewChild('chatContent') chatContent;

  currentUser = {
    avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
    fullName: 'Rosa Morales Aspillaga'
  }

  newMessage: string = '';

  public chatMessages = [
    {
      user: {
        avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
        fullName: 'Maricielo López Paez'
      },
      message_time: '11:30 am',
      message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique recusandae numquam ullam',
      status: 'done_all',
      its_me: false,
      kind: 'text',
      file: null
    },
    {
      user: {
        avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
        fullName: 'Rosa Morales Aspillaga'
      },
      message_time: '11:40 am',
      message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique recusandae numquam ullam hic aut nostrum at voluptate laudantium magnam eveniet fugit alias exercitationem neque, totam tempore enim facilis! Laborum, iusto.',
      status: 'done',
      its_me: true,
      kind: 'text',
      file: null
    }
  ];

  constructor() { }

  ngOnInit(): void {
    setTimeout(() => {
      if (this.chatContent) {
        this.chatContent.nativeElement.scrollTop = this.chatContent.nativeElement.scrollHeight;
      }
    }, 100);
  }

  upload(file:any): void {
    const fileName = file.target.files[0].name;

    this.chatMessages.push({
      user: this.currentUser,
      message_time: '11:40 am',
      message: 'es un mensajito-',
      status: 'done',
      kind: 'file',
      file: {
        name: fileName,
        objectURL: URL.createObjectURL(file.target.files[0])
      },
      its_me: true
    });

    setTimeout(() => {
      this.chatContent.nativeElement.scrollTop = this.chatContent.nativeElement.scrollHeight;
    }, 100);
  }

  appendNewMessage(): void {
    this.chatMessages.push({
      user: this.currentUser,
      message_time: '11:40 am',
      message: this.newMessage,
      status: 'done',
      kind: 'text',
      file: null,
      its_me: true
    });

    this.newMessage = '';

    setTimeout(() => {
      this.chatContent.nativeElement.scrollTop = this.chatContent.nativeElement.scrollHeight;
    }, 100);
  }

}
