namespace PFTWebAPI.Dto.AtencionSolicitud;
using System.ComponentModel.DataAnnotations;

public class RegisterRequestAtencion
{
        public int IdEstado { get; set; }
        public int IdAfilicacion { get; set; }
        public string usuario { get; set; }
        public string Boton { get; set; }
        public string? Comentario { get; set; }
        public int IdEstadoSolicitud { get; set; }
}