import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-third-group-cards',
  templateUrl: './third-group-cards.component.html',
  styleUrls: ['./third-group-cards.component.scss']
})
export class ThirdGroupCardsComponent implements OnInit {

  @Input() doctorThird: {id: number, name: string, link: any, section:string, status: string, display: string, time: string, date: string, state: string, chat: boolean, dates: boolean};

  @Input() selected: boolean = false;

  @Output() selectDoctorEvent = new EventEmitter<number>();
  @Output() clickShowChat = new EventEmitter<boolean>();
  @Output() clickShowDates = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
  }

}
