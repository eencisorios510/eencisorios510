import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class MessagesComponent implements OnInit {

  newMessage: string = '';

  public chatMessages = [
    {
      user: {
        avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
        fullName: 'Dr. José Huerta Pérez'
      },
      message_time: '11:30 am',
      message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique recusandae numquam ullam',
      status: 'done_all',
      its_me: false,
    },
    {
      user: {
        avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
        fullName: 'Rosa Morales Aspillaga'
      },
      message_time: '11:40 am',
      message: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Similique recusandae numquam ullam hic aut nostrum at voluptate laudantium magnam eveniet fugit alias exercitationem neque, totam tempore enim facilis! Laborum, iusto.',
      status: 'done',
      its_me: true
    }
  ];


  constructor() { }

  ngOnInit(): void {
  }

  appendNewMessage(): void {
    this.chatMessages.push({
      user: {
        avatar: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
        fullName: 'Rosa Morales Aspillaga'
      },
      message_time: '11:40 am',
      message: this.newMessage,
      status: 'done',
      its_me: true
    });

    this.newMessage = '';
  }

}
