using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace PFTWebAPI.Models
{
    public class HistorialAtencion
    {
        public int Id { get; set; }

        public int IdEstado { get; set; }

        public int IdAfilicacion { get; set; }

        [Column(TypeName = "datetime2")]
        public DateTime fecha_ingresado { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public string usuario { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        public string? Comentario { get; set; }
        
        public int? IdEstadoOrigen { get; set; }
    }
}


