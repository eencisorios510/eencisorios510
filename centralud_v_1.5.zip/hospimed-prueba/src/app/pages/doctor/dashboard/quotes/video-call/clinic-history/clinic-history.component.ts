import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EnterPinComponent } from './enter-pin/enter-pin.component';

@Component({
  selector: 'app-clinic-history',
  templateUrl: './clinic-history.component.html',
  styleUrls: ['./clinic-history.component.scss']
})
export class ClinicHistoryComponent implements OnInit {

  showOrders: boolean = false;

  constructor(public dialogEnterPin: MatDialog) { }

  openDialogEnterPin() {
    const dialogRef = this.dialogEnterPin.open(EnterPinComponent);

    dialogRef.afterClosed().subscribe(result => {
      this.showOrders = result;
    });
  }

  ngOnInit(): void {
  }

}
