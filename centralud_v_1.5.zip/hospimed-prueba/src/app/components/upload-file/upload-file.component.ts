import { Component, HostListener, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss']
})
export class UploadFileComponent implements OnInit {

  @Input() multiple: boolean = false;

  @ViewChild('dropZone') dropZone;

  files: any = [];

  uploadFileForm = new FormGroup({
    fileName:new FormControl(null)
  })

  constructor() { }

  ngOnInit(): void {
  }

  onFileDropped($event) {
    if (this.multiple) {
      this.files.push(...$event);
      console.log(this.files);
    } else {
      this.files = $event;
      console.log(this.files);
    }
  }

  upload(file:any): void {
    const newFiles = Array.from(file.target.files);

    if (this.multiple) {
      this.files.push(...newFiles);
      console.log(this.files);
    } else {
      this.files = newFiles;
      console.log(this.files);
    }
  }

  removeFile(index): void {
    this.files.splice(index, 1);
    // delete this.files[index];
  }
}
