namespace PFTWebAPI.Dto;

   public class ProductoGetDto
    {
        public int Id { get; set; } = 0;
        public string Nombre { get; set; } = string.Empty;
        public string ContratoJson { get; set; } = string.Empty;
    }