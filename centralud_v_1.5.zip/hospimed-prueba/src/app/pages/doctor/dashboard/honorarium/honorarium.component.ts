import { AfterViewInit, Component, ViewChild } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  hour: string;
  date: string;
  time: string;
  name: string;
  price: string;
  desc: string;
  total: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {date: '20/05/2021', hour: '19:00', time: '15”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '25”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '35”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '15”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '25”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '35”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '15”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '25”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '35”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '15”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '25”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'},
  {date: '20/05/2021', hour: '19:00', time: '35”', name: 'Susana Sánchez Palma', price: '36.50', desc: '2.95', total: '33.95'}
];

@Component({
  selector: 'app-honorarium',
  templateUrl: './honorarium.component.html',
  styleUrls: ['./honorarium.component.scss'],
})
export class HonorariumComponent implements AfterViewInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  displayedColumns: string[] = ['date', 'hour', 'time', 'name', 'price', 'desc', 'total'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }

  constructor() { }

  ngOnInit(): void {
    this.paginator._intl.itemsPerPageLabel="Filas por Página";
  }

}
