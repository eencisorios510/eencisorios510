import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-doctor-card',
  templateUrl: './doctor-card.component.html',
  styleUrls: ['./doctor-card.component.scss']
})
export class DoctorCardComponent implements OnInit {

  @Input() doctor: {id: number, name: string, status: string};
  @Input() selected: boolean = false;

  @Output() selectDoctorEvent = new EventEmitter<number>();

  constructor() { }

  ngOnInit(): void {
  }

}
