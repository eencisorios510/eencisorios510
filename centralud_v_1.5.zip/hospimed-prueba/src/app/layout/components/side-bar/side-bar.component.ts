import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.scss']
})
export class SideBarComponent implements OnInit {

  @Input() menuItems: Array<{ icon: String, name: String }>;
  @Input() headerAnnouncement: boolean;

  currentRoute: string = '';

  constructor(private router: Router) {
    router.events.subscribe((val: any) => {
      this.currentRoute = val.url;
    })
  }

  ngOnInit(): void {
  }

}
