﻿
                    import { Component, OnInit, inject } from '@angular/core';
                    import { Router, ActivatedRoute } from '@angular/router';
                    import { FormGroup, Validators } from '@angular/forms';
                    import { first } from 'rxjs/operators';
                    import { FormlyFieldConfig, FormlyFormOptions } from '@ngx-formly/core';
                    import { AfiliacionService, AlertService, ProductoService } from '@app/_services';
                    
                    @Component({ templateUrl: 'add-producto-afiliacion.component.html' })
                    export class AddProductoAfiliacionComponent implements OnInit {
                      id: string;
                      form = new FormGroup({});
                      model: any = {};
                      options: FormlyFormOptions = {};
                      fields: FormlyFieldConfig[] = [];
                      private readonly productoService = inject(ProductoService);
                      private readonly afiliacionService = inject(AfiliacionService);
                    
                      constructor(
                        private route: ActivatedRoute,
                        private alertService: AlertService,
                      ) {}
                    
                      ngOnInit() {
                        this.id = this.route.snapshot.params['id'];  
                        this.afiliacionService.getAfiliacionById(this.id)
                        .pipe(first())
                        .subscribe(x => {
                            this.getProducto(x.productoId);
                        });
                      }
                    
                      getProducto(productoId: string) {
                        this.productoService.getProductoById(productoId)
                        .pipe(first())
                        .subscribe({
                          next: response => {
                            this.fields = this.transformSchemaToFormlyFields(JSON.parse(response.contratoJson));
                          },
                          error: error => {
                            this.alertService.error(error);
                          }
                        });
                      }
                    
                      transformSchemaToFormlyFields(schema: any): FormlyFieldConfig[] {
                        const fields: FormlyFieldConfig[] = [];
                    
                        for (const key in schema.properties) {
                          if (schema.properties.hasOwnProperty(key)) {
                            const property = schema.properties[key];
                            const formattedLabel = this.formatLabel(key);
                            const field: FormlyFieldConfig = {
                              key: key,
                              type: this.getFieldType(property),
                              props: {
                                label: formattedLabel,
                                placeholder: property.description || '',
                                required: schema.required.includes(key),
                              },
                              validators: {
                                validation: []
                              }
                            };
                    
                            if (property.enum) {
                              field.type = 'select';
                              field.props.options = property.enum.map((option: string) => ({ label: option, value: option }));
                            }
                    
                            if (property.format === 'email') {
                              field.validators.validation.push(Validators.email);
                            }
                    
                            fields.push(field);
                          }
                        }
                    
                        return fields;
                      }
                    
                      formatLabel(label: string): string {
                        const formattedLabel = label.replace(/_/g, ' ')
                                                    .replace(/\b\w/g, char => char.toUpperCase());
                        return `${formattedLabel}`;
                      }
                    
                      getFieldType(property: any): string {
                        switch (property.type) {
                          case 'string':
                            return 'input';
                          case 'number':
                            return 'input';
                          case 'boolean':
                            return 'checkbox';
                          case 'array':
                            return 'input'; /* repeat */
                          default:
                            return 'input';
                        }
                      }
                    
                      onSubmit() {
                        if (this.form.valid) {
                          console.log(this.model);
                    
                          this.afiliacionService.updateDatosProducto(this.id, this.model).subscribe(
                            response => {
                              console.log('Datos guardados exitosamente', response);
                            },
                            error => {
                              console.error('Error al guardar los datos', error);
                            }
                          );
                        }
                      }
                    }