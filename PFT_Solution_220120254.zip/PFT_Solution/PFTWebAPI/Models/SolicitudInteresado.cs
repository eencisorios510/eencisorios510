namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
    public class SolicitudInteresado
    {
        public int Id { get; set; }
        public int SolicitudId { get; set; }
        public int? AplicacionId { get; set; }
        public int? UnidadId { get; set; }
        public bool EsResponsable { get; set; }
    }