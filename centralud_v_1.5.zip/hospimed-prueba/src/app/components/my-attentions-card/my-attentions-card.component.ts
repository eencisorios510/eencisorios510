import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-my-attentions-card',
  templateUrl: './my-attentions-card.component.html',
  styleUrls: ['./my-attentions-card.component.scss']
})
export class MyAttentionsCardComponent implements OnInit {


  @Input() doctor: {id: number, name: string, link: any, section:string, status: string, display: string, time: string, date: string, state: string, chat: boolean, payment: boolean};
  
  @Input() selected: boolean = false;

  @Output() selectDoctorEvent = new EventEmitter<number>();
  @Output() clickShowChat = new EventEmitter<boolean>();
  @Output() clickShowPayment = new EventEmitter<boolean>(); 

  constructor() { }

  ngOnInit(): void {
  }

}
