import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyPlanCardComponent } from './yearly-plan-card.component';

describe('YearlyPlanCardComponent', () => {
  let component: YearlyPlanCardComponent;
  let fixture: ComponentFixture<YearlyPlanCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearlyPlanCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyPlanCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
