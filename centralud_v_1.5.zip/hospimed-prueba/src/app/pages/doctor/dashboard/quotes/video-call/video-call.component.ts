import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-video-call',
  templateUrl: './video-call.component.html',
  styleUrls: ['./video-call.component.scss']
})
export class VideoCallComponent implements OnInit {

  started: boolean = false;

  showHistorialModal: boolean = false;

  showChatModal: boolean = false;

  showAuxiliaryExamsModal: boolean = false;
  showRecipeModal: boolean = false;
  showInterconsultationModal: boolean = false;
  showMedicalBoardModal: boolean = false;
  showNextAppointmentModal: boolean = false;
  showMedicalRestModal: boolean = false;

  clickShowAuxiliaryExamsModal(): void{
    this.showAuxiliaryExamsModal = true;
    this.showRecipeModal = false;
    this.showInterconsultationModal = false;
    this.showMedicalBoardModal = false;
    this.showNextAppointmentModal = false;
    this.showMedicalRestModal = false;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  clickShowRecipeModal(): void{
    this.showAuxiliaryExamsModal = false;
    this.showRecipeModal = true;
    this.showInterconsultationModal = false;
    this.showMedicalBoardModal = false;
    this.showNextAppointmentModal = false;
    this.showMedicalRestModal = false;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  clickShowInterconsultationModal(): void{
    this.showAuxiliaryExamsModal = false;
    this.showRecipeModal = false;
    this.showInterconsultationModal = true;
    this.showMedicalBoardModal = false;
    this.showNextAppointmentModal = false;
    this.showMedicalRestModal = false;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  clickshowMedicalBoardModal(): void{
    this.showAuxiliaryExamsModal = false;
    this.showRecipeModal = false;
    this.showInterconsultationModal = false;
    this.showMedicalBoardModal = true;
    this.showNextAppointmentModal = false;
    this.showMedicalRestModal = false;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  clickShowNextAppointmentModal(): void{
    this.showAuxiliaryExamsModal = false;
    this.showRecipeModal = false;
    this.showInterconsultationModal = false;
    this.showMedicalBoardModal = false;
    this.showNextAppointmentModal = true;
    this.showMedicalRestModal = false;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  clickShowMedicalRestModal(): void{
    this.showAuxiliaryExamsModal = false;
    this.showRecipeModal = false;
    this.showInterconsultationModal = false;
    this.showMedicalBoardModal = false;
    this.showNextAppointmentModal = false;
    this.showMedicalRestModal = true;
    this.showHistorialModal = false;
    this.showChatModal = false;
  }

  showHCH: boolean = false;

  diagnosticos: number[] = [1];

  tiempoEnfermedad: number = 0;

  separatorKeysCodes: number[] = [ENTER, COMMA];

  myControl = new FormControl();
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  addDiagnostico(): void {
    this.diagnosticos.push(1);
  }

  updateShowHCH(event): void {
    this.showHCH = event;
    this.showChatModal = false;
  }

  constructor() { }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }

  updateStarted(value): void {
    this.started = value;
  }
}
