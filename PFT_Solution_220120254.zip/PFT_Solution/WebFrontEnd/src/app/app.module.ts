﻿import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { LoaderModule } from '@bcp/ng-ui-components';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { AppComponent } from './app.component';
import { AlertComponent } from './_components';
import { HomeComponent } from './home';
import { CommonModule } from '@angular/common';
import { BcpLayoutModule, BcpNotificationDropdownModule, BcpTitleModule } from '@bcp/ng-ui-components';
import { FormlyModule } from '@ngx-formly/core';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';


@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        AppRoutingModule,
        LoaderModule,
        BcpLayoutModule,
        BcpNotificationDropdownModule,
        BcpTitleModule,
        //LoaderModule,
        CommonModule,
        FormlyModule.forRoot(),
        FormlyBootstrapModule,
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    bootstrap: [AppComponent]
})
export class AppModule { };