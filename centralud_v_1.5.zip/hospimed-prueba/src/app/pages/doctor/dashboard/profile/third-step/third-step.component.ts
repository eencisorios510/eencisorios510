import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-third-step',
  templateUrl: './third-step.component.html',
  styleUrls: ['./third-step.component.scss']
})
export class ThirdStepComponent implements OnInit {

  quoteTime: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

}
