import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.scss']
})
export class CounterComponent implements OnInit {

  @Input() value: number;
  @Input() step: number = 10;
  @Input() min: number = 0;
  @Input() max: number;
  @Input() suffix: string;
  @Input() type: string = "square";
  @Input() disabled: boolean = false;

  @Output() valueChange = new EventEmitter<number>();

  constructor() { }

  ngOnInit(): void {
  }

  plus () {
    if (this.max && this.value >= this.max) return;
    this.value += this.step;
    this.valueChange.emit(this.value);
  }

  minus () {
    if (this.min > (this.value - this.step)) return;
    this.value -= this.step;
    this.valueChange.emit(this.value);
  }
}
