import { _DisposeViewRepeaterStrategy } from '@angular/cdk/collections';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';

import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import {MatChipInputEvent} from '@angular/material/chips';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';


// export interface Recipe {
//   name: string;
// }

// export interface Doctor {
//   item: string;
// }

@Component({
  selector: 'app-recipe',
  templateUrl: './recipe.component.html',
  styleUrls: ['./recipe.component.scss']
})
export class RecipeComponent implements OnInit {

  showRecipe: boolean = false;
  showMagistral: boolean = false;
  showTable: boolean;
  showCard: boolean;

  createRecipe(): void {
    this.showRecipe = !this.showRecipe;
    this.showTable = false;
  }

  addRecipe(): void {
    this.showRecipe = !this.showRecipe;
    this.showTable = true;
  }

  createMagistral(): void {
    this.showMagistral = !this.showMagistral;
    this.showCard = false;
  }

  addMagistral(): void {
    this.showMagistral = !this.showMagistral;
    this.showCard = true;
  }

  @ViewChild('doctorInput') doctorInput: ElementRef<HTMLInputElement>;
  @ViewChild('recipeInput') recipeInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  doctorCtrl = new FormControl();
  doctores: string[] = ['Pomada'];
  allDoctores: string[] = ['Pomada1','Pomada2','Pomada3'];
  filteredDoctores: Observable<string[]>;

  cantidad: string = '0';
  dosis: string = '1 tableta';
  frecuencia: string = 'D/A/C';
  via: string = 'VO';
  duracion: string = '0';
  indicaciones: string = 'Aplicar después del baño';
  unidad: string = '10%';

  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  recipeCtrl = new FormControl();
  filteredRecipes: Observable<string[]>;
  recipes: string[] = ['Metformina COMP 850 mg Diaformina Tableta'];
  allRecipes: string[] = ['Metformina COMP 850 mg Diaformina Tableta','Paracetamol 500g','Dioxaflex Tableta'];
  

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    if (input) {
      input.value = '';
    }

    this.recipeCtrl.setValue(null);
  }

  remove(recipe: string): void {
    const index = this.recipes.indexOf(recipe);

    if (index >= 0) {
      this.recipes.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.recipes.push(event.option.viewValue);
    this.recipeInput.nativeElement.value = '';
    this.recipeCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allRecipes.filter(recipe => recipe.toLowerCase().indexOf(filterValue) === 0);
  }

  private _filterDoc(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allDoctores.filter(medic => medic.toLowerCase().indexOf(filterValue) === 0);
  }

  addDoctor(event: MatChipInputEvent, kind: string): void {
    const input = event.input;
    const value = event.value;

    if (input) {
      input.value = '';
    }
  }

  removeDoctor(doctor: string, kind: string): void {
    let index;

    switch (kind) {
      case 'doctores':
        index = this.doctores.indexOf(doctor);
        if (index >= 0) this.doctores.splice(index, 1);
        break;

      default:
        break;
    }
  }

  selectedDoctor(event: MatAutocompleteSelectedEvent): void {
    this.doctores.push(event.option.viewValue);
    this.doctorInput.nativeElement.value = '';
    this.doctorCtrl.setValue(null);
  }

  showAnnouncement: boolean = true;

  medicos: Array<number> = [1];

  addMedico() {
    this.medicos.push(1);
  }

  removeMedico() {
    this.medicos.splice(0, 1);
  }

  constructor() {
    this.filteredRecipes = this.recipeCtrl.valueChanges.pipe(
      startWith(null),
      map((medic: string | null) => medic ? this._filter(medic) : this.allRecipes.slice()));

      this.filteredDoctores = this.doctorCtrl.valueChanges.pipe(
        startWith(null),
        map((medic: string | null) => medic ? this._filterDoc(medic) : this.allDoctores.slice()));
   }

  ngOnInit(): void {
  }

  closeAnnouncement(): void {
    this.showAnnouncement = false;
  }

}
