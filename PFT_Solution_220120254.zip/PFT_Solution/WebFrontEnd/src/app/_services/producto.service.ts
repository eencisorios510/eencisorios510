import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Afiliacion,AfiliacionById, AfiliacionCombo,AfiliacionDetailButon, ProductoById } from '@app/_models';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ProductoService {
    constructor(private http: HttpClient) {}

    getProductoById(id: string) {
        return this.http.get<ProductoById>(`${environment.apiUrl}/Producto/${id}`);
    }

   
}