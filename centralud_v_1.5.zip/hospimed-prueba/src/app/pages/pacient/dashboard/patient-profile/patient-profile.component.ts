import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-profile',
  templateUrl: './patient-profile.component.html',
  styleUrls: ['./patient-profile.component.scss']
})
export class PatientProfileComponent implements OnInit {

  showSaveChild: boolean = true;

  showRegistry: boolean;

  showEditProfile: boolean = false;

  reconocimientos: Array<number> = [1];

  ruc: boolean;

  constructor() { }

  ngOnInit(): void {
  }

  addReconocimiento () {
    this.reconocimientos.push(1);
  }

  removeReconocimiento () {
    this.reconocimientos.splice(0, 1);
  }

  updateSaveChild(){
    this.showSaveChild = true;
  }

}
