    namespace PFTWebAPI.Dto;

public class ApiResponse<T>
{
    public T Data { get; set; }
    public int TotalRecords { get; set; }

    public ApiResponse(T data, int totalRecords)
    {
        Data = data;
        TotalRecords = totalRecords;
    }
}