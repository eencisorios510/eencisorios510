namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
public class Area
{
    public int Id { get; set; }
    [Column(TypeName = "nvarchar(250)")]
    public string Nombre { get; set; }
    public ICollection<Solicitud> Solicitudes { get; set; }
}
       