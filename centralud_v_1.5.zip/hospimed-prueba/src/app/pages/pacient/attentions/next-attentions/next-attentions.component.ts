import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-next-attentions',
  templateUrl: './next-attentions.component.html',
  styleUrls: ['./next-attentions.component.scss']
})
export class NextAttentionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
