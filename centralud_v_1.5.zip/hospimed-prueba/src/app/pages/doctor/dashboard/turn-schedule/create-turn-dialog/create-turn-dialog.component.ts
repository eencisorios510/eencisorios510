import { Component, Inject, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

@Component({
  selector: 'app-create-turn-dialog',
  templateUrl: './create-turn-dialog.component.html',
  styleUrls: ['./create-turn-dialog.component.scss']
})
export class CreateTurnDialogComponent implements OnInit {

  dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

  monthNames = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];

  selectedDays = [];

  selectedHours = [{ startTime: '', endTime: '' }];

  untilDate: string = '';

  customUntilDate: string = '';

  hours: any[] = [
    { value: '12:30', viewValue: '12:30pm' },
    { value: '13:30', viewValue: '1:30pm' },
    { value: '14:40', viewValue: '2:30pm' },
  ];

  days: any[] = [
    { value: 1, viewValue: 'L' },
    { value: 2, viewValue: 'M' },
    { value: 3, viewValue: 'X' },
    { value: 4, viewValue: 'J' },
    { value: 5, viewValue: 'V' },
    { value: 6, viewValue: 'S' },
    { value: 0, viewValue: 'D' },
  ]

  constructor(
    public dialogRef: MatDialogRef<CreateTurnDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {}

  onNoClick(): void {
    this.dialogRef.close();
  }

  toggleDay(day):void {
    const selectedDay = this.selectedDays.findIndex(item => item === day);

    if (selectedDay === -1) {
      this.selectedDays.push(day);
    } else {
      this.selectedDays.splice(selectedDay, 1);
    }
  }

  addSelectedHour():void {
    this.selectedHours.push({ startTime: '', endTime: '' });
  }

  removeSelectedHour():void {
    this.selectedHours.splice(0, 1);
  }
  addTurns():void {
    const data = [];

    const untilDate = this.untilDate === '1' ? 'Fin de mes' : this.customUntilDate;

    if ( this.selectedDays.length > 0 ) {
      this.selectedDays.forEach(day => {
        data.push({
          day,
          untilDate,
          hours: this.selectedHours
        });
      });
    }

    console.log('addTurns() data: ', data);

    this.dialogRef.close(data);
  }

  untilDateChanged(value): void {
    this.untilDate = value;
    this.customUntilDate = '';
  }

  ngOnInit(): void {
  }

}
