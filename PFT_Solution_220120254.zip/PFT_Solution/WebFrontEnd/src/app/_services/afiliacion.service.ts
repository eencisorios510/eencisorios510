import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '@environments/environment';
import { Afiliacion,AfiliacionById, AfiliacionCombo,AfiliacionDetailButon } from '@app/_models';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AfiliacionService {
    constructor(private http: HttpClient) {}

    registerAfiliacion(afiliacion: FormData) {
        console.log('afiliacion')
        console.log(afiliacion)
        return this.http.post(`${environment.apiUrl}/Solicitudes/register`, afiliacion);
    }

   
    getAllAfiliacion(page: number, pageSize: number, filter: string = ''): Observable<any> {
        let params = new HttpParams()
        .set('page', page.toString())
        .set('pageSize', pageSize.toString());
        if (filter) {
            params = params.set('filter', filter);
        }
        return this.http.get(`${environment.apiUrl}/Solicitudes/GetSolicitudesAll`, { params });
    }  
    

    getAfiliacionById(id: string) {
        return this.http.get<AfiliacionById>(`${environment.apiUrl}/Solicitudes/GetAfilicacionById/${id}`);
    }

    update(id: string, params: any) {
        return this.http.put(`${environment.apiUrl}/Solicitudes/${id}`, params);
    }

    deleteAfiliacion(id: string) {
        return this.http.delete(`${environment.apiUrl}/Solicitudes/${id}`);
    }

    GetAplicacionCombo() {
        return this.http.get<AfiliacionCombo[]>(`${environment.apiUrl}/Solicitudes/GetAplicacionCombo`);
    }

    GetProductoCombo() {
        return this.http.get<AfiliacionCombo[]>(`${environment.apiUrl}/Solicitudes/GetProductoCombo`);
    }    

    GetAreaCombo() {
        return this.http.get<AfiliacionCombo[]>(`${environment.apiUrl}/Solicitudes/GetAreaCombo`);
    }
    
    GetRolCombo() {
        return this.http.get<AfiliacionCombo[]>(`${environment.apiUrl}/Solicitudes/GetRolCombo`);
    }   
    
    GetEmpresaCombo() {
        return this.http.get<AfiliacionCombo[]>(`${environment.apiUrl}/Solicitudes/GetEmpresaCombo`);
    }  
    
    getButonsformAfliacionesDetail(rolId: string, estadoId: string) {
        return this.http.get<AfiliacionDetailButon[]>(`${environment.apiUrl}/Solicitudes/getButonsformSolicitudesDetail`, {
            params: {
              rolId: rolId,
              estadoId: estadoId
            }
          });
    }  

    updateDatosProducto(id: string, datosProducto: any): Observable<any> {
        return this.http.post(`${environment.apiUrl}/Solicitudes/UpdateDatosProducto/${id}`, datosProducto);
      }
}