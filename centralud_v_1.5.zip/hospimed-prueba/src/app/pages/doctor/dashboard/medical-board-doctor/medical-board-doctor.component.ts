import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-medical-board-doctor',
  templateUrl: './medical-board-doctor.component.html',
  styleUrls: ['./medical-board-doctor.component.scss']
})
export class MedicalBoardDoctorComponent implements OnInit {

  isHidden: boolean = false;

  started: boolean = false;
  showHistorialModal: boolean = false;
  showAuxiliaryExamsModal: boolean = false;
  showRecipeModal: boolean = false;
  showInterconsultationModal: boolean = false;
  showMedicalBoardModal: boolean = false;
  showNextAppointmentModal: boolean = false;
  showMedicalRestModal: boolean = false;

  showHCH: boolean = false;
  showFirmar: boolean = false;
  showPreviewModal: boolean = false;

  diagnosticos: number[] = [1];

  tiempoEnfermedad: number = 0;

  separatorKeysCodes: number[] = [ENTER, COMMA];

  myControl = new FormControl();
  options: string[] = ['One', 'Two', 'Three'];
  filteredOptions: Observable<string[]>;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  addDiagnostico(): void {
    this.diagnosticos.push(1);
  }

  updateShowHCH(event): void {
    this.showHCH = event;
  }

  constructor() { }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().indexOf(filterValue) === 0);
  }

  updateStarted(value): void {
    this.started = value;
  }
}