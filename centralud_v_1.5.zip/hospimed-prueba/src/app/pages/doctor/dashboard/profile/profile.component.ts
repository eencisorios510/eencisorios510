import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  currentStep: number = 3;

  steps: Array<{ value: number, label: string }> = [
    { value: 1, label: 'Contacto' },
    { value: 2, label: 'Formación' },
    { value: 3, label: 'Facturación' }
  ];

  showChangePass: boolean;

  clickshowChangePassModal(): void{
    this.showChangePass = true;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
