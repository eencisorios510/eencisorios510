﻿export class User {
    id: string;
    username: string;
    password: string;
    rol: string;
    token: string;
    name: string;
    email: string;
    desc_Rol: string;
    rolId: string;
}