import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-medical-appointment-reservation',
  templateUrl: './medical-appointment-reservation.component.html',
  styleUrls: ['./medical-appointment-reservation.component.scss']
})
export class MedicalAppointmentReservationComponent implements OnInit {

  @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

  stateCtrl = new FormControl();
  searchHistory: any[] = [];
  filteredSearchHistory: Observable<any[]>;

  searchInputState: string = 'blur'; // blur, focus

  doctors: any[] = [
    {
      id: 1,
      name: 'Dr. Aldo Mercado Ramirez',
      status: 'online'
    },
    {
      id: 2,
      name: 'Dr. Ken Ramirez',
      status: 'offline'
    },
    {
      id: 3,
      name: 'Dr. Mijalys Silva',
      status: 'online'
    },
    {
      id: 4,
      name: 'Dra. Hellen',
      status: 'offline'
    },
    {
      id: 5,
      name: 'Dr. Hector Medina',
      status: 'offline'
    },
    {
      id: 6,
      name: 'Dr. Paul McCartney',
      status: 'online'
    },
    {
      id: 7,
      name: 'Dr.  Dolores ORiordan',
      status: 'offline'
    },
    {
      id: 8,
      name: 'Dr. Walter White',
      status: 'online'
    },
    {
      id: 9,
      name: 'Dr. Debbie Harry',
      status: 'offline'
    }
  ];

  filteredDoctors: any[] = [];

  selectedDoctorId: number = 1;

  constructor() {
    this.filteredDoctors = this.doctors;

    this.filteredSearchHistory = this.stateCtrl.valueChanges
      .pipe(
        startWith(''),
        map(search => search ? this._filterSearchHistory(search) : this.searchHistory.slice())
      );
  }

  private _filterSearchHistory(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.searchHistory.filter(search => search.toLowerCase().indexOf(filterValue) === 0);
  }

  searchInputFocus(): void {
    this.searchInputState = 'focus';
  }

  searchInputBlur(): void {
    this.searchInputState = 'blur';
    // this.autocomplete.closePanel();
  }

  getSearchHistory(): void {
    this.searchHistory = [
      'Dr. Aldo Mercado Ramirez',
      'Dra. Melany Oré Capcha',
      'Dermatología',
      'Dr. Aldo Nakaruma Carrillo'
    ];
  }

  updateSelectedDoctorId(id): void {
    this.selectedDoctorId = id;
  }

  showAvailablesOnly(event): void {
    if (event.checked) {
      this.filteredDoctors = this.doctors.filter(doctor => doctor.status === 'online');
    } else {
      this.filteredDoctors = this.doctors;
    }
  }

  ngOnInit(): void {
    this.getSearchHistory();
  }

}
