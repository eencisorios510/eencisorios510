import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VideocallAntecedentesComponent } from './videocall-antecedentes.component';

describe('VideocallAntecedentesComponent', () => {
  let component: VideocallAntecedentesComponent;
  let fixture: ComponentFixture<VideocallAntecedentesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VideocallAntecedentesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VideocallAntecedentesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
