using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PFTWebAPI.Data;
namespace PFTWebAPI.Controllers
{
    public abstract class CrudController<TEntity, TGetDto, TCreateDto, TUpdateDto> 
        : ControllerBase
        where TEntity : class
    {
        protected readonly DataContext _context;
        protected readonly DbSet<TEntity> _dbSet;
        protected readonly IMapper _mapper;
    
        protected CrudController(DataContext context, IMapper mapper)
        {
            _context = context;
            _dbSet = _context.Set<TEntity>();
            _mapper = mapper;
        }
    
        [HttpGet]
        public virtual async Task<ActionResult<IEnumerable<TGetDto>>> GetAll()
        {
            var entities = await _dbSet.ToListAsync();
            var dtos = _mapper.Map<IEnumerable<TGetDto>>(entities);
            return Ok(dtos);
        }
    
        [HttpGet("{id}")]
        public virtual async Task<ActionResult<TGetDto>> GetById(int id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null) return NotFound();
    
            var dto = _mapper.Map<TGetDto>(entity);
            return Ok(dto);
        }
    
        [HttpPost]
        public virtual async Task<ActionResult<TGetDto>> Create(TCreateDto dto)
        {
            var entity = _mapper.Map<TEntity>(dto);
            _dbSet.Add(entity);
            await _context.SaveChangesAsync();
    
            var getDto = _mapper.Map<TGetDto>(entity);
            return CreatedAtAction(nameof(GetById), new { id = GetEntityId(entity) }, getDto);
        }
    
        [HttpPut("{id}")]
        public virtual async Task<IActionResult> Update(int id, TUpdateDto dto)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null) return NotFound();
    
            _mapper.Map(dto, entity);
            await _context.SaveChangesAsync();
    
            return NoContent();
        }
    
        [HttpDelete("{id}")]
        public virtual async Task<IActionResult> Delete(int id)
        {
            var entity = await _dbSet.FindAsync(id);
            if (entity == null) return NotFound();
    
            _dbSet.Remove(entity);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    
        protected virtual int GetEntityId(TEntity entity)
        {
            var propertyInfo = entity.GetType().GetProperty("Id");
            return (int)(propertyInfo?.GetValue(entity) ?? 0);
        }
    }
}    