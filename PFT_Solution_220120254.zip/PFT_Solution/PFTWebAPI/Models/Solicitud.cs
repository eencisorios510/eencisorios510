using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
using PFTWebAPI.Dto.Users;

namespace PFTWebAPI.Models
{
    public class Solicitud
    {
        public int Id { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string SolicitanteNombre { get; set; } = string.Empty;
        [Column(TypeName = "nvarchar(250)")]
        public string SolicitanteEmail { get; set; } = string.Empty;
        public DateTime FechaRegistro { get; set; } = DateTime.Now;
        public DateTime FechaActualizacion { get; set; } = DateTime.Now;
        public int EstadoActualId { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string? EmpresaSolicitud { get; set; }
        public int? IdAreaSolicitante { get; set; }
        public int ProductoId { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string? FlujoInformacion { get; set; }    
        [Column(TypeName = "nvarchar(250)")]
        public string? EspecialistaComercial { get; set; }
        public int? IdAplicacionSolicitante { get; set; }
        public string? ArchivoAdjunto { get; set; }   
        [Column(TypeName = "nvarchar(50)")] 
        public string? CodigoFt { get; set; }
        public string DatosProducto { get; set; } = string.Empty;
        public string DatosOrigen { get; set; } = string.Empty;
        public string DatosDestino { get; set; } = string.Empty;
        public string DatosDac { get; set; }  = string.Empty;
        public string TipoEncriptacion { get; set; } = "pgp";
        public bool EsBidireccional { get; set; } = false;
         public Producto Producto { get; set; }=default!;   
        public Area Area { get; set; }=default!; 
        public EstadosSolicitud EstadosSolicitud { get; set; }=default!;  
        public string Tecnologia { get; set; } = string.Empty;   
                  
    }
}







