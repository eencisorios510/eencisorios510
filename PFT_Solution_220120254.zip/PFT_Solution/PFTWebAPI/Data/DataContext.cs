﻿
namespace PFTWebAPI.Data;

using PFTWebAPI.Models;
using Microsoft.EntityFrameworkCore;

public class DataContext : DbContext
{
    protected readonly IConfiguration Configuration;

    public DataContext(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    protected override void OnConfiguring(DbContextOptionsBuilder options)
    {
        // connect to sql server database
        options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
    }
    public DbSet<Rol> Roles { get; set; }
    public DbSet<HistorialAtencion> HistorialAtenciones { get; set; }
    public DbSet<EstadosSolicitud> EstadosSolicitudes { get; set; }
    public DbSet<Aplicacion> Aplicaciones { get; set; }
    public DbSet<Area> Areas { get; set; }
    public DbSet<Solicitud> Solicitudes { get; set; }
    public DbSet<UserEntity> Users { get; set; }
    public DbSet<Generacion_Usuario> Generacion_Usuarios { get; set; }

    // public DbSet<Empresa_Detalle> Empresa_detalles { get; set; }
    public DbSet<Empresa> Empresas { get; set; }
    public DbSet<H2h_Detalle> H2h_detalles { get; set; }
    // public DbSet<Interesado> Interesados { get; set; }
    public DbSet<Producto> Productos { get; set; }
    public DbSet<Ruta_Transferencia> Ruta_transferencias { get; set; }
    public DbSet<Tipo_Transferencia> Tipo_transferencias { get; set; }
    // public DbSet<Unidad_Equipo> Unidad_equipos { get; set; }
    public DbSet<RolEstado> RolEstados { get; set; }
    public DbSet<SolicitudInteresado> SolicitudInteresados { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Rol>()
            .ToTable("ROL");

        modelBuilder.Entity<HistorialAtencion>()
            .ToTable("HISTORIAL_ATENCION");

        modelBuilder.Entity<EstadosSolicitud>()
            .ToTable("ESTADOS_SOLICITUD")
            .Property(e => e.Estado)
            .HasDefaultValue(true);

        modelBuilder.Entity<Area>()
            .ToTable("AREA");

        modelBuilder.Entity<Aplicacion>()
            .ToTable("APLICACION");           

       modelBuilder.Entity<Solicitud>()
            .ToTable("SOLICITUD");

        modelBuilder.Entity<UserEntity>()
            .ToTable("USUARIO");

        modelBuilder.Entity<Generacion_Usuario>()
            .ToTable("GENERACION_USUARIO");

        //modelBuilder.Ignore<AppUser>();
        // modelBuilder.Entity<Empresa_Detalle>()
        //     .ToTable("EMPRESA_DETALLE");

        modelBuilder.Entity<H2h_Detalle>()
            .ToTable("H2H_DETALLE");

        modelBuilder.Entity<Producto>()
            .ToTable("PRODUCTO");

        modelBuilder.Entity<Producto>()
            .ToTable("PRODUCTO");

        modelBuilder.Entity<Ruta_Transferencia>()
            .ToTable("RUTA_TRANSFERENCIA");

        modelBuilder.Entity<Tipo_Transferencia>()
            .ToTable("TIPO_TRANSFERENCIA");

        // modelBuilder.Entity<Unidad_Equipo>()
        //     .ToTable("UNIDAD_EQUIPO");

        modelBuilder.Entity<RolEstado>()
            .ToTable("ROL_ESTADO");    

        modelBuilder.Entity<SolicitudInteresado>()
            .ToTable("SOLICITUD_INTERESADO");  

         modelBuilder.Entity<Empresa>()
            .ToTable("EMPRESA");                  


        /* // Configuring Empresa and Empresa_Detalle relationship (one-to-many)
        modelBuilder.Entity<Empresa>()
             .ToTable("EMPRESA")
              .HasMany(e => e.Empresa_Detalles)
              .WithOne(ed => ed.Empresa)
              .HasForeignKey(ed => ed.Empresa_Id);

         // Configuring Solicitud and Empresa_Detalle relationship (one-to-one)
         modelBuilder.Entity<Solicitud>()
             .ToTable("SOLICITUD")
             .HasOne(s => s.Empresa_Detalle)
             .WithOne(ed => ed.Solicitud)
             .HasForeignKey<Solicitud>(s => s.Empresa_Detalle_Id);

         // Configuring Solicitud and H2h_Detalle relationship (one-to-one)
         modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.H2h_Detalle)
             .WithOne(h => h.Solicitud)
             .HasForeignKey<Solicitud>(s => s.H2h_Detalle_Id);

         // Configuring Solicitud and Tipo_Transferencia relationship (many-to-one)
         modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.Tipo_Transferencia)
             .WithMany(h => h.Solicitudes)
             .HasForeignKey(s => s.Tipo_Transferencia_Id);

         // Configuring Solicitud and Producto relationship (many-to-one)
         modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.Producto)
             .WithMany(p => p.Solicitudes)
             .HasForeignKey(s => s.Producto_Id);

         // Configuring Solicitud and Interesado relationship (one-to-many)
         modelBuilder.Entity<Solicitud>()
             .HasMany(s => s.Interesados)
             .WithOne(i => i.Solicitud)
             .HasForeignKey(i => i.Solicitud_id);

         // Configuring Solicitud and Ruta_Transferencia relationship (one-to-many)
         modelBuilder.Entity<Solicitud>()
             .HasMany(s => s.Ruta_Transferencias)
             .WithOne(rt => rt.Solicitud)
             .HasForeignKey(rt => rt.Solicitud_id);

         // Configuring Solicitud and Ip relationship (one-to-many)
         modelBuilder.Entity<Solicitud>()
             .HasMany(s => s.Ips)
             .WithOne(ip => ip.Solicitud)
             .HasForeignKey(ip => ip.Solicitud_id);

        // Configuring Interesado and Unidad_Equipo relationship (many-to-one)
         modelBuilder.Entity<Interesado>()
             .ToTable("INTERESADO")
             .HasOne(i => i.Unidad_Equipo)
             .WithMany(ue => ue.Interesados)
             .HasForeignKey(i => i.Unidad_Equipo_id);

         modelBuilder.Entity<Ip>()
             .ToTable("IP")
             .HasOne(ip => ip.Solicitud)
             .WithMany(s => s.Ips)
             .HasForeignKey(ip => ip.Solicitud_id); */
            
           // Configuring Solicitud and Producto relationship (many-to-one)
          modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.Producto)
             .WithMany(p => p.Solicitudes)
             .HasForeignKey(s => s.ProductoId); 

         modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.Area)
             .WithMany(p => p.Solicitudes)
             .HasForeignKey(s => s.IdAreaSolicitante);  

         modelBuilder.Entity<Solicitud>()
             .HasOne(s => s.EstadosSolicitud)
             .WithMany(p => p.Solicitudes)
             .HasForeignKey(s => s.EstadoActualId);  

         modelBuilder.Entity<RolEstado>()
             .HasOne(s => s.Rol)
             .WithMany(p => p.RolEstados)
             .HasForeignKey(s => s.RolId);  

         modelBuilder.Entity<RolEstado>()
             .HasOne(s => s.EstadosSolicitud)
             .WithMany(p => p.RolEstados)
             .HasForeignKey(s => s.EstadoId);                                          
    }
}
