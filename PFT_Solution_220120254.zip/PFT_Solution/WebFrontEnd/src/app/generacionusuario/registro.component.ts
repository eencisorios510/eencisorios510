﻿import { Component, OnInit ,inject} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { GuserService, AlertService } from '@app/_services';

@Component({ templateUrl: 'registro.component.html' })
export class RegistroGUsuarioComponent implements OnInit {
    private readonly guserService = inject(GuserService);
    form2: UntypedFormGroup;
    loading = false;
    submitted = false;

    constructor(
        private formBuilder: UntypedFormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private alertService: AlertService
    ) { }

    ngOnInit() {
        this.form2 = this.formBuilder.group({
            idAfiliacion: ['', Validators.required],
            nombreEmpresa: ['', Validators.required],
            producto: ['', Validators.required],
            ambiente: ['', Validators.required]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.form2.controls; }

    onSubmit() {
        this.submitted = true;

        // reset alerts on submit
        this.alertService.clear();

        // stop here if form is invalid
        if (this.form2.invalid) {
            return;
        }

        this.loading = true;
        console.log('this.form2.value')
        console.log(this.form2.value)
        this.guserService.gusuarioregister(this.form2.value)
            .pipe(first())
            .subscribe({
                next: response  => {
                    const codigo = (response as any).result.codigo;
             
                    this.loading = false;
                    this.alertService.success('Generación extitosa, su codigo es '+codigo, { keepAfterRouteChange: true });
                },
                    //this.router.navigate(['/ver', id]); 
                error: error => {
                    this.alertService.error(error);
                    this.loading = false;
                }
            });
    }
}