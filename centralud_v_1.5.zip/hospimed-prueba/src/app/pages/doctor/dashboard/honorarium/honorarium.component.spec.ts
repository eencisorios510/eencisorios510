import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HonorariumComponent } from './honorarium.component';

describe('HonorariumComponent', () => {
  let component: HonorariumComponent;
  let fixture: ComponentFixture<HonorariumComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HonorariumComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HonorariumComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
