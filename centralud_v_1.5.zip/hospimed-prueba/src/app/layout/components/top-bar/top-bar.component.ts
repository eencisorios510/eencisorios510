import { Location } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.scss']
})
export class TopBarComponent implements OnInit {

  @Output() updateShowFooterEvent = new EventEmitter<boolean>();

  pageTitle: string = '';
  showBackBtn: boolean = false;

  constructor(
    public router: Router,
    public location: Location) {
    router.events.subscribe((val: any) => {
      if (val instanceof NavigationEnd) {
        this.refreshPageTitle(val.url);
      }
    });
  }

  refreshPageTitle(currentRoute): void {
    const url = currentRoute.split('/').splice(-1);

    if (!url) {
      this.pageTitle = '';
      this.showBackBtn = false;
      return;
    }

    this.updateShowFooterEvent.emit(url[0] === 'dashboard');

    const routes = [
      { showBackBtn: true, url: 'profile', pageTitle: 'Mi perfil' },
      { showBackBtn: true, url: 'plans', pageTitle: 'Membresía' },
      { showBackBtn: true, url: 'yearly-plan', pageTitle: 'Membresía' },
      { showBackBtn: true, url: 'yearly-membership', pageTitle: 'Membresía' },
      { showBackBtn: true, url: 'monthly-membership', pageTitle: 'Membresía' },
      { showBackBtn: true, url: 'honorarium', pageTitle: 'Honorarios' },
      { showBackBtn: true, url: 'invitations', pageTitle: 'Invitaciones' },
      { showBackBtn: true, url: 'turn-schedule', pageTitle: 'Mis turnos' },
      { showBackBtn: true, url: 'quotes', pageTitle: 'Lista de citas' },
      { showBackBtn: true, url: 'medical-appointment-reservation', pageTitle: 'Reservar cita' },
      { showBackBtn: true, url: 'pick-turn', pageTitle: 'Reservar cita' },
      { showBackBtn: true, url: 'checkout', pageTitle: 'Reservar cita' },
      { showBackBtn: true, url: 'medical-form', pageTitle: 'Ficha médica' },
      { showBackBtn: true, url: 'video-call', pageTitle: 'Teleconsulta' },
      { showBackBtn: true, url: 'reports', pageTitle: 'Reportería' },
      { showBackBtn: true, url: 'medical-board', pageTitle: 'Junta Médica' },
      { showBackBtn: true, url: 'profile-record', pageTitle: 'Junta Médica' },
      { showBackBtn: true, url: 'patient-monitoring', pageTitle: 'Seguimiento' },
      { showBackBtn: true, url: 'help-center', pageTitle: 'Ayuda' },
      { showBackBtn: true, url: 'campaigns', pageTitle: 'Campañas' },
      { showBackBtn: true, url: 'hce-report', pageTitle: 'HCE' },
      { showBackBtn: true, url: 'clinic-history', pageTitle: 'Historia Clínica' },
    ];

    const currentRouteData = routes.find(item => item.url === url[0]);

    if (currentRouteData) {
      this.pageTitle = currentRouteData.pageTitle;
      this.showBackBtn = currentRouteData.showBackBtn;
    } else {
      this.pageTitle = '';
      this.showBackBtn = false;
    }
  }

  ngOnInit(): void {
  }

}
