namespace PFTWebAPI.Dto.Users;

    public class SolicitudGetAll
    {
        public int Id { get; set; }
        public string Solicitante { get; set; }
        public string CorreoSolicitante { get; set; }
        public string FechaIngresoSolicitud { get; set; }
        public string EstadoSolicitud { get; set; }
        public string EmpresaSolicitud { get; set; }
        public string ContactoEmpresa { get; set; }
        public string AreaSolicitante { get; set; }
        public string CorreoContactoEmpresa { get; set; }
        public string Producto { get; set; }
        public string FlujoInformacion { get; set; }
        public string DatosDac { get; set; }   
        public string TipoEncriptacion { get; set; }
        public string EspecialistaComercial { get; set; }
        public string AplicacionSolicitante { get; set; }
        public string Responsable { get; set; }
        public string DetalleSolicitud { get; set; }
        public string ArchivoAdjunto { get; set; }    
        public string Desc_AreaSolicitante { get; set; }
        public string Desc_Producto { get; set; }
        public string Desc_AplicacionSolicitante { get; set; }
        public string UsuarioFt { get; set; }
        public string Desc_EstadoSolicitud { get; set; }
        public int IdEstadoSolicitud { get; set; }
        public int ProductoId { get; set; }
    }