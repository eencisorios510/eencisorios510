﻿namespace PFTWebAPI.Dto.Users;

using System.ComponentModel.DataAnnotations;
    public class SolicitudAddRequest
    {
        [Required]
        public string Solicitante { get; set; }       
        [Required]
        public string CorreoSolicitante { get; set; }       
        [Required]
        public string EmpresaSolicitud { get; set; }
        [Required]
        public int IdAreaSolicitante { get; set; }
        [Required]
        public int ProductoId { get; set; }
        [Required]
        public string FlujoInformacion { get; set; }
        [Required]
        public string DatosDac { get; set; } 
        [Required]    
        public string TipoEncriptacion { get; set; }
        [Required]
        public string EspecialistaComercial { get; set; }
        [Required]
        public int IdAplicacionSolicitante { get; set; }
        public string Tecnologia { get; set; }  
        
    }