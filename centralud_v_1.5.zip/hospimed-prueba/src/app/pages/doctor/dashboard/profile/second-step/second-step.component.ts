import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-second-step',
  templateUrl: './second-step.component.html',
  styleUrls: ['./second-step.component.scss']
})
export class SecondStepComponent implements OnInit {

  pregrados: Array<number> = [1];
  experienciaLaboral: Array<number> = [1];
  reconocimientos: Array<number> = [1];

  constructor() { }

  ngOnInit(): void {
  }

  addPregrado () {
    this.pregrados.push(1);
  }

  removePregrado () {
    this.pregrados.splice(0, 1);
  }

  addExperienciaLaboral () {
    this.experienciaLaboral.push(1);
  }

  removeExperienciaLaboral () {
    this.experienciaLaboral.splice(0, 1);
  }

  addReconocimiento () {
    this.reconocimientos.push(1);
  }

  removeReconocimiento () {
    this.reconocimientos.splice(0, 1);
  }

}
