﻿import { Component, OnInit,inject } from '@angular/core';
import { first } from 'rxjs/operators';
import { GuserService, AlertService } from '@app/_services';

@Component({ templateUrl: 'listguser.component.html' })
export class ListguserComponent implements OnInit {
    lista = null;
    private readonly guserService = inject(GuserService);
    constructor() {}

    ngOnInit() {
        this.guserService.getGeneracionUsuarioAll()
        .pipe(first())
        .subscribe(users => {
            this.lista = users;
            console.log('users');
            console.log(users);
        });
    }
}