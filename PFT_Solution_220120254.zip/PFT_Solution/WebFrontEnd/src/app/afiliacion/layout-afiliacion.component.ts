﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'layout-afiliacion.component.html' })
export class LayoutAfiliacionComponent { }