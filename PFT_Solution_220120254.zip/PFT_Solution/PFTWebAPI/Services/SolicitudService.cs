namespace PFTWebAPI.Services;

using AutoMapper;
using BCrypt.Net;
using PFTWebAPI.Authorization;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using Microsoft.EntityFrameworkCore;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Dto;

public interface ISolicitudService
{
    ApiResponse<List<SolicitudGetAll>> GetSolicitudesAll(int page, int pageSize, string filter);
    Task<SolicitudGetAll> GetSolicitudDetalleAsync(int id);
    Task<Solicitud> Register(SolicitudAddRequest model);
    void Update(int id, SolicitudUpdateRequest model);
    void Delete(int id);
    IEnumerable<SolicitudCombo> GetAreaCombo();
    IEnumerable<SolicitudCombo> GetRolCombo();
    IEnumerable<SolicitudCombo> GetProductoCombo();
    IEnumerable<SolicitudCombo> GetAplicacionCombo();
    IEnumerable<SolicitudCombo> GetEmpresaCombo();
    
    void RegisUpdateDatosProductoter(int id, string datosProducto);
}

public class SolicitudService : ISolicitudService
{
    private readonly DataContext _context;
    private readonly IMapper _mapper;

    public SolicitudService(DataContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public ApiResponse<List<SolicitudGetAll>> GetSolicitudesAll(int page, int pageSize, string filter)
    {
        var query = from afiliacion in _context.Solicitudes
                    join area in _context.Areas on afiliacion.IdAreaSolicitante equals area.Id
                    join producto in _context.Productos on afiliacion.ProductoId equals producto.Id
                    join aplicacion in _context.Aplicaciones on afiliacion.IdAplicacionSolicitante equals aplicacion.Id
                    join estado in _context.EstadosSolicitudes on afiliacion.EstadoActualId equals estado.Id
                    select new SolicitudGetAll
                    {
                        Id = afiliacion.Id,
                        IdEstadoSolicitud = estado.Id,
                        Solicitante = afiliacion.SolicitanteNombre,
                        FechaIngresoSolicitud = afiliacion.FechaRegistro.Date.ToString(),
                        CorreoSolicitante = afiliacion.SolicitanteEmail,
                        EmpresaSolicitud = afiliacion.EmpresaSolicitud,
                        Desc_AreaSolicitante = area.Nombre,
                        Desc_Producto = producto.Nombre,
                        FlujoInformacion = afiliacion.FlujoInformacion,
                        DatosDac = afiliacion.DatosDac,
                        TipoEncriptacion = afiliacion.TipoEncriptacion,
                        EspecialistaComercial = afiliacion.EspecialistaComercial,
                        Desc_AplicacionSolicitante = aplicacion.Nombre,
                        UsuarioFt = afiliacion.CodigoFt,
                        Desc_EstadoSolicitud = estado.Nombre
                 
                    };

        if (!string.IsNullOrEmpty(filter))
        {
            query = query.Where(p => p.EmpresaSolicitud.Contains(filter) ||
                                        p.Id.ToString().Contains(filter) ||
                                        p.CorreoSolicitante.Contains(filter) ||
                                        p.UsuarioFt.ToString().Contains(filter));
        }

        query = query.OrderByDescending(p => p.Id);

        var totalRecords = query.Count();
        var afiliaciones = query.Skip((page - 1) * pageSize).Take(pageSize).ToList();

        // Depuración: Verificar los valores de IdEstadoSolicitud
        foreach (var afiliacion in afiliaciones)
        {
            Console.WriteLine($"Id: {afiliacion.Id}, IdEstadoSolicitud: {afiliacion.IdEstadoSolicitud}");
        }

        return new ApiResponse<List<SolicitudGetAll>>(afiliaciones, totalRecords);
    }


    public async Task<Solicitud> Register(SolicitudAddRequest model)
    {
        // map model to new afiliacion object
        var afiliacion = _mapper.Map<Solicitud>(model);
        
        afiliacion.FechaRegistro = DateTime.Now;
        afiliacion.EstadoActualId = 2;
        // save afiliacion
        _context.Solicitudes.Add(afiliacion);
        _context.SaveChanges();     

         return afiliacion;
    }

    public void Update(int id, SolicitudUpdateRequest model)
    {
        var afiliacion = getSolicitud(id);

   /*      // validate
        if (model.NroSolicitud != afiliacion.NroSolicitud && _context.Solicitudes.Any(x => x.NroSolicitud == model.NroSolicitud))
            throw new AppException("NroSolicitud '" + model.NroSolicitud + "' ya está en uso"); */

        // copy model to afiliacion and save
        _mapper.Map(model, afiliacion);
        _context.Solicitudes.Update(afiliacion);
        _context.SaveChanges();
    }

    public void Delete(int id)
    {
        var afiliacion = getSolicitud(id);
        _context.Solicitudes.Remove(afiliacion);
        _context.SaveChanges();
    }

    // helper methods

/*     public async Task<SolicitudGetAll> GetDetalleByIdAsync(int id)
    {
        return await GetSolicitudDetalleAsync(id);
    } */

    public async Task<SolicitudGetAll> GetSolicitudDetalleAsync(int id)
    {
        var query = from afiliacion in _context.Solicitudes
                    join area in _context.Areas on afiliacion.IdAreaSolicitante equals area.Id into areaJoin
                    from area in areaJoin.DefaultIfEmpty()
                    join producto in _context.Productos on afiliacion.ProductoId equals producto.Id into productoJoin
                    from producto in productoJoin.DefaultIfEmpty()
                    join aplicacion in _context.Aplicaciones on afiliacion.IdAplicacionSolicitante equals aplicacion.Id into aplicacionJoin
                    from aplicacion in aplicacionJoin.DefaultIfEmpty()
                    join estado in _context.EstadosSolicitudes on afiliacion.EstadoActualId equals estado.Id into estadoJoin
                    from estado in estadoJoin.DefaultIfEmpty()
                    where afiliacion.Id == id
                    select new SolicitudGetAll
                    {
                        Id = afiliacion.Id,
                        IdEstadoSolicitud = afiliacion.EstadoActualId,
                        Solicitante = afiliacion.SolicitanteNombre,
                        FechaIngresoSolicitud = afiliacion.FechaRegistro.Date.ToString(),
                        CorreoSolicitante = afiliacion.SolicitanteEmail,
                        EmpresaSolicitud = afiliacion.EmpresaSolicitud,
                        Desc_AreaSolicitante = area.Nombre,
                        Desc_Producto = producto.Nombre,
                        FlujoInformacion = afiliacion.FlujoInformacion,
                        DatosDac = afiliacion.DatosDac,
                        TipoEncriptacion = afiliacion.TipoEncriptacion,
                        EspecialistaComercial = afiliacion.EspecialistaComercial,
                        Desc_AplicacionSolicitante = aplicacion.Codigo,
                        UsuarioFt = afiliacion.CodigoFt,
                        Desc_EstadoSolicitud = estado.Nombre,
                        ProductoId = afiliacion.ProductoId
                    };

        return await query.FirstOrDefaultAsync();
    }

    private Solicitud getSolicitud(int id)
    {
        var afiliacion = _context.Solicitudes.Find(id);
        if (afiliacion == null) throw new KeyNotFoundException("Afiliación no encontrada");
        return afiliacion;
    }

    public IEnumerable<SolicitudCombo> GetAreaCombo()
    {
       var query = from area in _context.Areas
                    select new SolicitudCombo
                    {
                        Id = area.Id,
                        Nombre = area.Nombre,
                    };
        return query.ToList();
    }
        public IEnumerable<SolicitudCombo> GetRolCombo()
    {
       var query = from rol in _context.Roles
                    select new SolicitudCombo
                    {
                        Id = rol.Id,
                        Nombre = rol.Nombre,
                    };
        return query.ToList();
    }
        public IEnumerable<SolicitudCombo> GetProductoCombo()
    {
       var query = from producto in _context.Productos
                    select new SolicitudCombo
                    {
                        Id = producto.Id,
                        Nombre = producto.Nombre,
                    };
        return query.ToList();
    }
        public IEnumerable<SolicitudCombo> GetAplicacionCombo()
    {
       var query = from app in _context.Aplicaciones
                    select new SolicitudCombo
                    {
                        Id = app.Id,
                        Nombre = app.Codigo,
                    };
        return query.ToList();
    }


    public IEnumerable<SolicitudCombo> GetEmpresaCombo()
    {
       var query = from app in _context.Empresas
                    select new SolicitudCombo
                    {
                        Id = app.Id,
                        Nombre = app.Nombre + " - " + app.Ruc
                    };
        return query.ToList();
    }

public void RegisUpdateDatosProductoter(int id, string datosProducto)
{
    var solicitud = getSolicitud(id);
    if (solicitud == null)
    {
        throw new KeyNotFoundException("Afiliación no encontrada");
    }

    solicitud.DatosProducto = datosProducto;
    solicitud.FechaActualizacion = DateTime.Now;
    _context.Solicitudes.Update(solicitud);
    _context.SaveChanges();        
}
}