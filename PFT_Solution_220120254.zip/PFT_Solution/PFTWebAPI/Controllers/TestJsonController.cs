using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Schema;
using System.Collections.Generic;
using PFTWebAPI.Data;
using PFTWebAPI.Helpers;

namespace PFTWebAPI.Controllers
{
    public class SchemaService
    {
        private readonly JSchema _schema;

        public SchemaService(string schemaJson)
        {
            _schema = JSchema.Parse(schemaJson);
        }

        public IList<string> Validate(JObject data)
        {
            var errors = new List<string>();
            data.Validate(_schema, (sender, args) => errors.Add(args.Message));
            return errors;
        }
    }

    [ApiController]
    [Route("[controller]")]
    public class ContratoController : ControllerBase
    {
        private DataContext _context;
        public ContratoController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> CreateContrato()
        {
            string json = @"
            {
                ""path_contrato"": ""/ruta/a/la/imagen"",
                ""codigo_contrato"": ""12345"",
                ""correo1"": ""correo1@example.com"",
                ""correo2"": ""correo2@example.com"",
                ""correo3"": ""correo3@example.com"",
                ""correo4"": ""correo4@example.com"",
                ""tipo_conexion"": ""internet"",
                ""dns"": ""8.8.8.8"",
                ""ip"": [""192.168.1.1"", ""192.168.1.2""]
            }";
            var producto = await _context.Productos.FindAsync(1);
            if (producto == null)
            {
                return NotFound("Producto no encontrado");
            }

            JObject contrato = JObject.Parse(json);

            var schemaService = new SchemaService(producto.ContratoJson);
            var errors = schemaService.Validate(contrato);

            if (errors.Count > 0)
            {
                return BadRequest(errors);
            }

            // Aquí puedes manejar la lógica para guardar el contrato
            return Ok("Contrato creado exitosamente");
        }
    }
}