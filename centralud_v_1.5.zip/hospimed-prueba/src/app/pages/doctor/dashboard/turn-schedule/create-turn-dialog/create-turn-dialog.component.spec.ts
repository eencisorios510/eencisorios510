import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateTurnDialogComponent } from './create-turn-dialog.component';

describe('CreateTurnDialogComponent', () => {
  let component: CreateTurnDialogComponent;
  let fixture: ComponentFixture<CreateTurnDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateTurnDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTurnDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
