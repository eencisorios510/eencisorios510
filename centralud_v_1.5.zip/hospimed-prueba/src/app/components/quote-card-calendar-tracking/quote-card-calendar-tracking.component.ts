import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-quote-card-calendar-tracking',
  templateUrl: './quote-card-calendar-tracking.component.html',
  styleUrls: ['./quote-card-calendar-tracking.component.scss']
})
export class QuoteCardCalendarTrackingComponent implements OnInit {

  @Input() card: {date: string, alert: string}

  constructor() { }

  ngOnInit(): void {
  }

}
