import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-plan-card',
  templateUrl: './monthly-plan-card.component.html',
  styleUrls: ['./monthly-plan-card.component.scss']
})
export class MonthlyPlanCardComponent implements OnInit {

  @Input() cardTitle: string = null;

  constructor() { }

  ngOnInit(): void {
  }

}
