import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyAttentionsCardComponent } from './my-attentions-card.component';

describe('MyAttentionsCardComponent', () => {
  let component: MyAttentionsCardComponent;
  let fixture: ComponentFixture<MyAttentionsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyAttentionsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyAttentionsCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
