import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { Component, OnInit } from '@angular/core';
import {MatChipInputEvent} from '@angular/material/chips';

interface Food {
  value: string;
  viewValue: string;
}

export interface Exam {
  name: string;
}

@Component({
  selector: 'app-auxiliary-exams',
  templateUrl: './auxiliary-exams.component.html',
  styleUrls: ['./auxiliary-exams.component.scss']
})
export class AuxiliaryExamsComponent implements OnInit {

  proximoControl: number = 0;
  indicaciones: string = 'Lorem Ipsum';

  notDisable: boolean;
  showRayosX: boolean;
  showLaboratorio: boolean;
  createRayosX: boolean = true;

  addBlock(): void{
    this.createRayosX = false;
    this.notDisable = false;
    this.showLaboratorio = true;
    this.showRayosX = true;
  }

  selecOption(): void{
    this.notDisable = true;
    this.showLaboratorio = false;
    this.showRayosX = false;
    // this.createRayosX = true;

    // if(this.selectedValue === 'Rayos X-1'){
    //   this.createRayosX = true;
    // } else
    // this.selectedValue === 'Rayos X-1';
    // this.createRayosX = false;
   
  }

  editRayosX(): void{
    this.createRayosX = true;
    this.showRayosX = false;
    this.showLaboratorio = false;
    this.notDisable = true;
  }

  deleteItem(): void{
    this.createRayosX = false;
    this.showRayosX = false;
  }

  

  selectedValue: string;

  foods: Food[] = [
    {value: 'Laboratorio-0', viewValue: 'Laboratorio'},
    {value: 'Rayos X-1', viewValue: 'Rayos X'},
    {value: 'Ecografía-2', viewValue: 'Ecografía'},
    {value: 'Tomografía-3', viewValue: 'Tomografía'},
    {value: 'Resonancia-4', viewValue: 'Resonancia'},
    {value: 'Anat. Patológica-5', viewValue: 'Anat. Patológica'},
    {value: 'Densitometría-6', viewValue: 'Densitometría'},
    {value: 'Procediemientos-7', viewValue: 'Procediemientos'},
  ];

  
 

  // chips
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];
  exams: Exam[] = [
    {name: 'Radiografía de torax'},
    {name: 'Radiografía de craneo'},
  ];

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our exam
    if ((value || '').trim()) {
      this.exams.push({name: value.trim()});
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }
  }

  remove(exam: Exam): void {
    const index = this.exams.indexOf(exam);

    if (index >= 0) {
      this.exams.splice(index, 1);
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
