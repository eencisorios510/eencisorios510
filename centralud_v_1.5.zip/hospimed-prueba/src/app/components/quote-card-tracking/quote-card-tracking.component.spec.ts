import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteCardTrackingComponent } from './quote-card-tracking.component';

describe('QuoteCardTrackingComponent', () => {
  let component: QuoteCardTrackingComponent;
  let fixture: ComponentFixture<QuoteCardTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuoteCardTrackingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteCardTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
