    namespace PFTWebAPI.Dto;
    public class EstadoSolicitud
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public int Orden { get; set; }
        public bool Estado { get; set; }
    }