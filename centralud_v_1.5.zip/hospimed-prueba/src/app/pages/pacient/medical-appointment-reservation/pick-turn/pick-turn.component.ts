import { Component, OnInit } from '@angular/core';
import { MatCalendarCellCssClasses } from '@angular/material/datepicker';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-pick-turn',
  templateUrl: './pick-turn.component.html',
  styleUrls: ['./pick-turn.component.scss']
})
export class PickTurnComponent implements OnInit {

  // selectedDate = new Date('2019/09/26');
  selectedDate: Date;
  startAt = new Date('2019/09/11');
  minDate = new Date('2019/09/14');
  maxDate = new Date(new Date().setMonth(new Date().getMonth() + 1));
  year: any;
  DayAndDate: string;

  turnDate: any;

  dates = [
    { day: 1, date: '29-03-2021', dateName: 'Lun 29', turns: [{ startTime: '10:00', endTime: '11:00' }, { startTime: '11:00', endTime: '12:00' }] },
    { day: 2, date: '30-03-2021', dateName: 'Mar 30', turns: [] },
    { day: 3, date: '01-04-2021', dateName: 'Mié 1', turns: [{ startTime: '13:00', endTime: '14:00' }] },
    { day: 4, date: '02-04-2021', dateName: 'Jue 2', turns: [] },
    { day: 5, date: '03-04-2021', dateName: 'Vie 3', turns: [] },
    { day: 6, date: '04-04-2021', dateName: 'Sáb 4', turns: [] },
    { day: 7, date: '05-04-2021', dateName: 'Dom 5', turns: [] },
    { day: 1, date: '06-04-2021', dateName: 'Lunes 6', turns: [] },
    { day: 2, date: '07-04-2021', dateName: 'mar 7', turns: [] },
    { day: 3, date: '08-04-2021', dateName: 'Mié 8', turns: [] },
  ];

  isEmpty: boolean = false;

  constructor(private route: ActivatedRoute,private router: Router) {}

  ngOnInit(): void {
  }

  onSelect(event) {
    this.selectedDate = event;
    const dateString = event.toDateString();
    const dateValue = dateString.split(' ');
    this.year = dateValue[3];
    this.DayAndDate = dateValue[0] + ',' + ' ' + dateValue[1] + ' ' + dateValue[2];
  }

  myDateFilter = (d: Date): boolean => {
    const day = d.getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6 ;
  }

  selectTurn(turnData: {date: string, turnIndex: number}): void {
    console.log('Turno: ', turnData);
    const id = this.route.snapshot.paramMap.get('id');
    this.router.navigate(['/pacients/my/medical-appointment-reservation/'+ id +'/checkout']);
  }

  getDaysWithTurn() {
    const daysWithTurn = [];

    this.dates.forEach(date => {
      if ( date.turns.length > 0 && !daysWithTurn.includes(date.day) ) {
        daysWithTurn.push(date.day);
      }
    });

    return daysWithTurn;
  }

  dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      const daysWithTurn = this.getDaysWithTurn();
      console.log('dateClass() daysWithTurn: ', daysWithTurn);

      if (daysWithTurn.length === 0) return;

      if (daysWithTurn.includes(date.getDay())) {
        return 'special-date';
      }
    };
  }
}
