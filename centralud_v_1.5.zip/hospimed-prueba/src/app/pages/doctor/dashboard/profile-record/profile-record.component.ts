import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PopUpRxhComponent } from './pop-up-rxh/pop-up-rxh.component';

@Component({
  selector: 'app-profile-record',
  templateUrl: './profile-record.component.html',
  styleUrls: ['./profile-record.component.scss']
})
export class ProfileRecordComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openPopupRxh(){
    this.dialog.open(PopUpRxhComponent);
  }

}
