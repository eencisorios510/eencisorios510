import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Layout2Component } from './layout2.component';
import { RegistroGUsuarioComponent } from './registro.component';
import { ListguserComponent } from './listguser.component';
import { VerComponent } from './ver.component';

const routes: Routes = [
    {
        path: '', component: Layout2Component,
        children: [
            { path: '', component: ListguserComponent },
            { path: 'add', component: RegistroGUsuarioComponent },
            { path: 'ver/:id', component: VerComponent },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class GuserRoutingModule { }