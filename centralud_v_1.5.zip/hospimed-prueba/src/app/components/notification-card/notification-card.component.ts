import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-notification-card',
  templateUrl: './notification-card.component.html',
  styleUrls: ['./notification-card.component.scss']
})
export class NotificationCardComponent implements OnInit {
  
  filteredNewNotifications: any[] = [];
  selectedNewNotificationId: number = 1;

  filteredOldNotifications: any[] = [];
  selectedOldNotificationId: number = 1;
  
  newNotifications: any[] = [
    {
      id: 1,
      content: 'Tiene una cita próxima de «Especialidad» a las «hh:mm» con el «Especialista».',
      icon: 'error_outline',
      time: '1 hora',
      state: 'old',
      subMenu: 'old-icon'
    },
    {
      id: 2,
      content: 'Pague su cita reservada de «Especialidad» para el «dd/mm/aaaa» a las «hh:mm»',
      icon: 'work_outline',
      time: '1 hora',
      state: 'new',
      subMenu: 'new-icon'
    },
    {
      id: 3,
      content: 'Pague su cita reservada de «Especialidad» para el «dd/mm/aaaa» a las «hh:mm».  Perderá la reserva en 1 hora.',
      icon: 'videocam_outline',
      time: '1 hora',
      state: 'new',
      subMenu: 'new-icon'
    },
    {
      id: 4,
      content: 'Pague su recita de «Especialidad» agendada para el «dd/mm/aaaa» a las «hh:mm»',
      icon: 'content_paste',
      time: '1 hora',
      state: 'new',
      subMenu: 'new-icon'
    },
    {
      id: 5,
      content: 'Pague su recita de «Especialidad» agendada para el «dd/mm/aaaa» a las «hh:mm»',
      icon: 'note_add',
      time: '1 hora',
      state: 'new',
      subMenu: 'new-icon'
    },
  ];

  oldNotifications: any[] = [
    {
      id: 1,
      content: 'Le recordamos que tiene pendiente una cita de «Especialidad» reservada para el «dd/mm/aaaa» a las «hh:mm». La reserva se pierde en 1 hora.',
      icon: 'redeem',
      time: '',
      state: 'old',
      subMenu: 'old-icon'
    },
    {
      id: 2,
      content: 'Su médico le recuerda que tiene una cita de «Especialidad» en estado de reserva.m.',
      icon: 'home',
      time: '',
      state: 'old',
      subMenu: 'old-icon'
    },
    {
      id: 3,
      content: 'Tiene una nueva receta.',
      icon: 'device_thermostat',
      time: '',
      state: 'old',
      subMenu: 'old-icon'
    },
    {
      id: 4,
      content: 'Nueva orden de laboratorio cargada.',
      icon: 'videocam',
      time: '',
      state: 'old',
      subMenu: 'old-icon'
    },
    {
      id: 5,
      content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent molestie felis quis quam tempor convallis et id ipsum.',
      icon: 'bolt',
      time: '',
      state: 'old',
      subMenu: 'old-icon'
    },
  ];

  constructor() { 
      this.filteredNewNotifications = this.newNotifications;
      this.filteredOldNotifications = this.oldNotifications;
  }

  updateSelectedNewNotificationId(id): void {
    this.selectedNewNotificationId = id;
  }

  updateSelectedOldNotificationId(id): void {
    this.selectedOldNotificationId = id;
  }

  // updatesubMenuEvent(id): void {
  //   this.filteredNewNotifications = id
  // }

  ngOnInit(): void {
  }

}
