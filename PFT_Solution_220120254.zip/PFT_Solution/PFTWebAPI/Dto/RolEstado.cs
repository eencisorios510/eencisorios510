    namespace PFTWebAPI.Dto;
    public class RolEstado
    {
        public int EstadoId { get; set; }
        public int RolId { get; set; }
    }