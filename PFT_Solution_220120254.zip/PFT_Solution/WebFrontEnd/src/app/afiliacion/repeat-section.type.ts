import { Component, ChangeDetectorRef } from '@angular/core';
import { FieldArrayType } from '@ngx-formly/core';

@Component({
  selector: 'formly-repeat-section',
  templateUrl: 'repeat-section.type.html',
})
export class RepeatTypeComponent extends FieldArrayType {
  constructor(private cd: ChangeDetectorRef) {
    super();
  }

  add() {
    console.log('Add button clicked');
    if (!this.field.fieldGroup) {
      this.field.fieldGroup = [];
    }
    this.field.fieldGroup.push({
      key: `newField${this.field.fieldGroup.length}`,
      type: 'input',
      templateOptions: {
        label: `New Field ${this.field.fieldGroup.length + 1}`,
        placeholder: 'Enter value',
        required: true,
      },
    });
    console.log('New field added:', this.field.fieldGroup);
    this.cd.detectChanges(); // Forzar la detección de cambios
  }
}