import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pre-init',
  templateUrl: './pre-init.component.html',
  styleUrls: ['./pre-init.component.scss']
})
export class PreInitComponent implements OnInit {

  isEditing: boolean = false;

  duration: string = '40:00';

  @Output() startedEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
  }

}
