﻿namespace PFTWebAPI.Dto.Users;

public class UpdateRequest
{
    public string Username { get; set; }
    public int IdRol { get; set; }
}