import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationCardMedicalComponent } from './notification-card-medical.component';

describe('NotificationCardMedicalComponent', () => {
  let component: NotificationCardMedicalComponent;
  let fixture: ComponentFixture<NotificationCardMedicalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotificationCardMedicalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotificationCardMedicalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
