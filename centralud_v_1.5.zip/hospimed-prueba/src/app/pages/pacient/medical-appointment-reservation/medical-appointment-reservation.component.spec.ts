import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalAppointmentReservationComponent } from './medical-appointment-reservation.component';

describe('MedicalAppointmentReservationComponent', () => {
  let component: MedicalAppointmentReservationComponent;
  let fixture: ComponentFixture<MedicalAppointmentReservationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalAppointmentReservationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalAppointmentReservationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
