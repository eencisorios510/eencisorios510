import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutAfiliacionComponent } from './layout-afiliacion.component';
import { ListAfiliacionComponent } from './list-afiliacion.component';
import { AddEditAfiliacionComponent } from './add-edit-afiliacion.component';
import { DetalleAfiliacionComponent } from './detalle-afiliacion.component';
import { AddProductoAfiliacionComponent } from './add-producto-afiliacion.component';

const routes: Routes = [
    {
        path: '', component: LayoutAfiliacionComponent,
        children: [
            { path: '', component: ListAfiliacionComponent },
            { path: 'add', component: AddEditAfiliacionComponent },
            { path: 'detalle/:id', component: DetalleAfiliacionComponent },
            { path: 'addproducto/:id', component: AddProductoAfiliacionComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AfiliacionesRoutingModule { }