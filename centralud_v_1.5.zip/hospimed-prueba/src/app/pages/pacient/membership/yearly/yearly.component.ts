import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacient-yearly-plan',
  templateUrl: './yearly.component.html',
  styleUrls: ['./yearly.component.scss']
})
export class PacientYearlyPlanComponent implements OnInit {

  // hideSelect: boolean = true;

  subscriptionEndDate: Date = new Date('Mar 30 2021 00:00:00');;

  constructor() { }

  ngOnInit(): void {
  }

}
