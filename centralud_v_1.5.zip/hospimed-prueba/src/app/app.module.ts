import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MAT_DATE_LOCALE } from '@angular/material/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './layout/components/header/header.component';
import { FooterComponent } from './layout/components/footer/footer.component';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatSelectModule} from '@angular/material/select';
import {MatInputModule} from '@angular/material/input';
import {MatIconModule} from '@angular/material/icon';
import {MatMenuModule} from '@angular/material/menu';
import {MatTabsModule} from '@angular/material/tabs';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatCardModule} from '@angular/material/card';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';
import {MatSliderModule} from '@angular/material/slider';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatBadgeModule} from '@angular/material/badge';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatRadioModule} from '@angular/material/radio';
import {MatDividerModule} from '@angular/material/divider';
import {MatTableModule} from '@angular/material/table';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import {MatRippleModule} from '@angular/material/core';
import {MatDialogModule} from '@angular/material/dialog';
import {MatChipsModule} from '@angular/material/chips';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSnackBarModule} from '@angular/material/snack-bar';

import {LocationStrategy, HashLocationStrategy} from '@angular/common';

import { SwiperModule } from 'swiper/angular';
import { ComponentsComponent } from './pages/components/components.component';
import { StepperComponent } from './components/stepper/stepper.component';
import { CheckListComponent } from './components/check-list/check-list.component';
import { TopBarComponent } from './layout/components/top-bar/top-bar.component';
import { SideBarComponent } from './layout/components/side-bar/side-bar.component';
import { DashboardLayoutComponent } from './layout/dashboard-layout/dashboard-layout.component';
import { LoginComponent } from './pages/doctor/login/login.component';
import { RegisterComponent } from './pages/doctor/register/register.component';
import { PasswordRecoveryComponent } from './pages/doctor/password-recovery/password-recovery.component';
import { PlansComponent } from './pages/doctor/dashboard/plans-pages/plans/plans.component';
import { YearlyPlanComponent } from './pages/doctor/dashboard/plans-pages/yearly-plan/yearly-plan.component';
import { YearlyMembershipComponent } from './pages/doctor/dashboard/plans-pages/yearly-membership/yearly-membership.component';
import { MonthlyMembershipComponent } from './pages/doctor/dashboard/plans-pages/monthly-membership/monthly-membership.component';
import { HonorariumComponent } from './pages/doctor/dashboard/honorarium/honorarium.component';
import { InvitationsComponent } from './pages/doctor/dashboard/invitations/invitations.component';


import { DoctorDashboardComponent } from './pages/doctor/dashboard/dashboard.component';
import { PacientDashboardComponent } from './pages/pacient/dashboard/dashboard.component';
import { ValidateRegistrationDataComponent } from './pages/doctor/validate-registration-data/validate-registration-data.component';
import { QuoteCardComponent } from './components/quote-card/quote-card.component';
import { ProfileComponent } from './pages/doctor/dashboard/profile/profile.component';
import { DialogComponent } from './dialog/dialog.component';
import { FirstStepComponent } from './pages/doctor/dashboard/profile/first-step/first-step.component';
import { SecondStepComponent } from './pages/doctor/dashboard/profile/second-step/second-step.component';
import { ThirdStepComponent } from './pages/doctor/dashboard/profile/third-step/third-step.component';
import { CounterComponent } from './components/counter/counter.component';
import { AlertComponent } from './components/alert/alert.component';
import { UploadFileComponent } from './components/upload-file/upload-file.component';
import { TurnScheduleComponent } from './pages/doctor/dashboard/turn-schedule/turn-schedule.component';
import { ScheduleSliderComponent } from './components/schedule-slider/schedule-slider.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { CreateTurnDialogComponent } from './pages/doctor/dashboard/turn-schedule/create-turn-dialog/create-turn-dialog.component';
import { QuotesComponent } from './pages/doctor/dashboard/quotes/quotes.component';
import { QuoteItemComponent } from './components/quote-item/quote-item.component';

import { ChartsModule } from 'ng2-charts';
import { CountdownComponent } from './components/countdown/countdown.component';
import { HeaderAnnouncementComponent } from './layout/components/header-announcement/header-announcement.component';
import { ChatComponent } from './components/chat/chat.component';
import { ChatMessageComponent } from './components/chat/chat-message/chat-message.component';
import { LineChartComponent } from './components/line-chart/line-chart.component';
import { DoughnutChartComponent } from './components/doughnut-chart/doughnut-chart.component';
import { BarChartComponent } from './components/bar-chart/bar-chart.component';
import { VideoCallComponent } from './pages/doctor/dashboard/quotes/video-call/video-call.component';
import { QuoteDurationBulletComponent } from './components/quote-duration-bullet/quote-duration-bullet.component';
import { PacientLayoutComponent } from './layout/pacient-layout/pacient-layout.component';
import { MembershipComponent } from './pages/pacient/membership/membership.component';
import { PacientBasicPlanComponent } from './pages/pacient/membership/basic/basic.component';
import { PacientMonthlyPlanComponent } from './pages/pacient/membership/monthly/monthly.component';
import { PacientYearlyPlanComponent } from './pages/pacient/membership/yearly/yearly.component';
import { MonthlyPlanCardComponent } from './components/monthly-plan-card/monthly-plan-card.component';
import { YearlyPlanCardComponent } from './components/yearly-plan-card/yearly-plan-card.component';
import { MedicalAppointmentReservationComponent } from './pages/pacient/medical-appointment-reservation/medical-appointment-reservation.component';
import { DoctorCardComponent } from './components/doctor-card/doctor-card.component';
import { PickTurnComponent } from './pages/pacient/medical-appointment-reservation/pick-turn/pick-turn.component';
import { CheckoutComponent } from './pages/pacient/medical-appointment-reservation/checkout/checkout.component';
import { DoneComponent } from './pages/pacient/medical-appointment-reservation/done/done.component';
import { MedicalFormComponent } from './pages/pacient/medical-form/medical-form.component';
import { AntecedentesComponent } from './pages/pacient/medical-form/antecedentes/antecedentes.component';
import { GinecologicasComponent } from './pages/pacient/medical-form/ginecologicas/ginecologicas.component';
import { AlergiasComponent } from './pages/pacient/medical-form/alergias/alergias.component';
import { InvitationsPatientComponent } from './pages/pacient/dashboard/invitations-patient/invitations-patient.component';
import { TrackingComponent } from './pages/pacient/dashboard/tracking/tracking.component';
import { PreviewComponent } from './pages/doctor/dashboard/quotes/video-call/preview/preview.component';
import { HchComponent } from './pages/doctor/dashboard/quotes/video-call/hch/hch.component';
import { LeftModalComponent } from './components/left-modal/left-modal.component';
import { VideoStreamingComponent } from './components/video-streaming/video-streaming.component';
import { PacientHistoryComponent } from './pages/doctor/dashboard/quotes/video-call/pacient-history/pacient-history.component';
import { VideocallAntecedentesComponent } from './pages/doctor/dashboard/quotes/video-call/videocall-antecedentes/videocall-antecedentes.component';
import { AttentionsComponent } from './pages/pacient/dashboard/quotes/video-calls/attentions/attentions.component';
import { VideoComponent } from './pages/pacient/dashboard/quotes/video-calls/video/video.component';
import { HomeComponent } from './pages/pacient/dashboard/home/home.component';
import { MedicalCardComponent } from './components/medical-card/medical-card.component';
import { QuoteItemPatientComponent } from './components/quote-item-patient/quote-item-patient.component';
import { AttentionsPatientsComponent } from './pages/pacient/attentions/attentions.component';
import { HelpCenterComponent } from './pages/doctor/dashboard/help-center/help-center.component';
import { CampaignsPanelComponent } from './pages/doctor/dashboard/campaigns-panel/campaigns-panel.component';

import { MyAttentionsCardComponent } from './components/my-attentions-card/my-attentions-card.component';
import { MessagesComponent } from './pages/pacient/attentions/messages/messages.component';
import { PendingPaymentComponent } from './pages/pacient/attentions/pending-payment/pending-payment.component';
import { MedicalExamsComponent } from './pages/pacient/attentions/medical-exams/medical-exams.component';
import { NextAttentionsComponent } from './pages/pacient/attentions/next-attentions/next-attentions.component';
import { MedicalRecordComponent } from './pages/pacient/attentions/medical-record/medical-record.component';
import { StartVideocallComponent } from './pages/pacient/attentions/start-videocall/start-videocall.component';
import { NotificationCardComponent } from './components/notification-card/notification-card.component';
import { NewNotificationsCardComponent } from './components/notification-card/new-notifications-card/new-notifications-card.component';
import { OldNotificationsCardComponent } from './components/notification-card/old-notifications-card/old-notifications-card.component';
import { ConfirmationComponent } from './components/notification-card/confirmation/confirmation.component';
import { DashboardPatientsCarouselComponent } from './components/dashboard-patients-carousel/dashboard-patients-carousel.component';
import { TopBarPatientsComponent } from './layout/components/top-bar-patients/top-bar-patients.component';
import { NotificationCardMedicalComponent } from './components/notification-card/notification-card-medical/notification-card-medical.component';
import { AuxiliaryExamsComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/auxiliary-exams/auxiliary-exams.component';
import { RecipeComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/recipe/recipe.component';
import { InterconsultationComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/interconsultation/interconsultation.component';
import { MedicalBoardComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/medical-board/medical-board.component';
import { NextAppointmentComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/next-appointment/next-appointment.component';
import { MedicalRestComponent } from './pages/doctor/dashboard/quotes/video-call/workplan/medical-rest/medical-rest.component';
import { ReportsComponent } from './pages/doctor/dashboard/reports/reports.component';
import { MedicalBoardDoctorComponent } from './pages/doctor/dashboard/medical-board-doctor/medical-board-doctor.component';
import { PreInitComponent } from './pages/doctor/dashboard/medical-board-doctor/pre-init/pre-init.component';
import { HCEReportComponent } from './pages/doctor/dashboard/hce-report/hce-report.component';
import { PreviewInformationComponent } from './pages/doctor/dashboard/medical-board-doctor/preview-information/preview-information.component';
import { ProfileRecordComponent } from './pages/doctor/dashboard/profile-record/profile-record.component';
import { PopUpRxhComponent } from './pages/doctor/dashboard/profile-record/pop-up-rxh/pop-up-rxh.component';
import { PatientMonitoringComponent } from './pages/doctor/dashboard/patient-monitoring/patient-monitoring.component';
import { PatientProfileComponent } from './pages/pacient/dashboard/patient-profile/patient-profile.component';
import { AddChildComponent } from './pages/pacient/dashboard/patient-profile/add-child/add-child.component';
import { SecondGroupCardsComponent } from './components/my-attentions-card/second-group-cards/second-group-cards.component';
import { ThirdGroupCardsComponent } from './components/my-attentions-card/third-group-cards/third-group-cards.component';
import { ModalEditProfileComponent } from './pages/pacient/dashboard/patient-profile/modal-edit-profile/modal-edit-profile.component';
import { QuoteCardTrackingComponent } from './components/quote-card-tracking/quote-card-tracking.component';
import { QuoteCardCalendarTrackingComponent } from './components/quote-card-calendar-tracking/quote-card-calendar-tracking.component';
import { ScheduleSliderTrackingComponent } from './components/schedule-slider-tracking/schedule-slider-tracking.component';

import { DndDirective } from './dnd.directive';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { ChangePasswordComponent } from './pages/doctor/dashboard/profile/change-password/change-password.component';
import { ClinicHistoryComponent } from './pages/doctor/dashboard/quotes/video-call/clinic-history/clinic-history.component';
import { EnterPinComponent } from './pages/doctor/dashboard/quotes/video-call/clinic-history/enter-pin/enter-pin.component';
import { EndCallComponent } from './components/video-streaming/end-call/end-call.component';

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HeaderComponent,
    FooterComponent,
    ComponentsComponent,
    StepperComponent,
    CheckListComponent,
    TopBarComponent,
    SideBarComponent,
    DashboardLayoutComponent,
    LoginComponent,
    RegisterComponent,
    PasswordRecoveryComponent,
    PlansComponent,
    YearlyPlanComponent,
    YearlyMembershipComponent,
    MonthlyMembershipComponent,
    HonorariumComponent,
    InvitationsComponent,
    DoctorDashboardComponent,
    PacientDashboardComponent,
    ValidateRegistrationDataComponent,
    QuoteCardComponent,
    ProfileComponent,
    DialogComponent,
    FirstStepComponent,
    SecondStepComponent,
    ThirdStepComponent,
    CounterComponent,
    AlertComponent,
    UploadFileComponent,
    TurnScheduleComponent,
    ScheduleSliderComponent,
    CreateTurnDialogComponent,
    QuotesComponent,
    QuoteItemComponent,
    CountdownComponent,
    HeaderAnnouncementComponent,
    ChatComponent,
    ChatMessageComponent,
    LineChartComponent,
    DoughnutChartComponent,
    BarChartComponent,
    VideoCallComponent,
    QuoteDurationBulletComponent,
    PacientLayoutComponent,
    MembershipComponent,
    PacientBasicPlanComponent,
    PacientMonthlyPlanComponent,
    PacientYearlyPlanComponent,
    MonthlyPlanCardComponent,
    YearlyPlanCardComponent,
    MedicalAppointmentReservationComponent,
    DoctorCardComponent,
    PickTurnComponent,
    CheckoutComponent,
    DoneComponent,
    MedicalFormComponent,
    AntecedentesComponent,
    GinecologicasComponent,
    AlergiasComponent,
    InvitationsPatientComponent,
    TrackingComponent,
    PreviewComponent,
    HchComponent,
    LeftModalComponent,
    VideoStreamingComponent,
    PacientHistoryComponent,
    VideocallAntecedentesComponent,
    AttentionsComponent,
    VideoComponent,
    HCEReportComponent,
    HelpCenterComponent,
    CampaignsPanelComponent,
    HomeComponent,
    MedicalCardComponent,
    QuoteItemPatientComponent,
    MyAttentionsCardComponent,
    MessagesComponent,
    PendingPaymentComponent,
    MedicalExamsComponent,
    NextAttentionsComponent,
    MedicalRecordComponent,
    StartVideocallComponent,
    NotificationCardComponent,
    NewNotificationsCardComponent,
    OldNotificationsCardComponent,
    ConfirmationComponent,
    DashboardPatientsCarouselComponent,
    TopBarPatientsComponent,
    NotificationCardMedicalComponent,
    AuxiliaryExamsComponent,
    RecipeComponent,
    InterconsultationComponent,
    MedicalBoardComponent,
    NextAppointmentComponent,
    MedicalRestComponent,
    ReportsComponent,
    MedicalBoardDoctorComponent,
    AttentionsPatientsComponent,
    PreInitComponent,
    PreviewInformationComponent,
    ProfileRecordComponent,
    PopUpRxhComponent,
    PatientMonitoringComponent,
    PatientProfileComponent,
    AddChildComponent,
    SecondGroupCardsComponent,
    ThirdGroupCardsComponent,
    ModalEditProfileComponent,
    QuoteCardTrackingComponent,
    QuoteCardCalendarTrackingComponent,
    ScheduleSliderTrackingComponent,
    ReportsComponent,
    DndDirective,
    NotFoundComponent,
    ChangePasswordComponent,
    ClinicHistoryComponent,
    EnterPinComponent,
    EndCallComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatIconModule,
    MatMenuModule,
    MatTabsModule,
    MatButtonToggleModule,
    MatExpansionModule,
    MatCardModule,
    MatPaginatorModule,
    MatSlideToggleModule,
    MatBadgeModule,
    MatSidenavModule,
    MatRadioModule,
    SwiperModule,
    MatDividerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRippleModule,
    MatTableModule,
    MatDialogModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSortModule,
    MatSliderModule,
    CarouselModule,
    ChartsModule,
    MatSnackBarModule
  ],
  providers: [
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    },
    {
      provide: MAT_DATE_LOCALE,
      useValue: 'es-ES'
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
