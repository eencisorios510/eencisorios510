using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PFTWebAPI.Authorization;
using PFTWebAPI.Helpers;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Dto.AtencionSolicitud;
using PFTWebAPI.Services;
using System.DirectoryServices.AccountManagement;

namespace PFTWebAPI.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class AtencionController : ControllerBase
    {
        private IAtencionSolicitudService _atencionService;
        private IMapper _mapper;
        private readonly AppSettings _appSettings;
        private IJwtUtils _jwtUtils;
        public AtencionController(
            IAtencionSolicitudService atencionService,
            IMapper mapper,
            IOptions<AppSettings> appSettings,
            IJwtUtils jwtUtils)
        {
            _atencionService = atencionService;
            _mapper = mapper;
            _appSettings = appSettings.Value;
            _jwtUtils = jwtUtils;
        }
       
        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register(RegisterRequestAtencion model)
        {
            _atencionService.Register(model);
            return Ok(new { message = "Registro exitoso" });
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult GetAll()
        {
            var users = _atencionService.GetAll();
            return Ok(users);
        }

        [AllowAnonymous]
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var user = _atencionService.GetById(id);
            return Ok(user);
        }

        [AllowAnonymous]
        [HttpGet("GetByIdSolicitud/{IdAfilicacion}")]
        public IActionResult GetByIdSolicitud(int IdAfilicacion)
        {
            var user = _atencionService.GetByIdSolicitud(IdAfilicacion);
            return Ok(user);
        }        

    }
}
