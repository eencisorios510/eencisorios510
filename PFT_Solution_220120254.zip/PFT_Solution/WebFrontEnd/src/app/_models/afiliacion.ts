export class Afiliacion {
    id: string;
    solicitante: string;
    correoSolicitante: string;
    fechaIngresoSolicitud: string;
    idEstadoSolicitud: string;
    empresaAfiliacion: string;
    contactoEmpresa: string;
    idAreaSolicitante: string;
    correoContactoEmpresa: string;
    idProducto: string;
    flujoInformacion: string;
    datosDac: string;     
    tipoEncriptacion: string;
    especialistaComercial: string;
    idAplicacionSolicitante: string;
    responsable: string;
    detalleSolicitud: string;
    archivoAdjunto: string; 
    desc_AreaSolicitante:string;
    desc_Producto:string;
    desc_AplicacionSolicitante:string;
    desc_EstadoSolicitud:string;
}