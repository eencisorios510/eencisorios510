﻿import { Component,inject } from '@angular/core';

import { User } from '@app/_models';
import { AccountService } from '@app/_services';

@Component({ templateUrl: 'home.component.html' })
export class HomeComponent {
    private readonly accountService = inject(AccountService);
    user: User;

    constructor() {
        this.user = this.accountService.userValue;
    }
}