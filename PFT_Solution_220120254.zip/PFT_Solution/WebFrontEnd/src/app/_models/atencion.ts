export class Atencion {
    boton:string;
    idEstado: string;
    idAfilicacion: string;
    fecha_ingresado: string;
    usuario: string;
    comentario: string;
    idEstadoSolicitud: string;
    desc_Estado: string;
}