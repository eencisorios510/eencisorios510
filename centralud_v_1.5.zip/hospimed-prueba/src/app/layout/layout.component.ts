import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit {

  headerLight: boolean = false;

  menuItems = [
    { icon: '/assets/images/sidebar/turnos-icon.svg', name: 'Turnos' },
    { icon: '/assets/images/sidebar/citados-icon.svg', name: 'Citados' },
    { icon: '/assets/images/sidebar/teleconsulta-icon.svg', name: 'Teleconsulta' },
    { icon: '/assets/images/sidebar/seguimiento-icon.svg', name: 'Seguimiento' },
    { icon: '/assets/images/sidebar/campanas-icon.svg', name: 'Campañas' },
    { icon: '/assets/images/sidebar/junta-medica-icon.svg', name: 'Junta médica' },
    { icon: '/assets/images/sidebar/honorarios-icon.svg', name: 'Honorarios' },
    { icon: '/assets/images/sidebar/reporteria-icon.svg', name: 'Reportería' }
  ];

  constructor(private router: Router) {
    router.events.subscribe((val) => {
      this.headerLight = 'url' in val && val.url === '/';
    })
  }

  ngOnInit(): void {
  }

}
