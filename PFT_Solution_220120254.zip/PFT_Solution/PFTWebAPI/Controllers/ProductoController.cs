using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto;
using System.Linq.Expressions;
using Microsoft.AspNetCore.Authorization.Infrastructure;

namespace PFTWebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProductoController 
        : CrudController<Producto, ProductoGetDto, ProductoCreateDto, ProductoCreateDto>
    {
        public ProductoController(DataContext context, IMapper mapper)
            : base(context, mapper)
        {
        }

    }
}
