import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EndCallComponent } from './end-call.component';

describe('EndCallComponent', () => {
  let component: EndCallComponent;
  let fixture: ComponentFixture<EndCallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndCallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EndCallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
