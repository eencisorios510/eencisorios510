import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-quote-item',
  templateUrl: './quote-item.component.html',
  styleUrls: ['./quote-item.component.scss']
})
export class QuoteItemComponent implements OnInit {

  @Input() quote;

  @Input() isSelected: boolean = false;

  @Output() changeSelectedQuoteEvent = new EventEmitter<Number>();

  constructor() { }

  ngOnInit(): void {
  }

}
