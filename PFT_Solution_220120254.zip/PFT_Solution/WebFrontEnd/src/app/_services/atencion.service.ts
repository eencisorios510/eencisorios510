import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '@environments/environment';
import { Atencion } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class AtencionService {

    constructor(
        private router: Router,
        private http: HttpClient
    ) {

    }

    register(atencion: Atencion) {
        console.log("atencion");
        console.log(atencion);
        return this.http.post(`${environment.apiUrl}/Atencion/register`, atencion);
    }

    getAll() {
        return this.http.get<Atencion[]>(`${environment.apiUrl}/Atencion`);
    }

    getById(id: string) {
        return this.http.get<Atencion>(`${environment.apiUrl}/Atencion/${id}`);
    }

    GetByIdAfiliacion(idAfiliacion: string) {
        return this.http.get<Atencion[]>(`${environment.apiUrl}/Atencion/GetByIdAfiliacion/${idAfiliacion}`);
    }

}