﻿import { Component, OnInit, inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators, FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { AfiliacionService, AlertService, AtencionService } from '@app/_services';
import { User } from '@app/_models';
import { Atencion,AfiliacionDetailButon } from '@app/_models';
declare var $: any;

@Component({ templateUrl: 'detalle-afiliacion.component.html' })
export class DetalleAfiliacionComponent implements OnInit {
    private userSubject: BehaviorSubject<User>;
    selectedFile: File = null;
    formAtencion: UntypedFormGroup;
    id: string;
    newEstado: string;
    loading = false;
    submitted = false;
    atenciones: Atencion[] = [];
    nroSolicitud: string;
    solicitante: string;
    correoSolicitante: string;
    fechaIngresoSolicitud: string;
    desc_EstadoSolicitud: string;
    empresaAfiliacion: string;
    contactoEmpresa: string;
    desc_AreaSolicitante: string;
    correoContactoEmpresa:string;
    desc_Producto: string;
    flujoInformacion: string;
    datosDac: string;
    tipoEncriptacion: string;
    especialistaComercial: string;
    desc_AplicacionSolicitante: string;
    responsable : string;
    detalleSolicitud: string;
    idEstadoSolicitud:string;
    botones: AfiliacionDetailButon[] = [];

    private readonly afiliacionService = inject(AfiliacionService);
    private readonly atencionService = inject(AtencionService);

    constructor(
        private formBuilder: UntypedFormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private alertService: AlertService
    ) {
        this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));    
    }

    ngOnInit() {
        this.id = this.route.snapshot.params['id'];   
        this.afiliacionService.getAfiliacionById(this.id)
        .pipe(first())
        .subscribe(x => {
            console.log("x");
            console.log(x);
            this.nroSolicitud = x.id; 
            this.solicitante = x.solicitante; 
            this.correoSolicitante = x.correoSolicitante; 
            this.fechaIngresoSolicitud = x.fechaIngresoSolicitud; 
            this.desc_EstadoSolicitud = x.desc_EstadoSolicitud; 
            this.empresaAfiliacion = x.empresaAfiliacion; 
            this.contactoEmpresa = x.contactoEmpresa; 
            this.desc_AreaSolicitante = x.desc_AreaSolicitante; 
            this.correoContactoEmpresa = x.correoContactoEmpresa; 
            this.desc_Producto = x.desc_Producto; 
            this.flujoInformacion = x.flujoInformacion; 
            this.datosDac = x.datosDac; 
            this.tipoEncriptacion = x.tipoEncriptacion; 
            this.especialistaComercial = x.especialistaComercial; 
            this.desc_AplicacionSolicitante = x.desc_AplicacionSolicitante; 
            this.responsable = x.responsable; 
            this.detalleSolicitud = x.detalleSolicitud; 
            this.idEstadoSolicitud = x.idEstadoSolicitud;  
            this.formAtencion.patchValue({
              idEstadoSolicitud: this.idEstadoSolicitud
          });
          console.log("(this.userValue");
          console.log(this.userValue);
          console.log("this.userValue.rolId");
          console.log(this.userValue.rolId);
          console.log("this.idEstadoSolicitud");
          console.log(this.idEstadoSolicitud);
          this.getFormDetail(this.userValue.rolId, this.idEstadoSolicitud);
        });

        console.log("this.id");
        console.log(this.id);
        this.atencionService.GetByIdAfiliacion(this.id)
        .pipe(first())
        .subscribe(atenciones => {
          console.log("atenciones", atenciones);
          this.atenciones = atenciones;
        });

        this.formAtencion = this.formBuilder.group({
          boton: ['0'],
          comentario: ['', Validators.required],
          idAfilicacion: [this.id],
          usuario: [this.userValue.username],
          idEstadoSolicitud:[this.idEstadoSolicitud]
      });   
 
    }

    getFormDetail(rolId: string, estadoId: string): void {
      this.loading = true;
      this.afiliacionService.getButonsformAfliacionesDetail(rolId, estadoId).subscribe(
        data => {
          this.botones = data;
          console.log("this.botones");
          console.log(this.botones);
          this.loading = false;
        },
        error => {
          console.error('Error fetching form detail', error);
          this.loading = false;
        }
      );
    }
  
/*     getFormDetail(rolId: string, estadoId: string): void {
      this.afiliacionService.getButonsformAfliacionesDetail(rolId, estadoId).subscribe(
        data => {
          this.botones = data;
        },
        error => {
          console.error('Error fetching form detail', error);
        }
      );
    }  */

    public get userValue(): User {
        return this.userSubject.value;
    }
    get f() { return this.formAtencion.controls; }

    setBoton(boton: string) {
      console.log("boton4");
      console.log(boton);
        this.formAtencion.get('boton').setValue(boton);
      }
    
      onSubmitSig() {
        $('#comentarioModal').modal('hide');
        console.log("onSubmitSig()");
        this.submitted = true;
        this.alertService.clear();
    
        if (this.formAtencion.invalid) {
          console.log("return");
          return;
        }
    
        this.loading = true;
        this.createAtencion();
      }
    
      private createAtencion() {
        this.atencionService.register(this.formAtencion.value)
          .pipe(first())
          .subscribe({
            next: () => {
              this.alertService.success('Atencion agregada exitosamente', { keepAfterRouteChange: true });
              this.router.navigate(['/afiliaciones']);
              this.loading = false;
            },
            error: error => {
              this.alertService.error(error);
              console.error('There was an error!', error);
              this.loading = false;
            }
          });
      }

    onFileSelected(event) {
        this.selectedFile = event.target.files[0];
      }
}

