import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalBoardComponent } from './medical-board.component';

describe('MedicalBoardComponent', () => {
  let component: MedicalBoardComponent;
  let fixture: ComponentFixture<MedicalBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalBoardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
