import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-start-videocall',
  templateUrl: './start-videocall.component.html',
  styleUrls: ['./start-videocall.component.scss']
})
export class StartVideocallComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
