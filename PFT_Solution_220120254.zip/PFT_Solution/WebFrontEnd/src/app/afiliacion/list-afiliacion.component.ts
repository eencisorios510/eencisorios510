﻿import { Component, OnInit, inject } from '@angular/core';
import { first } from 'rxjs/operators';
import { User } from '@app/_models';
import { AfiliacionService } from '@app/_services';
import { BehaviorSubject, Observable } from 'rxjs';

@Component({ templateUrl: 'list-afiliacion.component.html' })
export class ListAfiliacionComponent implements OnInit {
    private userSubject: BehaviorSubject<User>;

    afiliaciones = [];
    totalRecords = 0;
    pageSize = 10;
    page = 1;
    filter = '';

    private readonly afiliacionService = inject(AfiliacionService);
    constructor() {
      this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user'))); 
    }

    ngOnInit() {
        this.loadAfiliaciones(); 
    }

    public get userValue(): User {
      return this.userSubject.value;
    }

    loadAfiliaciones(): void {
        this.afiliacionService.getAllAfiliacion(this.page, this.pageSize, this.filter).subscribe(data => {
          console.log('data')
          console.log(data)
          console.log('data.data')
          console.log(data.data)
          console.log('data.totalRecords')
          console.log(data.totalRecords)
          this.afiliaciones = data.data;
          this.totalRecords = data.totalRecords;
        });
      }
    
      onPageChange(page: number): void {
        this.page = page;
        this.loadAfiliaciones();
      }
    
      onFilterChange(filter: string): void {
        this.filter = filter;
        this.loadAfiliaciones();
      }    

      onButtonClickMisRegistros() {
        this.filter = this.userValue.email;
        this.loadAfiliaciones();
      }
    deleteAfiliacion(id: string) {
        const afiliacion = this.afiliaciones.find(x => x.id === id);
        afiliacion.isDeleting = true;
        this.afiliacionService.deleteAfiliacion(id)
            .pipe(first())
            .subscribe(() => this.afiliaciones = this.afiliaciones.filter(x => x.id !== id));
    }   

}