import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { BcpTitleModule } from '@bcp/ng-ui-components';
import { AfiliacionesRoutingModule } from './afiliaciones-routing.module';
import { LayoutAfiliacionComponent } from './layout-afiliacion.component';
import { ListAfiliacionComponent } from './list-afiliacion.component';
import { AddEditAfiliacionComponent } from './add-edit-afiliacion.component';
import { DetalleAfiliacionComponent } from './detalle-afiliacion.component';
import { AddProductoAfiliacionComponent } from './add-producto-afiliacion.component';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { FormlyModule } from '@ngx-formly/core';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
import { RepeatTypeComponent } from './repeat-section.type';
import { FormsModule } from '@angular/forms'; // Importa FormsModule

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        NgbModule,
        BcpTitleModule,
        AfiliacionesRoutingModule,
        FormsModule,
        FormlyModule.forRoot({
            types: [
              { name: 'repeat', component: RepeatTypeComponent },
            ],
          }),
        FormlyBootstrapModule,
    ],
    declarations: [
        LayoutAfiliacionComponent,
        ListAfiliacionComponent,
        AddEditAfiliacionComponent,
        DetalleAfiliacionComponent,
        AddProductoAfiliacionComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AfiliacionesModule { }