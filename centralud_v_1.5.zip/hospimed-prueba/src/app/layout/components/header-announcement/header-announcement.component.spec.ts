import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderAnnouncementComponent } from './header-announcement.component';

describe('HeaderAnnouncementComponent', () => {
  let component: HeaderAnnouncementComponent;
  let fixture: ComponentFixture<HeaderAnnouncementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderAnnouncementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderAnnouncementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
