export class AfiliacionCombo {
    id: string;
    nombre: string;
}