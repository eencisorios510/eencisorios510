import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import AOS from 'aos';
import { OwlOptions } from 'ngx-owl-carousel-o';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class PacientDashboardComponent implements OnInit {

  customOptions: OwlOptions = {
    loop: true,
    margin: 20,
    dots: false,
    nav: true,
    items: 4,
    navText: ['<div class="material-icons">arrow_back_ios_new</div>', '<div class="material-icons">arrow_forward_ios</div>'],
  }

  public todayQuotes = [];

  @Input() cardTitle: string = null;

  @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

  stateCtrl = new FormControl();
  searchHistory: any[] = [];
  filteredSearchHistory: Observable<any[]>;

  searchInputState: string = 'blur'; // blur, focus

  filteredDoctors: any[] = [];


  constructor() {
  
    this.filteredSearchHistory = this.stateCtrl.valueChanges
      .pipe(
        startWith(''),
        map(search => search ? this._filterSearchHistory(search) : this.searchHistory.slice())
      );
   }

   private _filterSearchHistory(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.searchHistory.filter(search => search.toLowerCase().indexOf(filterValue) === 0);
  }

  searchInputFocus(): void {
    this.searchInputState = 'focus';
  }

  searchInputBlur(): void {
    this.searchInputState = 'blur';
  }

  getSearchHistory(): void {
    this.searchHistory = [
      'Dr. Aldo Mercado Ramirez',
      'Dra. Melany Oré Capcha',
      'Dermatología',
      'Dr. Aldo Nakaruma Carrillo'
    ];
  }

  getTodayQuotes():void {
    this.todayQuotes = [{ id: 1 }, { id: 2}, { id: 3 }, { id: 4 }, { id: 5 }, { id: 6 }, { id: 7 }, { id: 8 }, { id: 9 },];
  }

  ngOnInit(): void {
    this.getTodayQuotes();
    this.getSearchHistory();
    AOS.init()
  }

}
