import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondGroupCardsComponent } from './second-group-cards.component';

describe('SecondGroupCardsComponent', () => {
  let component: SecondGroupCardsComponent;
  let fixture: ComponentFixture<SecondGroupCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondGroupCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondGroupCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
