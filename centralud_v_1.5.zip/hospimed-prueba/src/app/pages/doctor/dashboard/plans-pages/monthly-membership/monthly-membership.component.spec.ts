import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MonthlyMembershipComponent } from './monthly-membership.component';

describe('MonthlyMembershipComponent', () => {
  let component: MonthlyMembershipComponent;
  let fixture: ComponentFixture<MonthlyMembershipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MonthlyMembershipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MonthlyMembershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
