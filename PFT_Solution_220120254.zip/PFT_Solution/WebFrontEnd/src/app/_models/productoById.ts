export class ProductoById {
    id: string;
    nombre: string;
    contratoJson: string;
}