import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { GuserRoutingModule } from './guser-routing.module';
import { Layout2Component } from './layout2.component';
import { RegistroGUsuarioComponent } from './registro.component';
import { ListguserComponent } from './listguser.component';
import { VerComponent } from './ver.component';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        GuserRoutingModule
    ],
    declarations: [
        Layout2Component,
        RegistroGUsuarioComponent,
        ListguserComponent,
        VerComponent
        
    ]
})
export class GuserModule { }