import { AfterViewInit, Component, ViewChild } from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';

export interface PeriodicElement {
  number: string;
  date: string;
  name: string;
  lastname: string;
  age: string;
  gender: string;
  numberhce: string;
}

const ELEMENT_DATA: PeriodicElement[] = [
  {number:'2', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'3', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587', },
  {number:'4', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'5', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587', },
  {number:'6', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'7', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'8', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'9', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'10', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'11', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'12', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'13', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
  {number:'14', date: '20/05/2021' , name: 'Aldo Jose', lastname:'Aldo Jose', age: '38', gender: 'M', numberhce:'09565587',},
];

@Component({
  selector: 'app-hce-report',
  templateUrl: './hce-report.component.html',
  styleUrls: ['./hce-report.component.scss']
})
export class HCEReportComponent implements AfterViewInit { 

  displayedColumns: string[] = ['number', 'date', 'name', 'lastname', 'age', 'gender', 'numberhce', 'download'];
  dataSource = new MatTableDataSource<PeriodicElement>(ELEMENT_DATA);

  @ViewChild(MatPaginator) paginator!: MatPaginator;

  ngAfterViewInit () {
    this.dataSource.paginator = this.paginator;
  }

  constructor() { }

  ngOnInit(): void {
  }

}
