import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StartVideocallComponent } from './start-videocall.component';

describe('StartVideocallComponent', () => {
  let component: StartVideocallComponent;
  let fixture: ComponentFixture<StartVideocallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StartVideocallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StartVideocallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
