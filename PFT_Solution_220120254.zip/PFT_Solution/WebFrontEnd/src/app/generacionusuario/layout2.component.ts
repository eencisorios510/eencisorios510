﻿
import { Component } from '@angular/core';

@Component({ templateUrl: 'layout2.component.html' })
export class Layout2Component { }