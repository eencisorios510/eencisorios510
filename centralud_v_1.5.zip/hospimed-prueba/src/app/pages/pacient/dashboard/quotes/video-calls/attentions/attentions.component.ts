import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-attentions',
  templateUrl: './attentions.component.html',
  styleUrls: ['./attentions.component.scss']
})

export class AttentionsComponent implements OnInit {

  @Output() showChatEvent = new EventEmitter<boolean>();

  isHidden: boolean = false;

  started: boolean = true;

  showChatModal: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  updateStarted(value): void {
    this.started = value;
  }
}

