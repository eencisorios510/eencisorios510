import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyMembershipComponent } from './yearly-membership.component';

describe('YearlyMembershipComponent', () => {
  let component: YearlyMembershipComponent;
  let fixture: ComponentFixture<YearlyMembershipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearlyMembershipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyMembershipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
