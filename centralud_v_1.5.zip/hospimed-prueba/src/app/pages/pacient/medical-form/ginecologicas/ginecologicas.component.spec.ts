import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GinecologicasComponent } from './ginecologicas.component';

describe('GinecologicasComponent', () => {
  let component: GinecologicasComponent;
  let fixture: ComponentFixture<GinecologicasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GinecologicasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GinecologicasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
