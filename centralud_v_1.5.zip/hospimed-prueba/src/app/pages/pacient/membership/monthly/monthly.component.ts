import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacient-monthly-plan',
  templateUrl: './monthly.component.html',
  styleUrls: ['./monthly.component.scss']
})
export class PacientMonthlyPlanComponent implements OnInit {

  subscriptionEndDate: Date = new Date('Mar 21 2021 00:00:00');;

  constructor() { }

  ngOnInit(): void {
  }

}
