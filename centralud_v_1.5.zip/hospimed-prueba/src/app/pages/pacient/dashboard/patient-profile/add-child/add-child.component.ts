import { Output } from '@angular/core';
import { Component, OnInit, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-add-child',
  templateUrl: './add-child.component.html',
  styleUrls: ['./add-child.component.scss']
})
export class AddChildComponent implements OnInit {

  @Output() saveChild = new EventEmitter<boolean>();

  showSaveChild: boolean = true;

  showRegistryChild: boolean = true;

  showEditProfile: boolean = false;

  reconocimientos: Array<number> = [1];

  ruc: boolean;

  constructor() { }

  ngOnInit(): void {
  }

  addReconocimiento () {
    this.reconocimientos.push(1);
  }

  removeReconocimiento () {
    this.reconocimientos.splice(0, 1);
  }

}
