import {  Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.scss']
})
export class VideoComponent implements OnInit {
  @Output() showChatEvent = new EventEmitter<boolean>();

  fullscreen: boolean = false;

  callStarted: boolean = false;

  videocam: boolean = true;

  mic: boolean = true;

  constructor() { }

  ngOnInit(): void {
  }

}
