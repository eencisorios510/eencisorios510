namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
     public class Aplicacion
    {
        public int Id { get; set; }
        public string Nombre { get; set; } = string.Empty;
        public string Codigo { get; set; } = string.Empty;
        public string ProductOwner { get; set; } = string.Empty;
        public string EmailProductOwner { get; set; } = string.Empty;
        public string ExpertosLideres { get; set; } = string.Empty;
        public string CorreoExpertosLideres { get; set; } = string.Empty;
        public string AnalistasSeguridad { get; set; } = string.Empty;
        public string CorreoAnalistasSeguridad { get; set; } = string.Empty;
        public string Squad { get; set; } = string.Empty;
        public string Tribu { get; set; } = string.Empty;
        public bool Estado { get; set; }
    }
       