import { Component, ViewChild } from '@angular/core';
import { BcpActionSheet } from '@bcp/ng-ui-components';

@Component({
  selector: 'app-some-component',
  templateUrl: './some.component.html',
})
export class SomeComponent {
  @ViewChild('actionSheet') actionSheet!: BcpActionSheet;

  open(): void {
    this.actionSheet.open();
  }

  close(): void {
    this.actionSheet.close();
  }
}