import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pop-up-rxh',
  templateUrl: './pop-up-rxh.component.html',
  styleUrls: ['./pop-up-rxh.component.scss']
})
export class PopUpRxhComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
