﻿using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;

namespace PFTWebAPI.Models
{
    public class Generacion_Usuario
    {
        public int Id { get; set; }
        public string? IdSolicitud { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string? NombreEmpresa { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string? Producto { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string? Ambiente { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string? Codigo { get; set; }
    }
}
