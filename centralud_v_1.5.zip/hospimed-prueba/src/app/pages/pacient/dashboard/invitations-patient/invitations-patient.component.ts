import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invitations-patient',
  templateUrl: './invitations-patient.component.html',
  styleUrls: ['./invitations-patient.component.scss']
})
export class InvitationsPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
