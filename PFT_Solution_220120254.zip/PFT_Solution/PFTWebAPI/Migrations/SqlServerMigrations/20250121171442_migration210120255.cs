﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PFTWebAPI.Migrations.SqlServerMigrations
{
    /// <inheritdoc />
    public partial class migration210120255 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Ruc",
                table: "EMPRESA",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Ruc",
                table: "EMPRESA");
        }
    }
}
