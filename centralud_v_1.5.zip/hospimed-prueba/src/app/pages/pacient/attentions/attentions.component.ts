import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-attentions',
  templateUrl: './attentions.component.html',
  styleUrls: ['./attentions.component.scss']
})
export class AttentionsPatientsComponent implements OnInit {
  
  panelOpenState = true;

  @ViewChild(MatAutocompleteTrigger) autocomplete: MatAutocompleteTrigger;

  stateCtrl = new FormControl();
  searchHistory: any[] = [];
  filteredSearchHistory: Observable<any[]>;

  searchInputState: string = 'blur'; // blur, focus

  doctors: any[] = [
    {
      id: 1,
      name: 'Dra. Eliana Espinoza',
      link: 'https://envato-shoebox-0.imgix.net/a2ec/f41e-0b02-4159-905b-f914c7e2cee4/200318-Ph2-0566.jpg?auto=compress%2Cformat&fit=max&mark=https%3A%2F%2Felements-assets.envato.com%2Fstatic%2Fwatermark2.png&markalign=center%2Cmiddle&markalpha=18&w=700&s=19eb93f59e5c84d8b57762f89b56df1f',
      section: 'Dermatología',
      status: 'online',
      display: 'none',
      time: '9:00 am',
      date: '25/08/2021',
      state: 'Confirmado',
      chat: false,
      payment: false
    },
    {
      id: 2,
      name: 'Dr. Aldo Mercado R.',
      link: 'https://static.vecteezy.com/system/resources/previews/000/859/306/non_2x/smiling-doctor-portrait-photo.jpg',
      section: 'Medicina Interna',
      status: 'missing',
      display: 'show',
      time: '7:00 pm',
      date: '29/08/2021',
      state: 'Ficha médica',
      chat: true,
      payment: false
    },
    {
      id: 3,
      name: 'Dr. José Huerta Pérez',
      link: 'https://img.freepik.com/free-photo/handsome-young-businessman-shirt-eyeglasses_85574-6228.jpg',
      section: 'Ginecología',
      status: 'offline',
      display: 'none',
      time: '6:15 pm',
      date: '16/09/2021',
      state: 'Pendiente de pago',
      chat: false,
      payment: true
    },
   
  ];

  doctorSecond: any[] = [
    {
      id: 4,
      name: 'Dra. Lucía Dextre',
      link: 'https://image.freepik.com/foto-gratis/retrato-medico-africano_93675-26696.jpg',
      section: 'Neurología',
      status: 'offline',
      display: 'none',
      time: '6:15 pm',
      date: '17/08/2021',
      state: 'Orden de exámenes',
      exam: true
    },
    {
      id: 5,
      name: 'Dr. Miguel Aguilar',
      link: 'https://st3.depositphotos.com/10654668/i/600/depositphotos_135128860-stock-photo-male-doctor-with-stethoscope.jpg',
      section: 'Cardiología',
      status: 'online',
      display: 'none',
      time: '7:00 pm',
      date: '10/08/2021',
      state: '',
      exam: false
    }
  ]

  doctorThird: any[] = [
    {
      id: 6,
      name: 'Dr. Daniel Cuesta',
      link: 'https://image.freepik.com/foto-gratis/retrato-medico-africano_93675-56166.jpg',
      section: 'Oftamología',
      status: 'online',
      display: 'show',
      time: '10:00 am',
      date: '12/08/2021',
      state: '',
      chat: true,
      dates: false
    },
    {
      id: 7,
      name: 'Dra. Eliana Espinoza',
      link: 'https://envato-shoebox-0.imgix.net/a2ec/f41e-0b02-4159-905b-f914c7e2cee4/200318-Ph2-0566.jpg?auto=compress%2Cformat&fit=max&mark=https%3A%2F%2Felements-assets.envato.com%2Fstatic%2Fwatermark2.png&markalign=center%2Cmiddle&markalpha=18&w=700&s=19eb93f59e5c84d8b57762f89b56df1f',
      section: 'Dermatología',
      status: 'online',
      display: 'none',
      time: '9:40 am',
      date: '14/09/2021',
      state: 'Chat disponible',
      chat: false,
      dates: false
    },
    {
      id: 8,
      name: 'CIMEDIC',
      link: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrD6R-0UT1UsiTln30Fd5EF7RnrGzAGVOADE80lyloLZDB4yzT52rgxJCEHjNv-IIocYw&usqp=CAU',
      section: 'Rayos X',
      status: 'offline',
      display: 'none',
      time: '6:41 pm',
      date: '16/09/2021',
      state: '',
      chat: false,
      dates: false
    },
    {
      id: 9,
      name: 'Dr. Manuel Pinto Chavarry',
      link: 'https://envato-shoebox-0.imgix.net/4ccc/95cc-ffa2-425c-8766-9d6eee4b7867/200318-Ph1-0588.jpg?auto=compress%2Cformat&fit=max&mark=https%3A%2F%2Felements-assets.envato.com%2Fstatic%2Fwatermark2.png&markalign=center%2Cmiddle&markalpha=18&w=700&s=b97177bdc1436d78400ea0812f33c2fd',
      section: 'Odontología',
      status: 'offline',
      display: 'none',
      time: '12:15 pm',
      date: '23/06/2021',
      state: 'Pendiente de información',
      chat: false,
      dates: true
    },
  ]

  filteredDoctors: any[] = [];
  filteredDoctorSecond: any[] = [];
  filteredDoctorThird: any[] = [];

  selectedDoctorId: number = 1;

  constructor() { 
    this.filteredDoctors = this.doctors;
    this.filteredDoctorSecond = this.doctorSecond;
    this.filteredDoctorThird = this.doctorThird;

    this.filteredSearchHistory = this.stateCtrl.valueChanges
      .pipe(
        startWith(''),
        map(search => search ? this._filterSearchHistory(search) : this.searchHistory.slice())
      );
  }

  private _filterSearchHistory(value: string): any[] {
    const filterValue = value.toLowerCase();

    return this.searchHistory.filter(search => search.toLowerCase().indexOf(filterValue) === 0);
  }

  searchInputFocus(): void {
    this.searchInputState = 'focus';
  }

  searchInputBlur(): void {
    this.searchInputState = 'blur';
  }

  getSearchHistory(): void {
    this.searchHistory = [
      'Dra. Eliana Espinoza',
      'Dr. Aldo Mercado Ramirez',
      'Dermatología',
    ];
  }

  ngOnInit(): void {
    this.getSearchHistory();
  }

  updateSelectedDoctorId(id): void {
    this.selectedDoctorId = id;
  }

  showChat: boolean;
  showExams: boolean;
  showPayment: boolean;
  showDates: boolean;

  showViewChat(chat): void {
    this.showChat = chat;
    this.showExams = false;
    this.showPayment = false;
    this.showDates = false;
  }

  showViewExam(exam): void {
    this.showExams = exam;
    this.showChat = false;
    this.showPayment = false;
    this.showDates = false;
  }

  showViewPayment(payment): void {
    this.showPayment = payment;
    this.showChat = false;
    this.showExams = false;
    this.showDates = false;
  }

  showViewDates(dates): void {
    this.showDates = dates;
    this.showChat = false;
    this.showExams = false;
    this.showPayment = false;
  }

  // showAvailablesOnly(event): void {
  //   if (event.checked) {
  //     this.filteredDoctors = this.doctors.filter(doctor => doctor.status === 'online');
  //   } else {
  //     this.filteredDoctors = this.doctors;
  //   }
  // }
}
