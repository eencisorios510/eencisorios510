// namespace PFTWebAPI.Entities;
// using System.ComponentModel.DataAnnotations;

// public class Unidad_Equipo
// {
//     public int Id { get; set; }
//     public string Area { get; set; }
//     public string Po { get; set; }
//     public string Seguridad { get; set; }       
//     public ICollection<Interesado> Interesados { get; set; }
// }
        