import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pacient-basic-plan',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.scss']
})
export class PacientBasicPlanComponent implements OnInit {

  // hideSelect: boolean;

  @Output() updatePlanEvent = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

}
