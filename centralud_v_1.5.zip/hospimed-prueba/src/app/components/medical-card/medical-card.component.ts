import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-medical-card',
  templateUrl: './medical-card.component.html',
  styleUrls: ['./medical-card.component.scss']
})
export class MedicalCardComponent implements OnInit {

  @Input() quote: {id: number};

  @Input() selected: boolean = false;
  constructor() { }

  ngOnInit(): void {
  }

}
