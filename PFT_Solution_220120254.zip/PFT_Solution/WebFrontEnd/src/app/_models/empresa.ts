export class Empresa {
    nombre: string;
    nombreCorto: string;
    telefono: string;
    pais: string;
    ruc: string;
    fechaRegistro: Date;
}