import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pacient-layout',
  templateUrl: './pacient-layout.component.html',
  styleUrls: ['./pacient-layout.component.scss']
})
export class PacientLayoutComponent implements OnInit {
  
  showAnnouncement: boolean = false;

  showFooter: boolean = false;

  menuItems = [
    { icon: '/assets/images/sidebar/home-icon.png', name: 'Inicio', route: '/pacients/my' },
    { icon: '/assets/images/sidebar/plus-icon.png', name: 'Reservar', route: '/pacients/my/medical-appointment-reservation' },
    { icon: '/assets/images/sidebar/phone-icon.png', name: 'Teleconsulta', route: '/pacients/my/teleconsulta' },
    { icon: '/assets/images/sidebar/category-icon.png', name: 'Atenciones', route: '/pacients/my/attentions' },
    { icon: '/assets/images/sidebar/pills-icon.png', name: 'Seguimiento', route: '/pacients/my/tracking' },
  ];

  constructor() {}

  ngOnInit(): void {
  }

}
