import { Component, Input, OnInit } from '@angular/core';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-bar-chart',
  templateUrl: './bar-chart.component.html',
  styleUrls: ['./bar-chart.component.scss']
})
export class BarChartComponent implements OnInit {

  @Input() data: ChartDataSets[];
  @Input() labels: Label[];
  @Input() chartHeight: string;
  @Input() type: ChartType = 'bar';
  @Input() stacked: boolean = false;

  public barChartOptions: ChartOptions = {
    responsive: true,
    // We use these empty structures as placeholders for dynamic theming.
    scales: { xAxes: [{ stacked: false }], yAxes: [{ stacked: false }] },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      }
    }
  };
  // public barChartType: ChartType = 'horizontalBar';
  public barChartLegend = true;

  public barChartColors: Color[] = [
    { backgroundColor: '#103DF6' },
    { backgroundColor: '#F8BE00' },
  ];

  constructor() { }

  ngOnInit(): void {
    this.barChartOptions.scales.xAxes[0].stacked = this.stacked;
    this.barChartOptions.scales.yAxes[0].stacked = this.stacked;

    console.log('this.barChartOptions: ', this.barChartOptions);
  }

}
