import { Component, OnInit } from '@angular/core';
import { ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  public lineChartLabels: Label[];
  public lineChartData: ChartDataSets[];

  public doughnutChartLabels: Label[];
  public doughnutChartData: any[];
  public doughnutColors: Color[];

  public barChartLabels: Label[];
  public barChartData: ChartDataSets[];

  public stackedBarChartLabels: Label[];
  public stackedBarChartData: ChartDataSets[];


  constructor() { }

  ngOnInit(): void {
    this.getLineChartContent();
    this.getDoughnutChartContent();
    this.getBarChartContent();
    this.getStackedBarChartContent();
  }

  getLineChartContent(): void {
    this.lineChartLabels = ['JUN', 'AGO', 'SET', 'OCT', 'NOV', 'DIC'];

    this.lineChartData = [
      { data: [65, 59, 80, 81, 56, 55,], label: 'P. nuevo' },
      { data: [28, 48, 40, 19, 86, 27], label: 'P. continuador' },
    ];

    this.doughnutColors = [
      { backgroundColor: [ '#103DF6', '#607EFA', '#AEBFFA', '#879EFB', '#D7DEFB' ] },
    ];
  }

  getDoughnutChartContent(): void {
    this.doughnutChartLabels = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];

    this.doughnutChartData = [
      [20, 30, 10, 10, 30],
    ];
  }

  getBarChartContent(): void {
    this.barChartLabels = ['2008', '2009', '2010', '2011', '2012'];

    this.barChartData = [
      { data: [80, 81, 56, 55, 40], label: 'Interconsulta' },
      { data: [40, 19, 86, 27, 90], label: 'Consulta' }
    ];
  }

  getStackedBarChartContent(): void {
    this.stackedBarChartLabels = ['2008', '2009', '2010', '2011', '2012'];

    this.stackedBarChartData = [
      { data: [80, 81, 56, 55, 40], label: 'Interconsulta' },
      { data: [40, 19, 86, 27, 90], label: 'Consulta' }
    ];
  }

}
