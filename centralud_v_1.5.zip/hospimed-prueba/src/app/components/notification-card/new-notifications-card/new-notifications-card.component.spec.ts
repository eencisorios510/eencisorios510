import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewNotificationsCardComponent } from './new-notifications-card.component';

describe('NewNotificationsCardComponent', () => {
  let component: NewNotificationsCardComponent;
  let fixture: ComponentFixture<NewNotificationsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewNotificationsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewNotificationsCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
