import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ginecologicas',
  templateUrl: './ginecologicas.component.html',
  styleUrls: ['./ginecologicas.component.scss']
})
export class GinecologicasComponent implements OnInit {

  hasBirths: string = '0';

  hasMenstruation: boolean = false;
  hasMenopause: boolean = false;

  edadMestruacion: number = 10;
  edadMenopausia: number = 40;
  nGestaciones: number = 0;
  nPartos: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

  counter(i: number) {
    return new Array(i);
  }
}
