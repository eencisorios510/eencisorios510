/* using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

class Program
{
    private static readonly HttpClient client = new HttpClient();

    static async Task Main(string[] args)
    {
        string codigoInicial = "23123401"; // Ejemplo de código inicial
        string nuevoCodigo = await GenerarCodigoUnico(codigoInicial);
        Console.WriteLine($"Código único generado: {nuevoCodigo}");
    }

    static async Task<string> GenerarCodigoUnico(string codigo)
    {
        while (await ConsultaCodigoApi(codigo))
        {
            codigo = GenerarCodigo(codigo);
        }
        return codigo;
    }

    static string GenerarCodigo(string codigo)
    {
        if (codigo.Length != 8)
        {
            throw new ArgumentException("El código debe tener exactamente 8 caracteres.");
        }

        // Extraer las partes del código
        string yy = codigo.Substring(0, 2);
        string xxxx = codigo.Substring(2, 4);
        string nn = codigo.Substring(6, 2);

        // Convertir el correlativo a entero y aumentarlo en 1
        int correlativo = int.Parse(nn);
        correlativo++;

        // Si el correlativo supera 99, reiniciarlo a 01
        if (correlativo > 99)
        {
            correlativo = 1;
        }

        // Formatear el nuevo correlativo con dos dígitos
        string nuevoNN = correlativo.ToString("D2");

        // Construir el nuevo código
        string nuevoCodigo = $"{yy}{xxxx}{nuevoNN}";

        return nuevoCodigo;
    }

    static async Task<bool> ConsultaCodigoApi(string codigo)
    {
        string uri = $"https://pssftsod02:10075/B2BAPIs/svc/tradingpartners/?searchFor={codigo}";

        client.DefaultRequestHeaders.Accept.Clear();
        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(System.Text.Encoding.ASCII.GetBytes("USER:PASSWORD")));

        HttpResponseMessage response = await client.GetAsync(uri);
        return response.IsSuccessStatusCode;
    }
}
 */