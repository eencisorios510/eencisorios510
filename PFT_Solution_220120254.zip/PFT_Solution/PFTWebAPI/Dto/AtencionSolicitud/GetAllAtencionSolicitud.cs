
namespace PFTWebAPI.Dto.AtencionSolicitud;

using System.ComponentModel.DataAnnotations;

public class GetAllAtencionSolicitud
{
        public int Id { get; set; }

        public int IdEstado { get; set; }
        public string Desc_Estado { get; set; }

        public int IdAfilicacion { get; set; }

        public DateTime fecha_ingresado { get; set; }

        public string usuario { get; set; }

        public string? Comentario { get; set; }
        
        public int? IdEstadoOrigen { get; set; }
}