import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-second-group-cards',
  templateUrl: './second-group-cards.component.html',
  styleUrls: ['./second-group-cards.component.scss']
})
export class SecondGroupCardsComponent implements OnInit {

  @Input() doctorSecond: {id: number, name: string, link: any, section:string, status: string, display: string, time: string, date: string, state: string, exam: boolean};

  @Input() selected: boolean = false;

  @Output() selectDoctorEvent = new EventEmitter<number>();
  @Output() clickShowExams = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
  }

}
