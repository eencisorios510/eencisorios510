import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import {DialogComponent} from '../../../../../dialog/dialog.component';


@Component({
  selector: 'app-yearly-plan',
  templateUrl: './yearly-plan.component.html',
  styleUrls: ['./yearly-plan.component.scss']
})
export class YearlyPlanComponent implements OnInit {

  lists: string[] =[ 
    'Uso internacional',
    'Conexión con la RENIEC',
    'Gestión de citas',
    'Atención de guardia virtual (urgencia)',
    'Pagos seguros por pasarela de pago',
    'Historia Clínica Electrónica',
    'Receta electrónica',
    'Órdenes de exámenes auxiliares electrónicas',
    'Firma digital',
    'Interconsultas virtuales',
    'Juntas médicas virtuales',
    'Reporte de honorarios'
  ]

  constructor(public dialog: MatDialog) { }

openDialog() {
    this.dialog.open(DialogComponent);
  }

  ngOnInit(): void {
  }

}
