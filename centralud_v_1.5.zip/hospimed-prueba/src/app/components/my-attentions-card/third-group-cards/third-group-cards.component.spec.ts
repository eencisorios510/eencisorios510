import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThirdGroupCardsComponent } from './third-group-cards.component';

describe('ThirdGroupCardsComponent', () => {
  let component: ThirdGroupCardsComponent;
  let fixture: ComponentFixture<ThirdGroupCardsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThirdGroupCardsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThirdGroupCardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
