import { Component, Input, OnInit, EventEmitter } from '@angular/core';

interface User {
  value: string;
  viewValue: string;
  img: string;
}

@Component({
  selector: 'app-yearly-plan-card',
  templateUrl: './yearly-plan-card.component.html',
  styleUrls: ['./yearly-plan-card.component.scss']
})
export class YearlyPlanCardComponent implements OnInit {

  @Input() hideSelect: boolean = false;

  selectedValue: string;

  users: User[] = [
    {value: '0', viewValue: 'Stefan Silva Irribarren', img: 'https://image.freepik.com/foto-gratis/retrato-adolescente_23-2148105583.jpg'},
    {value: '1', viewValue: 'Karina del Río', img: 'https://image.freepik.com/foto-gratis/retrato-adolescente-feliz-volver-universidad_23-2148586573.jpg'},
    {value: '2', viewValue: 'Ana Silva', img: 'https://image.freepik.com/foto-gratis/retrato-hermosa-alegre-sonriente-nina-adolescente-15-anos_116407-5515.jpg'},
    {value: '3', viewValue: 'Salvador del Río', img: 'https://media.istockphoto.com/photos/portrait-of-a-teenager-picture-id1158015118?k=6&m=1158015118&s=612x612&w=0&h=W3-ft1mzzUlmb4OOSDyYfskyZsQqpHvimwjFJYHgbEU='}
  ];

  @Input() cardTitle: string = null;

  constructor() { }

  ngOnInit(): void {
  }

}
