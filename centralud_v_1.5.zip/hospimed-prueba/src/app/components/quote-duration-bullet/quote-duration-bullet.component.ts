import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-duration-bullet',
  templateUrl: './quote-duration-bullet.component.html',
  styleUrls: ['./quote-duration-bullet.component.scss']
})
export class QuoteDurationBulletComponent implements OnInit {

  isEditing: boolean = false;

  duration: Number = 20;

  constructor() { }

  ngOnInit(): void {
  }

}
