namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;

public class Ruta_Transferencia
{
    [Key]
    public int Id { get; set; }
    public string Servidor { get; set; }
    public string Max_tamanio_archivo { get; set; }
    public string Formato_nombre { get; set; }
    public bool Is_binary { get; set; }
    public string Frecuencia_nombre { get; set; }
    public string Rango_horas_ini { get; set; }    
    public string Rango_horas_fin { get; set; }
    public bool Is_datos_dac { get; set; }
    public bool Is_encripter { get; set; }
    public bool Is_descomprimir { get; set; }
    public string Ambiente { get; set; }
    //public Solicitud Solicitud { get; set; }=default!;
    public int Solicitud_id { get; set; }  
}
        