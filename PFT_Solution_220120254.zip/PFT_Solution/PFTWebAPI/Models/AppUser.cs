namespace PFTWebAPI.Models;
using Microsoft.AspNetCore.Identity;

public class AppUser : IdentityUser
{
}

