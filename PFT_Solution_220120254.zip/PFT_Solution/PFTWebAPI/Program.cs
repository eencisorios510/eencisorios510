using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using PFTWebAPI.Models;
using PFTWebAPI.Authorization;
using PFTWebAPI.Helpers;
using PFTWebAPI.Data;
using PFTWebAPI.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// use sql server db in production and sqlite db in development
builder.Services.AddDbContext<DataContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
);



if (builder.Environment.IsProduction())
    builder.Services.AddDbContext<DataContext>();
else
    builder.Services.AddDbContext<DataContext, SqliteDataContext>();

builder.Services.AddCors();
builder.Services.AddControllers();

// Configure automapper with all automapper profiles from this assembly
builder.Services.AddAutoMapper(typeof(Program));
//builder.Services.AddAutoMapper(typeof(Program),typeof(AutoMapperProfile));

// configure strongly typed settings object
builder.Services.Configure<AppSettings>(builder.Configuration.GetSection("AppSettings"));

// configure DI for application services
builder.Services.AddScoped<IJwtUtils, JwtUtils>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<IGeneracionUsuarioService, GeneracionUsuarioService>();
builder.Services.AddScoped<ISolicitudService, SolicitudService>();
builder.Services.AddScoped<IAtencionSolicitudService, AtencionSolicitudService>();
builder.Services.AddScoped<IEstadoService, EstadoService>();
builder.Services.AddHttpClient();

var app = builder.Build();

// migrate any database changes on startup (includes initial db creation)
using (var scope = app.Services.CreateScope())
{
    var dataContext = scope.ServiceProvider.GetRequiredService<DataContext>();
    dataContext.Database.Migrate();
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure HTTP request pipeline

// global cors policy
app.UseCors(x => x
    .AllowAnyOrigin()
    .AllowAnyMethod()
    .AllowAnyHeader());

// global error handler
app.UseMiddleware<ErrorHandlerMiddleware>();

// custom jwt auth middleware
app.UseMiddleware<JwtMiddleware>();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
