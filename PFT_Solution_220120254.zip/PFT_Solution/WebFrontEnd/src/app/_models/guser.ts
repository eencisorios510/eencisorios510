export class Guser {
    id?: number;
    idAfiliacion: string;
    nombreEmpresa: string;
    producto: string;
    ambiente: string;
    codigo: string;
}