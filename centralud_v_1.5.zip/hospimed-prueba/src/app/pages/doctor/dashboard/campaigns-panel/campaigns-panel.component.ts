import { Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import { MatCalendar, MatCalendarCellCssClasses } from '@angular/material/datepicker';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-campaigns-panel',
  templateUrl: './campaigns-panel.component.html',
  styleUrls: ['./campaigns-panel.component.scss']
})
export class CampaignsPanelComponent implements OnInit {

  showNameEdit: boolean;
  nameCampaing: string = 'Semana de la Maternidad Saludable y Segura';

  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  medicCtrl = new FormControl();
  filteredMedics: Observable<string[]>;
  medics: string[] = ['Embarazo de primer trimestre', 'Embarazo de segundo trimestre'];
  allMedics: string[] = ['Embarazo de tercer trimestre','Embarazo de cuarto trimestre','Embarazo de quinto trimestre'];

  @ViewChild('medicInput') medicInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  @ViewChild('turnsCalendar') turnsCalendar: MatCalendar<Date>;

  selectedDate: Date;
  startAt = new Date();
  minDate = new Date();
  maxDate = new Date(new Date().setMonth(new Date().getMonth() + 1));
  year: any;
  DayAndDate: string;

  turnDate: any;

  calendarRefreshFlag: boolean = true;

  dates = [
    { day: 1, date: '29-03-2021', dateName: 'Lun 29', turns: [] },
    { day: 2, date: '30-03-2021', dateName: 'Mar 30', turns: [] },
    { day: 3, date: '01-04-2021', dateName: 'Mié 1', turns: [] },
    { day: 4, date: '02-04-2021', dateName: 'Jue 2', turns: [] },
    { day: 5, date: '03-04-2021', dateName: 'Vie 3', turns: [] },
    { day: 6, date: '04-04-2021', dateName: 'Sáb 4', turns: [] },
    { day: 0, date: '05-04-2021', dateName: 'Dom 5', turns: [] },
    { day: 1, date: '06-04-2021', dateName: 'Lunes 6', turns: [] },
    { day: 2, date: '07-04-2021', dateName: 'mar 7', turns: [] },
    { day: 3, date: '08-04-2021', dateName: 'Mié 8', turns: [] },
  ];

  isEmpty: boolean = true;

  constructor() {
    this.filteredMedics = this.medicCtrl.valueChanges.pipe(
      startWith(null),
      map((medic: string | null) => medic ? this._filter(medic) : this.allMedics.slice()));
  }

  ngOnInit(): void {
  }

  onSelect(event) {
    this.selectedDate = event;
    const dateString = event.toDateString();
    const dateValue = dateString.split(' ');

    this.year = dateValue[3];
    this.DayAndDate = dateValue[0] + ',' + ' ' + dateValue[1] + ' ' + dateValue[2];
  }

  myDateFilter = (d: Date): boolean => {
    const day = d.getDay();
    return day !== 0 && day !== 6 ;
  }

  removeTurn(turnData: {date: string, turnIndex: number}): void {
    const dateIndex = this.dates.findIndex(item => item.date === turnData.date);

    if (dateIndex > -1) {
      this.dates[dateIndex].turns.splice(turnData.turnIndex, 1);
      this.turnsCalendar.updateTodaysDate();
      this.calendarRefreshFlag = false;
      this.calendarRefreshFlag = true;
    }
  }

  getDaysWithTurn() {
    const daysWithTurn = [];

    this.dates.forEach(date => {
      if ( date.turns.length > 0 && !daysWithTurn.includes(date.day) ) {
        daysWithTurn.push(date.day);
      }
    });

    return daysWithTurn;
  }

  dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      const daysWithTurn = this.getDaysWithTurn();
      console.log('dateClass() daysWithTurn: ', daysWithTurn);

      if (daysWithTurn.length === 0) return;

      if (daysWithTurn.includes(date.getDay())) {
        return 'special-date';
      }
    };
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our medic
    if ((value || '').trim()) {
      this.medics.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.medicCtrl.setValue(null);
  }

  remove(medic: string): void {
    const index = this.medics.indexOf(medic);

    if (index >= 0) {
      this.medics.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.medics.push(event.option.viewValue);
    this.medicInput.nativeElement.value = '';
    this.medicCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allMedics.filter(medic => medic.toLowerCase().indexOf(filterValue) === 0);
  }
}
