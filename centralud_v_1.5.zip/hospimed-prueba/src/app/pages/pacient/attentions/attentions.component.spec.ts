import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AttentionsPatientsComponent } from './attentions.component';

describe('AttentionsPatientsComponent', () => {
  let component: AttentionsPatientsComponent;
  let fixture: ComponentFixture<AttentionsPatientsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AttentionsPatientsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AttentionsPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
