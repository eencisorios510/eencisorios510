import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteDurationBulletComponent } from './quote-duration-bullet.component';

describe('QuoteDurationBulletComponent', () => {
  let component: QuoteDurationBulletComponent;
  let fixture: ComponentFixture<QuoteDurationBulletComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuoteDurationBulletComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteDurationBulletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
