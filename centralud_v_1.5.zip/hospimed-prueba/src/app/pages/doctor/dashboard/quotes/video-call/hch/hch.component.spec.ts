import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HchComponent } from './hch.component';

describe('HchComponent', () => {
  let component: HchComponent;
  let fixture: ComponentFixture<HchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
