﻿import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '@app/_models';
import { environment } from '@environments/environment';
import { Guser } from '@app/_models';

@Injectable({ providedIn: 'root' })
export class GuserService {
    private userSubject: BehaviorSubject<User>;

    constructor(
        private router: Router,
        private http: HttpClient
    ) {
        this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));
    }

    public get userValue(): User {
        return this.userSubject.value;
    }

    gusuarioregister(guser: Guser) {
        console.log('guser')
        console.log(guser)
        return this.http.post(`${environment.apiUrl}/GeneracionUsuarios/register`, guser);
    }

    getGeneracionUsuarioAll() {
        return this.http.get<Guser[]>(`${environment.apiUrl}/GeneracionUsuarios/GetGeneracionUsuarioAll`);
    }

    getGeneracionUsuarioById(id: string): Observable<Guser> {
        return this.http.get<Guser>(`${environment.apiUrl}/GeneracionUsuarios/GetGeneracionUsuarioById/${id}`);
    }    

}