import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PopUpRxhComponent } from './pop-up-rxh.component';

describe('PopUpRxhComponent', () => {
  let component: PopUpRxhComponent;
  let fixture: ComponentFixture<PopUpRxhComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PopUpRxhComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PopUpRxhComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
