namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
    
    public class RolEstado
    {
        public int Id { get; set; }
        public int EstadoId { get; set; }
        public int RolId { get; set; }
        public EstadosSolicitud EstadosSolicitud { get; set; }=default!;  
        public Rol Rol { get; set; }=default!;          
    }