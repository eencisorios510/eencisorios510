﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PFTWebAPI.Migrations.SqlServerMigrations
{
    /// <inheritdoc />
    public partial class migration210120252 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "APLICACION",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Codigo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProductOwner = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EmailProductOwner = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpertosLideres = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CorreoExpertosLideres = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnalistasSeguridad = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CorreoAnalistasSeguridad = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Squad = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tribu = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estado = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_APLICACION", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AREA",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(250)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AREA", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EMPRESA",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    NombreCorto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Telefono = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pais = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EMPRESA", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ESTADOS_SOLICITUD",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    Orden = table.Column<int>(type: "int", nullable: true),
                    Estado = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ESTADOS_SOLICITUD", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GENERACION_USUARIO",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdSolicitud = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NombreEmpresa = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Producto = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Ambiente = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    Codigo = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GENERACION_USUARIO", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "H2H_DETALLE",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Contacto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Ruta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Ip_host = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Puerto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Solicitud_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_H2H_DETALLE", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "HISTORIAL_ATENCION",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IdEstado = table.Column<int>(type: "int", nullable: false),
                    IdAfilicacion = table.Column<int>(type: "int", nullable: false),
                    fecha_ingresado = table.Column<DateTime>(type: "datetime2", nullable: false),
                    usuario = table.Column<string>(type: "nvarchar(10)", nullable: false),
                    Comentario = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    IdEstadoOrigen = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HISTORIAL_ATENCION", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PRODUCTO",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    ContratoJson = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Estado = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PRODUCTO", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ROL",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Codigo = table.Column<string>(type: "nvarchar(3)", nullable: false),
                    Nombre = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    Activo = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ROL", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "RUTA_TRANSFERENCIA",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Servidor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Max_tamanio_archivo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Formato_nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Is_binary = table.Column<bool>(type: "bit", nullable: false),
                    Frecuencia_nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Rango_horas_ini = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Rango_horas_fin = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Is_datos_dac = table.Column<bool>(type: "bit", nullable: false),
                    Is_encripter = table.Column<bool>(type: "bit", nullable: false),
                    Is_descomprimir = table.Column<bool>(type: "bit", nullable: false),
                    Ambiente = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Solicitud_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RUTA_TRANSFERENCIA", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SOLICITUD_INTERESADO",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SolicitudId = table.Column<int>(type: "int", nullable: false),
                    AplicacionId = table.Column<int>(type: "int", nullable: true),
                    UnidadId = table.Column<int>(type: "int", nullable: true),
                    EsResponsable = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SOLICITUD_INTERESADO", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TIPO_TRANSFERENCIA",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TIPO_TRANSFERENCIA", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "USUARIO",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Username = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    IdRol = table.Column<string>(type: "nvarchar(250)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_USUARIO", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SOLICITUD",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SolicitanteNombre = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    SolicitanteEmail = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    FechaRegistro = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaActualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EstadoActualId = table.Column<int>(type: "int", nullable: false),
                    EmpresaSolicitud = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    IdAreaSolicitante = table.Column<int>(type: "int", nullable: true),
                    ProductoId = table.Column<int>(type: "int", nullable: false),
                    FlujoInformacion = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    EspecialistaComercial = table.Column<string>(type: "nvarchar(250)", nullable: true),
                    IdAplicacionSolicitante = table.Column<int>(type: "int", nullable: true),
                    ArchivoAdjunto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CodigoFt = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    DatosProducto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DatosOrigen = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DatosDestino = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DatosDac = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TipoEncriptacion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EsBidireccional = table.Column<bool>(type: "bit", nullable: false),
                    Tecnologia = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SOLICITUD", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SOLICITUD_AREA_IdAreaSolicitante",
                        column: x => x.IdAreaSolicitante,
                        principalTable: "AREA",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SOLICITUD_ESTADOS_SOLICITUD_EstadoActualId",
                        column: x => x.EstadoActualId,
                        principalTable: "ESTADOS_SOLICITUD",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SOLICITUD_PRODUCTO_ProductoId",
                        column: x => x.ProductoId,
                        principalTable: "PRODUCTO",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ROL_ESTADO",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    EstadoId = table.Column<int>(type: "int", nullable: false),
                    RolId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ROL_ESTADO", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ROL_ESTADO_ESTADOS_SOLICITUD_EstadoId",
                        column: x => x.EstadoId,
                        principalTable: "ESTADOS_SOLICITUD",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ROL_ESTADO_ROL_RolId",
                        column: x => x.RolId,
                        principalTable: "ROL",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ROL_ESTADO_EstadoId",
                table: "ROL_ESTADO",
                column: "EstadoId");

            migrationBuilder.CreateIndex(
                name: "IX_ROL_ESTADO_RolId",
                table: "ROL_ESTADO",
                column: "RolId");

            migrationBuilder.CreateIndex(
                name: "IX_SOLICITUD_EstadoActualId",
                table: "SOLICITUD",
                column: "EstadoActualId");

            migrationBuilder.CreateIndex(
                name: "IX_SOLICITUD_IdAreaSolicitante",
                table: "SOLICITUD",
                column: "IdAreaSolicitante");

            migrationBuilder.CreateIndex(
                name: "IX_SOLICITUD_ProductoId",
                table: "SOLICITUD",
                column: "ProductoId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "APLICACION");

            migrationBuilder.DropTable(
                name: "EMPRESA");

            migrationBuilder.DropTable(
                name: "GENERACION_USUARIO");

            migrationBuilder.DropTable(
                name: "H2H_DETALLE");

            migrationBuilder.DropTable(
                name: "HISTORIAL_ATENCION");

            migrationBuilder.DropTable(
                name: "ROL_ESTADO");

            migrationBuilder.DropTable(
                name: "RUTA_TRANSFERENCIA");

            migrationBuilder.DropTable(
                name: "SOLICITUD");

            migrationBuilder.DropTable(
                name: "SOLICITUD_INTERESADO");

            migrationBuilder.DropTable(
                name: "TIPO_TRANSFERENCIA");

            migrationBuilder.DropTable(
                name: "USUARIO");

            migrationBuilder.DropTable(
                name: "ROL");

            migrationBuilder.DropTable(
                name: "AREA");

            migrationBuilder.DropTable(
                name: "ESTADOS_SOLICITUD");

            migrationBuilder.DropTable(
                name: "PRODUCTO");
        }
    }
}
