import { Component, OnInit, ViewChild } from '@angular/core';
import { MatCalendar, MatCalendarCellCssClasses } from '@angular/material/datepicker';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import { CreateTurnDialogComponent } from './create-turn-dialog/create-turn-dialog.component';

@Component({
  selector: 'app-turn-schedule',
  templateUrl: './turn-schedule.component.html',
  styleUrls: ['./turn-schedule.component.scss']
})
export class TurnScheduleComponent implements OnInit {

  @ViewChild('turnsCalendar') turnsCalendar: MatCalendar<Date>;

  // selectedDate = new Date('2019/09/26');
  selectedDate: Date;
  startAt = new Date();
  minDate = new Date();
  maxDate = new Date(new Date().setMonth(new Date().getMonth() + 1));
  year: any;
  DayAndDate: string;

  turnDate: any;

  calendarRefreshFlag: boolean = true;

  dates = [
    { day: 1, date: '29-03-2021', dateName: 'Lun 29', turns: [] },
    { day: 2, date: '30-03-2021', dateName: 'Mar 30', turns: [] },
    { day: 3, date: '01-04-2021', dateName: 'Mié 1', turns: [] },
    { day: 4, date: '02-04-2021', dateName: 'Jue 2', turns: [] },
    { day: 5, date: '03-04-2021', dateName: 'Vie 3', turns: [] },
    { day: 6, date: '04-04-2021', dateName: 'Sáb 4', turns: [] },
    { day: 0, date: '05-04-2021', dateName: 'Dom 5', turns: [] },
    { day: 1, date: '06-04-2021', dateName: 'Lunes 6', turns: [] },
    { day: 2, date: '07-04-2021', dateName: 'mar 7', turns: [] },
    { day: 3, date: '08-04-2021', dateName: 'Mié 8', turns: [] },
  ];

  isEmpty: boolean = true;

  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {
  }

  onSelect(event) {
    this.selectedDate = event;
    const dateString = event.toDateString();
    const dateValue = dateString.split(' ');


    this.year = dateValue[3];
    this.DayAndDate = dateValue[0] + ',' + ' ' + dateValue[1] + ' ' + dateValue[2];

    this.openDialog();
  }

  myDateFilter = (d: Date): boolean => {
    const day = d.getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6 ;
  }

  removeTurn(turnData: {date: string, turnIndex: number}): void {
    const dateIndex = this.dates.findIndex(item => item.date === turnData.date);

    if (dateIndex > -1) {
      this.dates[dateIndex].turns.splice(turnData.turnIndex, 1);
      this.turnsCalendar.updateTodaysDate();
      this.calendarRefreshFlag = false;
      this.calendarRefreshFlag = true;
    }
  }

  getDaysWithTurn() {
    const daysWithTurn = [];

    this.dates.forEach(date => {
      if ( date.turns.length > 0 && !daysWithTurn.includes(date.day) ) {
        daysWithTurn.push(date.day);
      }
    });

    return daysWithTurn;
  }

  openDialog = () => {
    const dialogRef = this.dialog.open(CreateTurnDialogComponent, {
      width: '480px',
      data: {
        selectedDate: this.selectedDate
      }
    });

    dialogRef.afterClosed().subscribe(data => {
      if (data && Array.isArray(data)) {
        data.forEach(turn => {
          this.dates
            .filter(item => item.day === turn.day)
            .forEach(item => item.turns = item.turns.concat(turn.hours));
        });

        this.isEmpty = false;

        this.turnsCalendar.updateTodaysDate();
        this.calendarRefreshFlag = false;
        this.calendarRefreshFlag = true;
      }

      this.selectedDate = null;
    });
  }

  dateClass() {
    return (date: Date): MatCalendarCellCssClasses => {
      const daysWithTurn = this.getDaysWithTurn();
      console.log('dateClass() daysWithTurn: ', daysWithTurn);

      if (daysWithTurn.length === 0) return;

      if (daysWithTurn.includes(date.getDay())) {
        return 'special-date';
      }
    };
  }

}
