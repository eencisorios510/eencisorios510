import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-membership',
  templateUrl: './monthly-membership.component.html',
  styleUrls: ['./monthly-membership.component.scss']
})
export class MonthlyMembershipComponent implements OnInit {

  lists: string[] =[ 
    'Uso internacional',
    'Conexión con la RENIEC',
    'Gestión de citas',
    'Atención de guardia virtual (urgencia)',
    'Pagos seguros por pasarela de pago',
    'Historia Clínica Electrónica',
    'Receta electrónica',
    'Órdenes de exámenes auxiliares electrónicas',
    'Firma digital',
    'Interconsultas virtuales',
    'Juntas médicas virtuales',
    'Reporte de honorarios'
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
