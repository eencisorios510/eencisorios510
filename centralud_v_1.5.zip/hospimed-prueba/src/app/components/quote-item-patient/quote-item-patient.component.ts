import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quote-item-patient',
  templateUrl: './quote-item-patient.component.html',
  styleUrls: ['./quote-item-patient.component.scss']
})
export class QuoteItemPatientComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
