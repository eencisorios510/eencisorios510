export class AfiliacionDetailButon {
    boton: string;
    estado: boolean;
}