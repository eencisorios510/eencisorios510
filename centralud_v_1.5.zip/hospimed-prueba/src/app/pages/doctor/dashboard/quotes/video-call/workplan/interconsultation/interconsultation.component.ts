import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'app-interconsultation',
  templateUrl: './interconsultation.component.html',
  styleUrls: ['./interconsultation.component.scss']
})
export class InterconsultationComponent implements OnInit {

  Checked: boolean;

  visible = true;
  selectable = true;
  removable = true;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  medicCtrl = new FormControl();
  filteredMedics: Observable<string[]>;
  medics: string[] = ['Dra. Lara Miel'];
  allMedics: string[] = ['Dra. Lara Miel','Dra. Lara Vásquez','Dr. Laura de las casas', 'Dr. Lopez del río', 'Dr. Lorena Vilchez'];

  @ViewChild('medicInput') medicInput: ElementRef<HTMLInputElement>;
  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  interconsultas: Array<number> = [1];

  addInterconsulta() {
    this.interconsultas.push(1);
  }

  removeInterconsulta() {
    this.interconsultas.splice(0, 1);
  }

  constructor() { 
    this.filteredMedics = this.medicCtrl.valueChanges.pipe(
      startWith(null),
      map((medic: string | null) => medic ? this._filter(medic) : this.allMedics.slice()));
  }

  ngOnInit(): void {
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our medic
    if ((value || '').trim()) {
      this.medics.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.medicCtrl.setValue(null);
  }

  remove(medic: string): void {
    const index = this.medics.indexOf(medic);

    if (index >= 0) {
      this.medics.splice(index, 1);
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.medics.push(event.option.viewValue);
    this.medicInput.nativeElement.value = '';
    this.medicCtrl.setValue(null);
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.allMedics.filter(medic => medic.toLowerCase().indexOf(filterValue) === 0);
  }

}
