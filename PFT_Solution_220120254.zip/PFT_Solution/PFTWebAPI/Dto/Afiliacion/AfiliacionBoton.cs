namespace PFTWebAPI.Dto.Users;

    public class SolicitudBoton
    {
        public string Boton { get; set; }
        public bool Estado { get; set; }
    }