import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteCardCalendarTrackingComponent } from './quote-card-calendar-tracking.component';

describe('QuoteCardCalendarTrackingComponent', () => {
  let component: QuoteCardCalendarTrackingComponent;
  let fixture: ComponentFixture<QuoteCardCalendarTrackingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuoteCardCalendarTrackingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteCardCalendarTrackingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
