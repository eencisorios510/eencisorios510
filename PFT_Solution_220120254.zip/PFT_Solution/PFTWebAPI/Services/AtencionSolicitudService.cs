namespace PFTWebAPI.Services;
using Microsoft.EntityFrameworkCore;

using AutoMapper;
using BCrypt.Net;
using PFTWebAPI.Authorization;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Dto.AtencionSolicitud;

public interface IAtencionSolicitudService
{
    IEnumerable<GetAllAtencionSolicitud> GetAll();
    HistorialAtencion GetById(int id);
     IEnumerable<GetAllAtencionSolicitud> GetByIdSolicitud(int IdAfilicacion);
    void Register(RegisterRequestAtencion model);
}

public class AtencionSolicitudService : IAtencionSolicitudService
{
    private DataContext _context;
    private IJwtUtils _jwtUtils;
    private readonly IMapper _mapper;
    private IEstadoService _estadoService;

    public AtencionSolicitudService(
        DataContext context,
        IJwtUtils jwtUtils,
        IMapper mapper,
        IEstadoService estadoService)
    {
        _context = context;
        _jwtUtils = jwtUtils;
        _mapper = mapper;
        _estadoService = estadoService;
    }


    public IEnumerable<GetAllAtencionSolicitud> GetAll()
    {
       var query = from atencion in _context.HistorialAtenciones
                    //join rol in _context.Roles on usuario.IdRol equals rol.Id
                    select new GetAllAtencionSolicitud
                    {
                        Id = atencion.Id,
                        IdEstado = atencion.IdEstado,
                        IdAfilicacion = atencion.IdAfilicacion,
                        fecha_ingresado = atencion.fecha_ingresado,
                        usuario = atencion.usuario,
                        Comentario = atencion.Comentario,
                        IdEstadoOrigen = atencion.IdEstadoOrigen
                    };
        return query.ToList();
        //return _context.Users;
    }

    public HistorialAtencion GetById(int id)
    {
        return getAtencion(id);
    }
    public  IEnumerable<GetAllAtencionSolicitud> GetByIdSolicitud(int IdAfilicacion)
    {
       var query = from atencion in _context.HistorialAtenciones
                    join estado in _context.EstadosSolicitudes on atencion.IdEstado equals estado.Id
                    select new GetAllAtencionSolicitud
                    {
                        Id = atencion.Id,
                        IdEstado = atencion.IdEstado,
                        IdAfilicacion = atencion.IdAfilicacion,
                        fecha_ingresado = atencion.fecha_ingresado,
                        usuario = atencion.usuario,
                        Comentario = atencion.Comentario,
                        IdEstadoOrigen = atencion.IdEstadoOrigen,
                        Desc_Estado = estado.Nombre
                    };
    query = query.Where(p => p.IdAfilicacion.Equals(IdAfilicacion))
                 .OrderByDescending(p => p.fecha_ingresado);           
        return query.ToList();
    }
    public void Register(RegisterRequestAtencion model)
    {

        var estado = _estadoService.getEstadoById( model.IdEstadoSolicitud);
        var atencion = _mapper.Map<HistorialAtencion>(model);
        atencion.fecha_ingresado = DateTime.Now;
        switch (model.Boton)
        {
            case "anterior":
                var estadoAnt = _context.EstadosSolicitudes.FirstOrDefault(x=>x.Orden == estado.Orden-1);
                if (estadoAnt != null)
                {
                   atencion.IdEstado = estadoAnt.Id;   
                }
                else
                {
                    throw new KeyNotFoundException("Estado anterior no se encontro");
                }
              
                break;
            case "siguiente":
                var estadoSig = _context.EstadosSolicitudes.FirstOrDefault(x=>x.Orden == estado.Orden+1);
                if (estadoSig != null)
                {
                    atencion.IdEstado = estadoSig.Id;  
                }
                else
                {
                    throw new KeyNotFoundException("Estado siguiente no se encontro");
                }                
                break;
            case "cancelado":
                atencion.IdEstado = 1;
                break;
            case "rechazado":
                atencion.IdEstado = 9;
                break;
            case "pendiente":
                atencion.IdEstado = 7;
                break;
            default:
                 throw new KeyNotFoundException("Boton no se encontro");
            
        }

        _context.HistorialAtenciones.Add(atencion);


        // Actualizar el estado en la tabla Solicitud
        var afiliacion = _context.Solicitudes.FirstOrDefault(a => a.Id == model.IdAfilicacion);
        if (afiliacion != null)
        {
            afiliacion.EstadoActualId = atencion.IdEstado; // Asumiendo que IdEstado es el nuevo estado
            _context.Entry(afiliacion).State = EntityState.Modified; // Forzar el rastreo de cambios
        }
        else
        {
            throw new KeyNotFoundException("Solicitud no encontrada");
        }


        _context.SaveChanges();
    }

    private HistorialAtencion getAtencion(int id)
    {
        var atencion = _context.HistorialAtenciones.Find(id);
        if (atencion == null) throw new KeyNotFoundException("Atencion no se encontro");
        return atencion;
    }



}