import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { AuthGuard } from './_helpers';

const accountModule = () => import('./account/account.module').then(x => x.AccountModule);
const guserModule = () => import('./generacionusuario/guser.module').then(x => x.GuserModule);
const usersModule = () => import('./users/users.module').then(x => x.UsersModule);
const afiliacionesModule = () => import('./afiliacion/afiliaciones.module').then(x => x.AfiliacionesModule);

const routes: Routes = [
    { path: '', component: HomeComponent, canActivate: [AuthGuard] },
    { path: 'users', loadChildren: usersModule, canActivate: [AuthGuard]},
    { path: 'account', loadChildren: accountModule },
    { path: 'generacionusuario', loadChildren: guserModule, canActivate: [AuthGuard] },
    { path: 'afiliaciones', loadChildren: afiliacionesModule, canActivate: [AuthGuard] },
    
    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {})],
    exports: [RouterModule]
})
export class AppRoutingModule { }