using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto;
using System.Linq.Expressions;

namespace PFTWebAPI.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class EmpresaController 
        : GridController<Empresa, EmpresaGetDto, EmpresaCreateDto, EmpresaCreateDto>
    {
        public EmpresaController(DataContext context, IMapper mapper)
            : base(context, mapper)
        {
        }

        protected override Expression<Func<Empresa,bool>> SearchExpression(string query)
        {
            return e => e.Nombre.Contains(query);
        }

    }
}
