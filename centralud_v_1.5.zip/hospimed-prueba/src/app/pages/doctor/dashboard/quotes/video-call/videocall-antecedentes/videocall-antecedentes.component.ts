import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocomplete, MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatChipInputEvent } from '@angular/material/chips';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-videocall-antecedentes',
  templateUrl: './videocall-antecedentes.component.html',
  styleUrls: ['./videocall-antecedentes.component.scss']
})
export class VideocallAntecedentesComponent implements OnInit {

  @ViewChild('patologicoInput') patologicoInput: ElementRef<HTMLInputElement>;
  @ViewChild('quirurgicoInput') quirurgicoInput: ElementRef<HTMLInputElement>;
  @ViewChild('alergiaInput') alergiaInput: ElementRef<HTMLInputElement>;

  @ViewChild('auto') matAutocomplete: MatAutocomplete;

  patologicoCtrl = new FormControl();
  quirurgicoCtrl = new FormControl();
  alergiaCtrl = new FormControl();

  patologicos: string[] = [];
  filteredPatologicos: Observable<string[]>;

  quirurgicos: string[] = [];
  filteredQuirurgicos: Observable<string[]>;

  alergias: string[] = [];
  filteredAlergias: Observable<string[]>;

  separatorKeysCodes: number[] = [ENTER, COMMA];

  constructor() { }

  ngOnInit(): void {
  }

  add(event: MatChipInputEvent, kind: string): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      switch (kind) {
        case 'patologicos':
          this.patologicos.push(value.trim());
          this.patologicoCtrl.setValue(null);
          break;

        case 'quirurgicos':
          this.quirurgicos.push(value.trim());
          this.quirurgicoCtrl.setValue(null);
          break;

        case 'alergias':
          this.alergias.push(value.trim());
          this.alergiaCtrl.setValue(null);
          break;

        default:
          break;
      }
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    // this.patologicoCtrl.setValue(null);
  }

  remove(patologico: string, kind: string): void {
    let index;

    switch (kind) {
      case 'patologicos':
        index = this.patologicos.indexOf(patologico);
        if (index >= 0) this.patologicos.splice(index, 1);
        break;

        case 'quirurgicos':
        index = this.quirurgicos.indexOf(patologico);
        if (index >= 0) this.quirurgicos.splice(index, 1);
        break;

        case 'alergias':
        index = this.alergias.indexOf(patologico);
        if (index >= 0) this.alergias.splice(index, 1);
        break;

      default:
        break;
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.patologicos.push(event.option.viewValue);
    this.patologicoInput.nativeElement.value = '';
    this.patologicoCtrl.setValue(null);
  }

}
