﻿/* import { Component, OnInit, inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { BehaviorSubject, Observable } from 'rxjs';
import { AfiliacionService, AlertService, EmpresaService } from '@app/_services';
import { AfiliacionCombo, User, Empresa } from '@app/_models';
declare var $: any;

@Component({ templateUrl: 'add-edit-afiliacion.component.html' })
export class AddEditAfiliacionComponent implements OnInit {
    formNewEmpresa: UntypedFormGroup;
    isPopupOpen = false;
    private userSubject: BehaviorSubject<User>;
    formAfiliacion: UntypedFormGroup;
    productos: AfiliacionCombo[] = [];
    areas: AfiliacionCombo[] = [];
    aplicaciones: AfiliacionCombo[] = [];
    empresas: AfiliacionCombo[] = [];
    loading = false;
    submitted = false;

    nroSolicitud: string;
    solicitante: string;
    correoSolicitante: string;
    fechaIngresoSolicitud: string;
    estadoSolicitud: string;
    private readonly afiliacionService = inject(AfiliacionService);
    private readonly empresaService = inject(EmpresaService);

    constructor(
        private formBuilder: UntypedFormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private alertService: AlertService
    ) {
        this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));    
    }

    ngOnInit() {
        const fecha = new Date();
        this.formAfiliacion = this.formBuilder.group({
            solicitante: [this.userValue.name],
            correoSolicitante: [this.userValue.email],
            fechaIngresoSolicitud: [fecha.toLocaleString()],
            empresaAfiliacion: ['', Validators.required],
            contactoEmpresa: ['', Validators.required],
            idAreaSolicitante: ['', Validators.required],
            correoContactoEmpresa: ['', [Validators.required, Validators.email]],
            productoId: ['', Validators.required],
            flujoInformacion: ['', Validators.required],
            datosDac: ['', Validators.required],
            tipoEncriptacion: ['', Validators.required],
            especialistaComercial: ['', Validators.required],
            idAplicacionSolicitante: ['', Validators.required],
            responsable: ['', Validators.required],
            detalleSolicitud: ['', Validators.required],
            archivoAdjunto: ['']
        });

        this.formNewEmpresa = this.formBuilder.group({
            nombre: ['', Validators.required],
            nombreCorto: ['', Validators.required],
            telefono: ['', Validators.required],
            pais: ['', Validators.required],
            ruc:['', Validators.required]
        });  

        this.nroSolicitud = 'xxxx'; 
        this.solicitante = this.userValue.name; 
        this.correoSolicitante = this.userValue.email; 
        const now = new Date();
        this.fechaIngresoSolicitud = now.toLocaleString(); 
        this.estadoSolicitud = 'En espera'; 

                this.afiliacionService.GetAplicacionCombo()
                .pipe(first())
                .subscribe(x => {
                    this.aplicaciones = x; 
                });
                this.afiliacionService.GetProductoCombo()
                .pipe(first())
                .subscribe(x => {
                    this.productos = x; 
                });
                this.afiliacionService.GetAreaCombo()
                .pipe(first())
                .subscribe(x => {
                    this.areas = x; 
                });    
                this.afiliacionService.GetEmpresaCombo()
                .pipe(first())
                .subscribe(x => {
                    this.empresas = x; 
                }); 

    }


    openPopup() {
        this.isPopupOpen = true;
      }
    public get userValue(): User {
        return this.userSubject.value;
    }

    get f() { return this.formAfiliacion.controls; }

    onSubmit() {
        console.log("onSubmit()")
        this.submitted = true;

        this.alertService.clear();

        if (this.formAfiliacion.invalid) {
            return;
        }

        this.loading = true;
        this.createAfiliacion();
    }

    private createAfiliacion() {
        const formData = new FormData();
        formData.append('solicitante', this.userValue.name);
        formData.append('correoSolicitante', this.userValue.email);
        formData.append('empresaSolicitud', this.formAfiliacion.get('empresaAfiliacion').value);
        formData.append('idAreaSolicitante', this.formAfiliacion.get('idAreaSolicitante').value);
        formData.append('productoId', this.formAfiliacion.get('productoId').value);
        formData.append('flujoInformacion', this.formAfiliacion.get('flujoInformacion').value);
        formData.append('datosDac', this.formAfiliacion.get('datosDac').value);
        formData.append('tipoEncriptacion', this.formAfiliacion.get('tipoEncriptacion').value);
        formData.append('especialistaComercial', this.formAfiliacion.get('especialistaComercial').value);
        formData.append('idAplicacionSolicitante', this.formAfiliacion.get('idAplicacionSolicitante').value);
        formData.append('tecnologia', this.formAfiliacion.get('tecnologia').value);

        this.afiliacionService.registerAfiliacion(formData)
            .pipe(first())
            .subscribe({
                next: response  => {
                    const id = (response as any).result.id;
                    this.alertService.success('Afiliación agregada exitosamente,su codigo es '+id, { keepAfterRouteChange: true });
                    this.router.navigate(['/afiliaciones/addproducto', id]);
                    this.loading = false;
                },
                error: error => {
                    this.alertService.error(error);
                    this.loading = false;
                }
            });

    }

    onSubmitEmpresa() {
        $('#newEmpresaModal').modal('hide');
        console.log("onSubmitSig()");
        this.submitted = true;
        this.alertService.clear();
    
        if (this.formNewEmpresa.invalid) {
          console.log("return");
          return;
        }
    
        this.loading = true;
        this.createEmpresa();
      }

      private createEmpresa() {
            const empresa: Empresa = this.formNewEmpresa.value;
            this.empresaService.register(empresa).subscribe(
              (response: Empresa) => {
                console.log('Empresa registrada:', response);
              },
              (error) => {
                console.error('Error al registrar la empresa:', error);
              }
            );

      }


     

} */


      import { Component, OnInit, inject } from '@angular/core';
      import { Router, ActivatedRoute } from '@angular/router';
      import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
      import { first } from 'rxjs/operators';
      import { BehaviorSubject, Observable } from 'rxjs';
      import { AfiliacionService, AlertService, EmpresaService } from '@app/_services';
      import { AfiliacionCombo, User, Empresa } from '@app/_models';
      declare var $: any;
      
      @Component({ templateUrl: 'add-edit-afiliacion.component.html' })
      export class AddEditAfiliacionComponent implements OnInit {
          formNewEmpresa: UntypedFormGroup;
          isPopupOpen = false;
          private userSubject: BehaviorSubject<User>;
          formAfiliacion: UntypedFormGroup;
          productos: AfiliacionCombo[] = [];
          areas: AfiliacionCombo[] = [];
          aplicaciones: AfiliacionCombo[] = [];
          empresas: AfiliacionCombo[] = [];
          loading = false;
          submitted = false;
      
          nroSolicitud: string;
          solicitante: string;
          correoSolicitante: string;
          fechaIngresoSolicitud: string;
          estadoSolicitud: string;
          private readonly afiliacionService = inject(AfiliacionService);
          private readonly empresaService = inject(EmpresaService);
      
          constructor(
              private formBuilder: UntypedFormBuilder,
              private route: ActivatedRoute,
              private router: Router,
              private alertService: AlertService
          ) {
              this.userSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('user')));    
          }
      
          ngOnInit() {
              const fecha = new Date();
              this.formAfiliacion = this.formBuilder.group({
                  solicitante: [this.userValue.name],
                  correoSolicitante: [this.userValue.email],
                  fechaIngresoSolicitud: [fecha.toLocaleString()],
                  empresaAfiliacion: ['', Validators.required],
                  contactoEmpresa: ['', Validators.required],
                  idAreaSolicitante: ['', Validators.required],
                  correoContactoEmpresa: ['', [Validators.required, Validators.email]],
                  productoId: ['', Validators.required],
                  flujoInformacion: ['', Validators.required],
                  datosDac: ['', Validators.required],
                  tipoEncriptacion: ['', Validators.required],
                  especialistaComercial: ['', Validators.required],
                  idAplicacionSolicitante: ['', Validators.required],
                  responsable: ['', Validators.required],
                  detalleSolicitud: ['', Validators.required],
                  archivoAdjunto: ['']
              });
      
              this.formNewEmpresa = this.formBuilder.group({
                  nombre: ['', Validators.required],
                  nombreCorto: ['', Validators.required],
                  telefono: ['', Validators.required],
                  pais: ['', Validators.required],
                  ruc:['', Validators.required]
              });  
      
              this.nroSolicitud = 'xxxx'; 
              this.solicitante = this.userValue.name; 
              this.correoSolicitante = this.userValue.email; 
              const now = new Date();
              this.fechaIngresoSolicitud = now.toLocaleString(); 
              this.estadoSolicitud = 'En espera'; 
      
              this.loadCombos();
          }
      
          loadCombos() {
              this.afiliacionService.GetAplicacionCombo()
                  .pipe(first())
                  .subscribe(x => {
                      this.aplicaciones = x; 
                  });
              this.afiliacionService.GetProductoCombo()
                  .pipe(first())
                  .subscribe(x => {
                      this.productos = x; 
                  });
              this.afiliacionService.GetAreaCombo()
                  .pipe(first())
                  .subscribe(x => {
                      this.areas = x; 
                  });    
              this.afiliacionService.GetEmpresaCombo()
                  .pipe(first())
                  .subscribe(x => {
                      this.empresas = x; 
                  }); 
          }
      
          openPopup() {
              this.isPopupOpen = true;
          }
      
          public get userValue(): User {
              return this.userSubject.value;
          }
      
          get f() { return this.formAfiliacion.controls; }
      
          onSubmit() {
              console.log("onSubmit()")
              this.submitted = true;
      
              this.alertService.clear();
      
              if (this.formAfiliacion.invalid) {
                  return;
              }
      
              this.loading = true;
              this.createAfiliacion();
          }
      
          private createAfiliacion() {
              const formData = new FormData();
              formData.append('solicitante', this.userValue.name);
              formData.append('correoSolicitante', this.userValue.email);
              formData.append('empresaSolicitud', this.formAfiliacion.get('empresaAfiliacion').value);
              formData.append('idAreaSolicitante', this.formAfiliacion.get('idAreaSolicitante').value);
              formData.append('productoId', this.formAfiliacion.get('productoId').value);
              formData.append('flujoInformacion', this.formAfiliacion.get('flujoInformacion').value);
              formData.append('datosDac', this.formAfiliacion.get('datosDac').value);
              formData.append('tipoEncriptacion', this.formAfiliacion.get('tipoEncriptacion').value);
              formData.append('especialistaComercial', this.formAfiliacion.get('especialistaComercial').value);
              formData.append('idAplicacionSolicitante', this.formAfiliacion.get('idAplicacionSolicitante').value);
              formData.append('tecnologia', this.formAfiliacion.get('tecnologia').value);
      
              this.afiliacionService.registerAfiliacion(formData)
                  .pipe(first())
                  .subscribe({
                      next: response  => {
                          const id = (response as any).result.id;
                          this.alertService.success('Afiliación agregada exitosamente, su código es ' + id, { keepAfterRouteChange: true });
                          this.router.navigate(['/afiliaciones/addproducto', id]);
                          this.loading = false;
                      },
                      error: error => {
                          this.alertService.error(error);
                          this.loading = false;
                      }
                  });
          }
      
          onSubmitEmpresa() {
              $('#newEmpresaModal').modal('hide');
              console.log("onSubmitEmpresa()");
              this.submitted = true;
              this.alertService.clear();
          
              if (this.formNewEmpresa.invalid) {
                console.log("return");
                return;
              }
          
              this.createEmpresa();
          }
      
          private createEmpresa() {
              const empresa: Empresa = this.formNewEmpresa.value;
              this.empresaService.register(empresa).subscribe(
                  (response: Empresa) => {
                      console.log('Empresa registrada:', response);
                      this.loadCombos(); // Actualizar la lista de empresas
                      this.formNewEmpresa.reset(); // Resetear el formulario
                      this.submitted = false; // Resetear el estado de submitted
                  },
                  (error) => {
                      console.error('Error al registrar la empresa:', error);
                  }
              );
          }
      }      