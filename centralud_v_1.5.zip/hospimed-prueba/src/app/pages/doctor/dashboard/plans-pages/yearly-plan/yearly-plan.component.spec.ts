import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { YearlyPlanComponent } from './yearly-plan.component';

describe('YearlyPlanComponent', () => {
  let component: YearlyPlanComponent;
  let fixture: ComponentFixture<YearlyPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ YearlyPlanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(YearlyPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
