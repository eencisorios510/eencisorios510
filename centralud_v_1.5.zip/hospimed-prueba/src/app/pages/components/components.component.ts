import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-components',
  templateUrl: './components.component.html',
  styleUrls: ['./components.component.scss']
})
export class ComponentsComponent implements OnInit {

  currentStep: number =  2;

  steps: Array<{ value: number, label: string }> = [
    { value: 1, label: 'Contacto' },
    { value: 2, label: 'Formación' },
    { value: 3, label: 'Facturación' }
  ];

  list: Array<String> = [
    'Incremento de demanda de pacientes',
    'Permisos para un asistente administrativo',
    'Carga masiva para invitaciones a pacientes',
    'Clasificación de pacientes: Crónico, Oncologico y Quirúrgico',
    'Seguimiento inteligente de pacientes',
    'Programacion inteligente de campañas ',
    'Junta Médica virtual',
    'Estadísticas diarias de atenciones'
  ];

  constructor() { }

  ngOnInit(): void {
  }

}
