﻿namespace PFTWebAPI.Services;

using AutoMapper;
using BCrypt.Net;
using PFTWebAPI.Authorization;
using PFTWebAPI.Models;
using PFTWebAPI.Data;
using PFTWebAPI.Dto.Users;
using PFTWebAPI.Helpers;

public interface IUserService
{
    IEnumerable<GetAllUsers> GetAll();
    UserEntity GetById(int id);
    void Register(RegisterRequest model);
    void Update(int id, UpdateRequest model);
    void Delete(int id);
    string GetRolByUsername(string username);
    UserEntity GetUserByUsername(string username);
}

public class UserService : IUserService
{
    private DataContext _context;
    private IJwtUtils _jwtUtils;
    private readonly IMapper _mapper;

    public UserService(
        DataContext context,
        IJwtUtils jwtUtils,
        IMapper mapper)
    {
        _context = context;
        _jwtUtils = jwtUtils;
        _mapper = mapper;
    }


    public IEnumerable<GetAllUsers> GetAll()
    {
       var query = from usuario in _context.Users
                    join rol in _context.Roles on usuario.IdRol equals rol.Id
                    select new GetAllUsers
                    {
                        Id = usuario.Id,
                        Username = usuario.Username,
                        IdRol = usuario.IdRol,
                        Desc_Rol = rol.Nombre
                    };
        return query.ToList();
        //return _context.Users;
    }

    public UserEntity GetById(int id)
    {
        return getUser(id);
    }

    public void Register(RegisterRequest model)
    {
        // validate
        if (_context.Users.Any(x => x.Username == model.Username))
            throw new AppException("usuario '" + model.Username + "' ya se registro");

        // map model to new user object
        var user = _mapper.Map<UserEntity>(model);

        // save user
        _context.Users.Add(user);
        _context.SaveChanges();
    }

    public void Update(int id, UpdateRequest model)
    {
        var user = getUser(id);

        // copy model to user and save
        _mapper.Map(model, user);
        _context.Users.Update(user);
        _context.SaveChanges();
    }

    public void Delete(int id)
    {
        var user = getUser(id);
        _context.Users.Remove(user);
        _context.SaveChanges();
    }

    // helper methods

    private UserEntity getUser(int id)
    {
        var user = _context.Users.Find(id);
        if (user == null) throw new KeyNotFoundException("Usurio no se encontro");
        return user;
    }

    public string GetRolByUsername(string username)
    {
        var user = _context.Users.SingleOrDefault(u => u.Username == username);
        if (user != null)
        {
            var role = _context.Roles.SingleOrDefault(r => r.Id == user.IdRol);
            if (role != null)
            {
                return role.Nombre;
            }
        }
        return "Usuario";
    }

    public UserEntity GetUserByUsername(string username)
    {
        return _context.Users.SingleOrDefault(u => u.Username == username);
    }

}