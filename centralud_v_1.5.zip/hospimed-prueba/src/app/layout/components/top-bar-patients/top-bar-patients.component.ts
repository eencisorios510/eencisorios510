import { Location } from '@angular/common';
import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-top-bar-patients',
  templateUrl: './top-bar-patients.component.html',
  styleUrls: ['./top-bar-patients.component.scss']
})
export class TopBarPatientsComponent implements OnInit {

  @Output() updateShowFooterEvent = new EventEmitter<boolean>();

  pageTitle: string = '';
  showBackBtn: boolean = false;


  constructor(
    public router: Router,
    public location: Location) {
      router.events.subscribe((val: any) => {
        if (val instanceof NavigationEnd) {
          this.refreshPageTitle(val.url);
        }
      });
     }
  
     refreshPageTitle(currentRoute): void {
      const url = currentRoute.split('/').splice(-1);
  
      if (!url) {
        this.pageTitle = '';
        this.showBackBtn = false;
        return;
      }

      this.updateShowFooterEvent.emit(url[0] === '/pacients/my');
  
      const routes = [
        { showBackBtn: true, url: 'attentions', pageTitle: 'Mis atenciones' },
        { showBackBtn: true, url: 'membership', pageTitle: 'Membresía' },
        { showBackBtn: true, url: 'basic', pageTitle: 'Membresía' },
        { showBackBtn: true, url: 'monthly', pageTitle: 'Membresía' },
        { showBackBtn: true, url: 'yearly', pageTitle: 'Membresía' },
        { showBackBtn: true, url: 'turn-schedule', pageTitle: 'Mis turnos' },
        { showBackBtn: true, url: 'quotes', pageTitle: 'Lista de citas' },
        { showBackBtn: true, url: 'medical-appointment-reservation', pageTitle: 'Reservar cita' },
        { showBackBtn: true, url: 'pick-turn', pageTitle: 'Reservar cita' },
        { showBackBtn: true, url: 'checkout', pageTitle: 'Reservar cita' },
        { showBackBtn: true, url: 'medical-form', pageTitle: 'Ficha médica' },
        { showBackBtn: true, url: 'teleconsulta', pageTitle: 'Teleconsulta' },
        { showBackBtn: true, url: 'invitations', pageTitle: 'Invitaciones' },
        { showBackBtn: true, url: 'tracking', pageTitle: 'Seguimiento' },
        { showBackBtn: true, url: 'patient-profile', pageTitle: 'Mi Perfil' },
        { showBackBtn: true, url: 'add-child', pageTitle: 'Mi Perfil' },
        { showBackBtn: true, url: 'help-center', pageTitle: 'Ayuda' },
      ];
  
      const currentRouteData = routes.find(item => item.url === url[0]);
  
      if (currentRouteData) {
        this.pageTitle = currentRouteData.pageTitle;
        this.showBackBtn = currentRouteData.showBackBtn;
      } else {
        this.pageTitle = '';
        this.showBackBtn = false;
      }
    }

  ngOnInit(): void {
  }

}
