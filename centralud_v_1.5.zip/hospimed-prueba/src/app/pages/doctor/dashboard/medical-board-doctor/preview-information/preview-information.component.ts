import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-preview-information',
  templateUrl: './preview-information.component.html',
  styleUrls: ['./preview-information.component.scss']
})
export class PreviewInformationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
