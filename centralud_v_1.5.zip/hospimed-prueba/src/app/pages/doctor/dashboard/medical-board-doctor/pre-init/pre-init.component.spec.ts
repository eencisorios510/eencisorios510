import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreInitComponent } from './pre-init.component';

describe('PreInitComponent', () => {
  let component: PreInitComponent;
  let fixture: ComponentFixture<PreInitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreInitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreInitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
