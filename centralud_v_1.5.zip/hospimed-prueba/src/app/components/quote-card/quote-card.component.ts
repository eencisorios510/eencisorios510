import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-quote-card',
  templateUrl: './quote-card.component.html',
  styleUrls: ['./quote-card.component.scss']
})
export class QuoteCardComponent implements OnInit {

  @Output() updateExpandedEvent = new EventEmitter<number>();

  @Input() quote: {id: number};

  @Input() expand: boolean = false;
  // expand: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  toggleExpand () {
    console.log('toggleExpand');
    this.updateExpandedEvent.emit(!this.expand ? this.quote.id : null);
    // this.expand = !this.expand;
  }

}
