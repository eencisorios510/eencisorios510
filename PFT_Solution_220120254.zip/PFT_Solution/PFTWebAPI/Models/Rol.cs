namespace PFTWebAPI.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
    public class Rol
    {
        public int Id { get; set; }
        [Column(TypeName = "nvarchar(3)")]
        public string Codigo { get; set; }
        [Column(TypeName = "nvarchar(250)")]
        public string Nombre { get; set; }
        public bool Activo { get; set; }
        public ICollection<RolEstado> RolEstados { get; set; }
    }