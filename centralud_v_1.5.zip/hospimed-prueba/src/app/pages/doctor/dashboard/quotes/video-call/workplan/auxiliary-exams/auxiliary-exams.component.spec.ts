import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuxiliaryExamsComponent } from './auxiliary-exams.component';

describe('AuxiliaryExamsComponent', () => {
  let component: AuxiliaryExamsComponent;
  let fixture: ComponentFixture<AuxiliaryExamsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuxiliaryExamsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuxiliaryExamsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
