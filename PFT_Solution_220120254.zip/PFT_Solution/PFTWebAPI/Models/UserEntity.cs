﻿namespace PFTWebAPI.Models;

using System.Text.Json.Serialization;
using System.ComponentModel.DataAnnotations.Schema;
public class UserEntity
{
    public int Id { get; set; }
    [Column(TypeName = "nvarchar(250)")]
    public string Username { get; set; }
    [Column(TypeName = "nvarchar(250)")]
    public int IdRol { get; set; }
}

