namespace PFTWebAPI.Dto;

    public class ProductoCreateDto
    {
        public string Nombre { get; set; } = string.Empty;
        public string ContratoJson { get; set; } = string.Empty;
    }