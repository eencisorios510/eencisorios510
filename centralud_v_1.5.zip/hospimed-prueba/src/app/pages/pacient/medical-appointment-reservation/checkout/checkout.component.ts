import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {

  pacient: number = 1;

  paymentDocType: string;

  externalUser: boolean = false;
  giftReservation: boolean = false;

  extraServices =  [
    { id: 1, name: 'Certificado médico', price: 15.00, checked: false },
    { id: 2, name: 'Informe médico', price: 35.00, checked: false },
    { id: 3, name: 'Copia de HCE', price: 25.00, checked: false },
  ];

  basePrice = 105.00;

  constructor() { }

  get totalPrice() {
    let totalPrice = this.basePrice;

    this.extraServices.forEach(extra => {
      if (extra.checked) totalPrice += extra.price;
    })

    return totalPrice.toFixed(2);
  }

  externalUserChanged(): void {
    if (this.externalUser) {
      this.giftReservation = false;
    }
  }

  giftReservationChanged(): void {
    if (this.giftReservation) {
      this.externalUser = false;
    }
  }

  ngOnInit(): void {
  }

}
