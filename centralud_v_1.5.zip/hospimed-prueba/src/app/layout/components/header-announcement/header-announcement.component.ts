import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-header-announcement',
  templateUrl: './header-announcement.component.html',
  styleUrls: ['./header-announcement.component.scss']
})
export class HeaderAnnouncementComponent implements OnInit {

  @Output() hideAnnouncementEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
  }

  closeAnnouncement(): void {
    this.hideAnnouncementEvent.emit();
  }

}
