import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardPatientsCarouselComponent } from './dashboard-patients-carousel.component';

describe('DashboardPatientsCarouselComponent', () => {
  let component: DashboardPatientsCarouselComponent;
  let fixture: ComponentFixture<DashboardPatientsCarouselComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DashboardPatientsCarouselComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardPatientsCarouselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
