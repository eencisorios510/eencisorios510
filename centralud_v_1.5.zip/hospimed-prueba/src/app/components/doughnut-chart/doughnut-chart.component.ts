import { Component, Input, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';
import { Color, Label, MultiDataSet } from 'ng2-charts';

@Component({
  selector: 'app-doughnut-chart',
  templateUrl: './doughnut-chart.component.html',
  styleUrls: ['./doughnut-chart.component.scss']
})
export class DoughnutChartComponent implements OnInit {

  @Input() chartHeight: string;
  @Input() labels: Label[];
  @Input() data: MultiDataSet;
  @Input() colors: Color[] = [
    { backgroundColor: [ '#103DF6', '#F8BE00' ] },
    { backgroundColor: [ '#103DF6', '#F8BE00' ] },
    { backgroundColor: [ '#103DF6', '#F8BE00' ] },
  ];

  public doughnutChartType: ChartType = 'doughnut';


  constructor() { }

  ngOnInit(): void {
  }

}
