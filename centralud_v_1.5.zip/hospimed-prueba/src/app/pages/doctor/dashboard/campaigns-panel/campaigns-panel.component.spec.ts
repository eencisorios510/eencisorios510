import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignsPanelComponent } from './campaigns-panel.component';

describe('CampaignsPanelComponent', () => {
  let component: CampaignsPanelComponent;
  let fixture: ComponentFixture<CampaignsPanelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CampaignsPanelComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CampaignsPanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
