import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LayoutComponent } from './layout/layout.component';
import { DashboardLayoutComponent } from './layout/dashboard-layout/dashboard-layout.component';
import { PacientLayoutComponent } from './layout/pacient-layout/pacient-layout.component';
import { ComponentsComponent } from './pages/components/components.component';

import { LoginComponent } from './pages/doctor/login/login.component';
import { RegisterComponent } from './pages/doctor/register/register.component';

import { PasswordRecoveryComponent } from './pages/doctor/password-recovery/password-recovery.component';
import { PlansComponent } from './pages/doctor/dashboard/plans-pages/plans/plans.component';
import { YearlyPlanComponent } from './pages/doctor/dashboard/plans-pages/yearly-plan/yearly-plan.component';
import { YearlyMembershipComponent } from './pages/doctor/dashboard/plans-pages/yearly-membership/yearly-membership.component';
import { MonthlyMembershipComponent } from './pages/doctor/dashboard/plans-pages/monthly-membership/monthly-membership.component';
import { InvitationsComponent } from './pages/doctor/dashboard/invitations/invitations.component';
import { HonorariumComponent } from './pages/doctor/dashboard/honorarium/honorarium.component';
import { DoctorDashboardComponent } from './pages/doctor/dashboard/dashboard.component';
import { ValidateRegistrationDataComponent } from './pages/doctor/validate-registration-data/validate-registration-data.component';
import { ProfileComponent } from './pages/doctor/dashboard/profile/profile.component';
import { TurnScheduleComponent } from './pages/doctor/dashboard/turn-schedule/turn-schedule.component';
import { QuotesComponent } from './pages/doctor/dashboard/quotes/quotes.component';
import { VideoCallComponent } from './pages/doctor/dashboard/quotes/video-call/video-call.component';

import { PacientDashboardComponent } from './pages/pacient/dashboard/dashboard.component';
import { MembershipComponent } from './pages/pacient/membership/membership.component';
import { PacientBasicPlanComponent } from './pages/pacient/membership/basic/basic.component';
import { PacientMonthlyPlanComponent } from './pages/pacient/membership/monthly/monthly.component';
import { PacientYearlyPlanComponent } from './pages/pacient/membership/yearly/yearly.component';
import { MedicalAppointmentReservationComponent } from './pages/pacient/medical-appointment-reservation/medical-appointment-reservation.component';
import { PickTurnComponent } from './pages/pacient/medical-appointment-reservation/pick-turn/pick-turn.component';
import { CheckoutComponent } from './pages/pacient/medical-appointment-reservation/checkout/checkout.component';
import { DoneComponent } from './pages/pacient/medical-appointment-reservation/done/done.component';
import { MedicalFormComponent } from './pages/pacient/medical-form/medical-form.component';
import { InvitationsPatientComponent } from './pages/pacient/dashboard/invitations-patient/invitations-patient.component';
import { TrackingComponent } from './pages/pacient/dashboard/tracking/tracking.component';
import { pathToFileURL } from 'url';
import { VideoComponent } from './pages/pacient/dashboard/quotes/video-calls/video/video.component';
import { HomeComponent } from './pages/pacient/dashboard/home/home.component';
import { AttentionsPatientsComponent } from './pages/pacient/attentions/attentions.component';
import { ReportsComponent } from './pages/doctor/dashboard/reports/reports.component';
import { MedicalBoardDoctorComponent } from './pages/doctor/dashboard/medical-board-doctor/medical-board-doctor.component';
import { ProfileRecordComponent } from './pages/doctor/dashboard/profile-record/profile-record.component';
import { PatientMonitoringComponent } from './pages/doctor/dashboard/patient-monitoring/patient-monitoring.component';
import { AttentionsComponent } from './pages/pacient/dashboard/quotes/video-calls/attentions/attentions.component';


import { HCEReportComponent } from './pages/doctor/dashboard/hce-report/hce-report.component';
import { HelpCenterComponent } from './pages/doctor/dashboard/help-center/help-center.component';
import { PatientProfileComponent } from './pages/pacient/dashboard/patient-profile/patient-profile.component';
import { AddChildComponent } from './pages/pacient/dashboard/patient-profile/add-child/add-child.component';
import { CampaignsPanelComponent } from './pages/doctor/dashboard/campaigns-panel/campaigns-panel.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { ClinicHistoryComponent } from './pages/doctor/dashboard/quotes/video-call/clinic-history/clinic-history.component';

const routes: Routes = [
  // {
  //   path: '*',
  //   component: NotFoundComponent
  // },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full'
      },
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'register',
        component: RegisterComponent
      },
      {
        path: 'validate-registration-data',
        component: ValidateRegistrationDataComponent
      },
      {
        path: 'password-recovery',
        component: PasswordRecoveryComponent
      }
    ]
  },
  {
    path: 'dashboard',
    component: DashboardLayoutComponent,
    children: [
      {
        path: 'clinic-history',
        component: ClinicHistoryComponent
      },
      {
        path: 'components',
        component: ComponentsComponent
      },
      {
        path: '',
        component: DoctorDashboardComponent
      },
      {
        path: 'profile',
        component: ProfileComponent
      },
      {
        path: 'turn-schedule',
        component: TurnScheduleComponent
      },
      {
        path: 'quotes',
        component: QuotesComponent
      },
      {
        path: 'quotes/:id/video-call',
        component: VideoCallComponent
      },
      {
        path: 'plans',
        component: PlansComponent
      },
      {
        path: 'yearly-plan',
        component: YearlyPlanComponent
      },
      {
        path: 'yearly-membership',
        component: YearlyMembershipComponent
      },
      {
        path: 'monthly-membership',
        component: MonthlyMembershipComponent
      },
      {
        path: 'invitations',
        component: InvitationsComponent
      },
      {
        path: 'honorarium',
        component: HonorariumComponent
      },
      {
        path: 'reports',
        component: ReportsComponent
      },
      {
        path: 'medical-board',
        component: MedicalBoardDoctorComponent
      },
      {
        path: 'profile-record',
        component: ProfileRecordComponent
      },
      {
        path: 'patient-monitoring',
        component: PatientMonitoringComponent
      },
      { path: 'campaigns',
        component: CampaignsPanelComponent  
      },
      { path: 'help-center',
        component: HelpCenterComponent  
      },
      { path: 'hce-report',
      component: HCEReportComponent  
    },
    ]
  },
  {
    path: 'pacients',
    component: PacientLayoutComponent,
    children: [
      {
        path: 'my',
        component: PacientDashboardComponent
      },
      {
        path: 'my/membership',
        component: MembershipComponent,
        children: [
          {
            path: '',
            component: PacientBasicPlanComponent,
          },
          {
            path: 'basic',
            component: PacientBasicPlanComponent,
          },
          {
            path: 'monthly',
            component: PacientMonthlyPlanComponent,
          },
          {
            path: 'yearly',
            component: PacientYearlyPlanComponent,
          },
        ]
      },
      {
        path: 'my/medical-appointment-reservation',
        component: MedicalAppointmentReservationComponent
      },
      {
        path: 'my/medical-appointment-reservation/:id/pick-turn',
        component: PickTurnComponent
      },
      {
        path: 'my/medical-appointment-reservation/:id/checkout',
        component: CheckoutComponent
      },
      {
        path: 'my/medical-appointment-reservation/done',
        component: DoneComponent
      },
      {
        path: 'my/medical-form',
        component: MedicalFormComponent
      },
      {
        path: 'my/home',
        component: HomeComponent
      },
      {
        path: 'my/attentions',
        component: AttentionsPatientsComponent
      },
      {
        path: 'my/invitations',
        component: InvitationsPatientComponent
      },
      { path: 'my/help-center',
        component: HelpCenterComponent  
      },
      { path: 'my/tracking',
        component: TrackingComponent  
      },
      {
        path: 'my/teleconsulta',
        component: AttentionsComponent
      },
      {
        path: 'my/patient-profile',
        component: PatientProfileComponent,
      },
      {
        path: 'my/add-child',
        component: AddChildComponent
      }
    ]
  },
  {
  path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'plans',
        component: PlansComponent
      },
      {
        path: 'yearly-plan',
        component: YearlyPlanComponent
      },
      {
        path: 'yearly-membership',
        component: YearlyMembershipComponent
      },
      {
        path: 'monthly-membership',
        component: MonthlyMembershipComponent
      },
      {
        path: 'invitations',
        component: InvitationsComponent
      },
      {
        path: 'honorarium',
        component: HonorariumComponent
      },
      {
        path: 'home',
        component: HomeComponent
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
