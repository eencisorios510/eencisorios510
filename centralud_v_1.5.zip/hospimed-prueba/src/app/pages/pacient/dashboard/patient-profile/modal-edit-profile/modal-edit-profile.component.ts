import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-edit-profile',
  templateUrl: './modal-edit-profile.component.html',
  styleUrls: ['./modal-edit-profile.component.scss']
})
export class ModalEditProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
