import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientMonitoringComponent } from './patient-monitoring.component';

describe('PatientMonitoringComponent', () => {
  let component: PatientMonitoringComponent;
  let fixture: ComponentFixture<PatientMonitoringComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientMonitoringComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientMonitoringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
