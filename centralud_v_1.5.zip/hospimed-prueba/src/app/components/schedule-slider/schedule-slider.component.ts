import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-schedule-slider',
  templateUrl: './schedule-slider.component.html',
  styleUrls: ['./schedule-slider.component.scss']
})
export class ScheduleSliderComponent implements OnInit {

  @Input() dates: [];
  @Input() isEmpty: boolean = true;
  @Input() isPacient: boolean = false;

  @Output() removeTurnEvent = new EventEmitter<{ date: string, turnIndex: number }>();
  @Output() selectTurnEvent = new EventEmitter<{ date: string, turnIndex: number }>();

  sliderOptions: OwlOptions = {
    loop: false,
    dots: false,
    items: 4,
    nav: true,
    navText: [ '<div class="schedule-slider-btn mat-calendar-previous-button"></div>', '<div class="schedule-slider-btn mat-calendar-next-button"></div>' ],
    responsive: {
      1024 : {
        items: 7
      }
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

  removeTurn(date, turnIndex): void {
    console.log('date: ', date);
    console.log('turnIndex: ', turnIndex);
    this.removeTurnEvent.emit({ date, turnIndex });
  }

  handleTurnClicked(turn): void {
    if (!this.isPacient) return;

    this.selectTurnEvent.emit(turn);
  }

}
