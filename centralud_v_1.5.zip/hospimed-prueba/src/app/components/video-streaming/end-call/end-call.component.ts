import { Component, OnInit } from '@angular/core';
import {MatDialogRef} from '@angular/material/dialog';

@Component({
  selector: 'app-end-call',
  templateUrl: './end-call.component.html',
  styleUrls: ['./end-call.component.scss']
})
export class EndCallComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<EndCallComponent>) { }

  onCancel(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
  }

}
