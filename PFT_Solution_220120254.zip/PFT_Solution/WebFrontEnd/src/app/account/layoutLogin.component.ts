﻿import { Component ,inject} from '@angular/core';
import { Router } from '@angular/router';

import { AccountService } from '@app/_services';

@Component({ templateUrl: 'layoutLogin.component.html' })
export class LayoutLoginComponent {
    private readonly accountService = inject(AccountService);
    constructor(
        private router: Router
    ) {
        // redirect to home if already logged in
        if (this.accountService.userValue) {
            this.router.navigate(['/']);
        }
    }
}