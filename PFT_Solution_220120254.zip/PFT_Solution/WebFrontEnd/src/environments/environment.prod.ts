export const environment = {
  production: true,
 //apiUrl: 'http://localhost:5041' 
 apiUrl: 'https://localhost:7060'
 //apiUrl: 'http://10.162.78.96:8080'
};
