import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-next-appointment',
  templateUrl: './next-appointment.component.html',
  styleUrls: ['./next-appointment.component.scss']
})
export class NextAppointmentComponent implements OnInit {

  proximaCita: number = 0;

  constructor() { }

  ngOnInit(): void {
  }

}
