import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-left-modal',
  templateUrl: './left-modal.component.html',
  styleUrls: ['./left-modal.component.scss']
})
export class LeftModalComponent implements OnInit {

  @Input() show: boolean;

  @Input() size: string = 'half'; // half = 50% || quarter = 25%

  @Input() title: string = '';

  @Output() hideModalEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit(): void {
  }

}
